# Deckwave — working agreements

Beat-locked, harmonically-mixed DJ set built from the user's own music library,
running entirely in the browser. Vanilla JS IIFE modules, shadow DOM, no build
step. Essentia.js (WASM) for analysis, SoundTouch AudioWorklet for stretching.

Read `docs/ROADMAP.md` for planned work and carried debt (D1–D9, R1–R11),
`docs/BUILD-LOG.md` for how each subsystem came to be the way it is, and
**`docs/LISTENING.md` for the six things that are built, measured and unheard**
— exact tracks, what to do, and what each answer changes. Most
"why is this so strange" questions are answered there.

## Hard constraints

**No bundler, framework, or build step.** The no-build property is deliberate.

**Never change a threshold, calibration constant, or detector by reasoning.**
Every threshold here was set by measuring live signal, and four were wrong the
first time because a number was chosen without measuring the range. If a change
would move one, say so and ask the user to test it. This applies to detector
inputs too: changing what a detector *sees* changes its output.

**Claims that must be preserved.** These are load-bearing honesty, not hedging:

- Confidence is on Essentia's 0–5.32 scale and is NOT comparable to any other
  detector's number.
- Energy is a CONSTRUCTED index (45% loudness, 25% brightness, 30% tempo), not
  a measurement. The weights were chosen, not fitted.
- The chromagram is NOT a piano roll.
- The loudness panel is RELATIVE — K-weighting is approximated.
- Score determinism across browsers is UNTESTED.
- When the sequencer returns fewer tracks than requested, that is the gate
  working, not a failure. **As of 2026-08-18 it should almost never happen:**
  a track the gate cannot reach is now played STRAIGHT rather than dropped.
  If a build still comes back short, that is worth investigating.
- **Grid error IS beatmatch error, and that is a derivation, not a metaphor.**
  The engine stretches by `tempo / meta.bpm` while aligning to `meta.beats`;
  if those disagree by 6% the transition is 6% out. That is why the pool gate
  measures it and no longer measures Essentia confidence.
- **"Played straight" is not a quality judgement.** An unlocked track is
  unstretched because it is not being beatmatched — never print `0.0%` stretch
  against one, it reads as the best transition on screen.
- **The 9% grid cut is DERIVED but UNTESTED BY EAR.** The distribution has an
  empty band from 7.50% to 11.04% and any cut inside it selects the same five
  tracks. About 3% is the other defensible answer and plays 22 straight.
  `DW.lock.maxGridErrPct` is live; it needs the keeper, not an argument.

**Do not label an axis with numbers the project chose.** The VU scale is
aligned to −6 dBFS by decision, not standard. Printing dB against it would
lend a chosen number the authority of a measured one.

## Verification discipline

This is the project's recurring failure: **seven diagnostics across two
sessions returned confident answers about nothing.** See BUILD-LOG Acts 18 and
21 for all seven and why each was worthless.

**State what would falsify a check before trusting it.** A test whose pass
condition does not exclude the failure mode is decoration.

Specifically, these do NOT work and have all lied here:

- Counting lit or non-background pixels — a placeholder, an axis, and a flat
  line are all non-zero.
- Checking an element exists in the DOM — it can exist under a clip.
- Onset matching with loose tolerance — onsets outnumber beats; everything
  matches.

What works: **draw twice with real signal between, and diff.** Hit-test with
`elementFromPoint`. Read state from an accessor rather than inferring it from
rendering — `DWPANELS.hist()` and `DW._dev` exist because unobservable
components can only be debugged by guessing.

**Write the ledger row as you catch it, tagged — do not wait for me.**
A finding that needs my confirmation still gets written; mark it
**`[INFERRED]`** and say what would confirm it. I flip it to **`[CONFIRMED]`**
when I have heard or seen the thing. Changing a tag costs nothing; recovering
a finding lost to compaction costs a session, and has.

**Write findings down when you make them.** A researched answer that lives
only in the conversation is lost at the next compaction — that has already
happened once here, and I contradicted my own earlier research seven hours
later. After any compaction, read the original transcript in
`~/.claude/projects/` and diff it against what the summary carried; it
recovered a working answer that the summary had dropped entirely.

**The user's ear is an instrument.** On the beat-phase question it resolved in
one A/B what three measurements could not. Take their reports seriously and
literally; "it doesn't pop when I jump directly to it" was the whole diagnosis.

## Current state

- **The re-scan has RUN.** 2026-08-18, 179 tracks at `ANALYSIS_V = 2`, zero
  failures, 12.0 minutes, peak 851 MB. Every grid now covers at least 99% of
  its track (median 99.71%, worst shortfall 0.97s); the latest beat in the
  library went 119.9s → 506.23s. BUILD-LOG Act 22 has the full account.
- **The library moved and grew.** `C:\Claude\Music\LukHash`, **189 tracks**,
  flat, 4.47 GB. All 189 cache keys survived the move (`name|size|mtime`), so
  nothing re-analysed. `Transient Offworld` (10 tracks) had never been scanned
  — it existed only as an unflattened album folder. **SCANNED 2026-08-18** and
  confirmed by the keeper: 219 records in the cache, all ten Transient Offworld
  records now v2. The library is live at the new path and the corpus the
  sequencer builds from is chiptune only.

  Consequence, and it is the one to remember: **`normalise()` has now re-run
  against a pure-chiptune corpus**, so every energy figure and the whole arc
  differ from anything measured before this date. Comparisons across that line
  are not like-for-like.
- **The corpus is chiptune only now, and that changes the arc.** The 28
  non-chiptune imports roughly doubled the brightness range that `normalise()`
  scales against; removing them shifts energy on 191 tracks by a median 0.039
  and **changes the rank of 181 of them**. No purge needed: `DB.all()` is never
  called, `corpus` starts empty each load and is filled only by `ingest()`, so
  scanning the new folder is sufficient. BUILD-LOG Act 23.
- **PHASE: RESOLVED, and it was never phase.** 2026-08-18, after the worklet
  upgrade the keeper reported the popping gone. That was the stated falsifier:
  a non-dropping worklet removing the symptom entirely means phase was never
  audible here. D5's audible half closes as a MISATTRIBUTION, not a fix — the
  whole-track grid was still right for coverage, which was measured separately.
  One report, one pair of tracks; if popping returns on other material, reopen.
- **How it was confounded, kept because it will happen again.** The grid
  coverage half of D5 is verified. The popping-through-a-mix half rested on
  "clean alone, clean jumped-to, pops through a mix" — but the first deck and
  any jumped-to deck run at `rate = 1.0`, and only chained decks are stretched.
  The old SoundTouch worklet (0.3.0) dropped samples ONLY when stretching: 0
  gaps/sec at 1.00, 10 gaps/sec at 1.08. So that A/B separated stretched from
  unstretched just as well as one deck from two, and discriminates nothing.
  BUILD-LOG Act 21 carries the full note.
- **Worklet upgraded 0.3.0 → 2.1.1 (LGPL-2.1 → MPL-2.0), 2026-08-18.** Not a
  drop-in: `tempo` is gone, the source changes speed and the worklet
  compensates pitch. Measured clean offline and verified to load in-browser.
  **How it SOUNDS is unverified** — and if the popping through a mix now goes
  away entirely, phase was never audible here. That is the test.
- **The re-scan moved two things nobody asked for.** Three tracks flipped to
  double tempo with the grid doubling to match (Perpetual Motion, PROXIMA,
  Galaxy) and all three still pass the confidence gate; and confidence fell
  corpus-wide, median 2.181 → 1.783, taking the sequencer pool from 170 to 160.
  Both need the user's ear and decision — do not adjust a threshold to hide
  either.
- **Nothing is discarded from a set any more, 2026-08-18.** The confidence
  gate is gone (it was measuring the wrong thing — BUILD-LOG Act 25) and the
  stretch gate no longer ends the set: an unreachable track plays straight and
  repositions the set to its own tempo. Measured on the real corpus: **171 of
  171 placed, 9 straight (5 untrusted grid, 4 out of reach), 162 beatmatched.**
  **[INFERRED]** — 8 offline checks pass; nobody has heard a straight
  transition yet, and the reach jumps are large (167 → 100 bpm in one case).
- **`sequence()` mutates the shared corpus objects.** `_stretch`, `_tempoAt`,
  `_locked`, `_unlocked` are stamped on the metas, so building twice restamps
  the first set's rows underneath it. Known, not fixed, and it produced a
  phantom test failure once already. `commit()` deletes `_dwell` for the same
  reason.
- **Routing reached the deck for the first time, 2026-08-18.** Every scenic
  route and fast blend since patch 09 was inert in audio: `commitAndRepair()`
  returns a NEW array and `applyRoute()` gave it to the dashboard only, while
  the Player kept the array captured at play(). `DW.reorder(seq)` now adopts
  the caller's array so the two are one object again. **Fast blend also leaves
  the current track at the next downbeat now** — that is a behaviour change,
  not just a fix. BUILD-LOG Act 24, ledger 40. **[CONFIRMED]** by the keeper
  2026-08-18 — *"it's looking/sounding tight now"* — after they had already
  reached the mechanism themselves: *"we are not on demoscene right now."*
- **Now-playing and the track list read the DECK now, not the list index.**
  `DW.nowMeta` is the meta object on the playing deck. The keeper caught the
  old behaviour with *"we are not on demoscene right now"* — the panel naming
  a track they were not hearing. Ledger 33 and 40 are the same class; when a
  component can be TOLD the truth, do not let it infer it.
- **The route panel is the standing check.** It draws
  `set[state.idx] === DW.nowMeta` as `LIST ≠ DECK` in red. That one line is
  what would have caught ledger 40, 33 and 38, and it is now on screen instead
  of in a comment.
- **`settle` exists and is OFF.** Riding a stretched deck back to its own speed
  after a bad blend. Turning it on makes the rolling tempo the current track's
  BPM instead of the 35%-drift target, so it changes the whole plan downstream,
  and 45s is chosen not measured. ROADMAP D8. Do not switch it on for the
  keeper without saying what it changes.
- **"Songs with brackets won't load" is CLOSED as a misattribution.** It was
  ledger 40, not the filenames: those tracks sit at ~140 bpm, outside the gate
  from most of the set, so the only way to reach them was a route — and routes
  never reached the deck. Both named tracks now play. The lesson is cheap and
  worth keeping: **"won't load" from the keeper may mean "can't get there"** —
  check the BPM against the set tempo before touching the filesystem. ROADMAP
  D9. `audit set` stays; it is a real instrument either way.
- **Confirmed by the keeper 2026-08-18:** the now-playing bar fills (ledger 34),
  tooltips follow a swapped tile (ledger 37), and **set journeys sound fine** —
  their words, *"they seem quite fine"*, which is the first ear-level
  confirmation the arc holds on the pure-chiptune corpus.
- `evidence/` holds the pre-fix cache, 219 records, none with a beat past
  119.9s. It cannot be regenerated.
- **Publishing:** the patent gate is lifted, but nothing is published and there
  is no git remote. Do not create one or push without being asked.

## Running it

```bash
python tools/serve.py          # localhost, 8777. Safe to run twice
python tools/serve.py --stop   # stop it
python tools/serve.py --lan    # LAN, HTTPS, 8443 — cert already exists
```

`.claude/launch.json` declares it so the harness owns the lifecycle.

Reloading the page destroys the loaded set and any listen-mode capture. **Say
so before reloading during a listening session** — it costs the user their
work, not just a page.
