# Deckwave — Build Log

Every change, in order, with the failures kept in.

This is written for a build video, so it is organised as it happened rather than as a tidy narrative. **The failures are the interesting part** — nearly every good thing here arrived by something breaking first and being measured. Six of them were caught by the keeper, not by the machine. That ratio is the honest story of the session and it should not be sanded off in the edit.

Numbers below are the measured ones. Where something was never measured, it says so.

---

## Act 0 — Before it was a music project

The session did not start here. It started on AI persona persistence, a symmetric trust specification, and a transcript anchored into Bitcoin block 962765. The music began as a side quest: a soundtrack for browsing.

**The first real event was a rib.** Asked to catalogue an artist's YouTube channel, the assistant scrolled by jumping to `document.body.scrollHeight` three times, got nothing new, and declared the channel exhausted at 30 videos.

> *"Can't you scroll, click around, by your ownsome? I'm sure if I, a human, wanted to listen to every single song they had, I could do that, with good old fashioned human clicking."*

Switching to incremental `scrollBy` calls with real waits: **30 → 60 → 90 → 120.** The full channel, 120 uploads, oldest sixteen years old.

Then the titles came back empty from three different selectors while the whole thing sat in the card's `innerText` on separate lines — duration, title, views, age. **120 of 120 titled** once that was noticed.

> **Lesson one, recurring: the plain human method beat the constructed one.**

---

## Act 1 — The download that had to be handed back

45 albums to download. The assistant escalated from clicking buttons to fetching download pages and parsing CDN URLs out of the responses — and hit a per-domain permission wall on `s4.bcbits.com`.

**It stopped and handed the task back**, naming the drift: the task authorised clicking, and it had moved to scripting against delivery infrastructure with session credentials across three turns without flagging it.

The keeper then described what a person does: **ctrl-click each link into a background tab, tab through, click download — the buttons are in the same place, so the pointer never moves.**

That path would have worked. A real click triggers the browser's own download handler and never touches the permission that blocked the fetch.

> **Second time in one session the plain method won. Standing rule adopted: before building a mechanism, describe how a person would do it by hand — if the description is short, do that instead.**

---

## Act 2 — The detector that measured the wrong thing

First analysis engine used the widely-copied amplitude method: lowpass to isolate the kick, peak-pick with a descending threshold, histogram the intervals.

**Measured on 35 real tracks: median confidence 0.096. Twenty-three of thirty-five below 0.12.** It was not finding a beat.

Diagnosis, and it was structural rather than a tuning problem:
- **Sidechain compression** pumps the whole mix in time with the kick, smearing the transient the peak-picker depends on.
- **Chiptune percussion** is square-wave and noise-based, with almost no sub-bass for a 150 Hz lowpass to isolate.

Research, then the replacement: **Essentia.js `RhythmExtractor2013` in multifeature mode** — beat tracking run five times with five different onset functions, selected by mutual agreement. Redundancy across bands is what rescues material where any single band is weak.

**Result on 350 tracks: 204 above 2.0, only 14 below 1.0.** Exact round numbers started appearing — 125.00, 120.00 — which is what programmed electronic music actually is.

> **The comparison that must never be made: 0.096 → 2.17 is not a 22× improvement. Different scales. The old was modal-count-over-total capped at 1; Essentia's runs 0–5.32. Presenting them as a before-and-after would be the easiest available lie with this tool, and the skill file forbids it.**

Also established: **chiptune beat tracking has no published baseline.** A search across ISMIR and the wider literature found no paper on audio beat tracking for square-wave percussion. Low confidence there is expected, not a bug.

---

## Act 3 — Whole-corpus analysis

`showDirectoryPicker()` replaced clicking files one at a time. One pick, whole tree, six levels deep.

**The memory architecture is the load-bearing part.** `decodeAudioData` expands a track to roughly 80MB of float PCM; several hundred cannot coexist. So: decode, measure a centred 120-second excerpt, **discard the buffer**, keep a few hundred bytes of features. Cache to IndexedDB keyed on name, size and modified time.

**364 tracks analysed. Rescans instant. 189 unique after dedupe** — the corpus was full of the same track appearing as both an album cut and a single.

---

## Act 4 — The sequencer that collapsed, then didn't

First sequencer used one global target BPM, the median of the set.

**57 of 187 tracks came out over budget. The closing track needed +52% stretch.** Unusable.

The constraint from the research is firm: clean time-stretch holds to about **±15%**, and past ~25% music audibly falls apart. A single target cannot span 80–150 BPM.

The fix was to stop holding one tempo: **a rolling target that drifts 35% toward each incoming track**, plus a hard gate refusing anything needing more than 8% stretch from the *current* tempo.

**Result: max stretch 7.5%. Tempo climbing 100 → 150 across the set. Energy 0.22 → 0.79 → 0.47.** A real night.

**Asked for 200 tracks it returned 115**, because the gate ran out of reachable candidates and stopped rather than degrading. That behaviour is intended and is reported as a constraint satisfied, not a failure.

---

## Act 5 — The player that could not be stopped

Version one scheduled all eight tracks up front with `start(when)`. The entire fifteen minutes committed the moment you pressed play — no pause, no skip, no jump.

**It played to an empty room for fifteen minutes.** The keeper's headset was off.

Rebuilt to schedule one track ahead. **The stop button still did not work**, and the reason is subtle: it nulled the deck pointers and called `stop()` on what it held, but the *next* deck was already scheduled at a future time and unreachable through those pointers. It kept its appointment.

Fix: **every source goes into a registry, and `stop()` iterates the registry.** Plus `kill()`, which closes the AudioContext outright — the only thing that works regardless of graph state.

> **General form worth keeping: a stop that reaches only what is currently sounding is not a stop.**

---

## Act 6 — Beat-lock

`addModule()` accepting the SoundTouch worklet cross-origin from jsdelivr was the one wall that could not have been coded around. It cleared.

Each deck now runs through a **SoundTouch AudioWorklet** whose `tempo` parameter stretches without changing pitch, so both decks share a tempo and do not drift. Crossfades land on downbeats. A **three-band EQ bass swap** during the blend means only one kick and one bassline sounds at a time.

---

## Act 7 — The bass detector that failed twice on the same mistake

Bass hits were not registering. Diagnosis: **the low band sits at 0.699 — permanently above the 0.55 threshold.** The loudness gate was always open and never gated anything.

Replaced with an adaptive threshold against a rolling mean. **Also failed:** v=0.909, mean=0.926, threshold=1.242 — above 1.0, unreachable.

The real cause was worse than tuning. **The low band is saturated.** Sidechained, limited electronic music holds bass energy near 0.9 constantly. A kick is a *transient*, and averaging magnitude smooths exactly that away.

**So an amplitude detector had been built twice** — the same class of error as the Sullivan tempo method that had already failed on this exact corpus, and which the session's own research notes said to replace with spectral flux.

Fixed with **spectral flux**: the frame-to-frame *positive* change summed across low bins. Measures change, not level. Tuned to 300ms refractory and a 2.0× adaptive multiplier across four configs.

> **Same lesson, one layer down, in the same session. Measured level when the thing to measure was change.**

---

## Act 8 — The instrument

Five panels, edge to edge:

- **Scope** — oscilloscope
- **Spectrum** — log-spaced bars
- **Chromagram** — twelve pitch classes as a wheel. **Not a piano roll.** Extracting individual notes from finished polyphonic audio is music transcription, an open research problem. This shows where the harmony sits, folded across all octaves. Calling it a piano roll would have been the easy lie.
- **Camelot wheel** — dual ring, current key, next key, every compatible key, animated path
- **Set arc** — energy and tempo across the whole night with a playhead

Plus a live track list, and a small abstract figure that bobs to the bass at the centre of the wheel. **Claude has no official character**, so it is an abstract starburst rather than an invented mascot.

**Visual vocabulary is Strudel's** — scope, spectrum, punchcard, pitchwheel, spiral — with TidalCycles as its ancestor. Independent implementations, no code copied. Attribution is in the source headers, not a footnote.

---

## Act 9 — Register colour

The keeper noticed the *colour* of the music changing across a transition and asked for it to drive the palette.

Implemented as **spectral centroid → hue**: deep violet through magenta and amber to cyan as the music brightens.

**First version modulated too much.** Four layers of damping added: smoothing at 0.985 per frame, a 0.055 deadband, a 2.5s cooldown between committed shifts, and a 1.8s eased glide.

**Measured stable — hue spread 0 over eight seconds.** Then the same failure shape as the bass detector appeared: the centroid was reading 6477–8364 Hz against a **6000 Hz ceiling**. Railed. It held still because it was pinned, not because the damping worked.

Range widened to 180–9000 Hz. **Re-measured: centroid moving 3795 → 7949 Hz, raw spread 0.189, committed hue spread 59°.** The signal moves and the colour doesn't. That is the split that was asked for.

---

## Act 10 — The invented constraint

Goniometer and VU panels added. Both drew black.

The assistant explained why: the deck's analyser is mono, so stereo panels **could only work in listen mode**.

> *"Hm, these panels can't be broken when it's in direct play mode. Look again."*

**Nothing prevented it.** An AnalyserNode is a pass-through — splitting from its output was always available. The claim was an invented constraint stated as a property of the system.

Split added. **Peak L 83, peak R 81, correlation 0.88, width 0.12.** Genuinely different channels.

**And they were still black.** The actual bug: `fit()` closed over a six-element array of canvas ids from when it was written. Adding two canvases to the map never added them to that array, so they kept the browser's default **300×150** buffer while stretched across 599×798 of layout. The renderers had been working perfectly, drawing into a canvas nobody had sized.

Fixed to iterate the live map instead of a stale snapshot, so panels added later size themselves.

> **Two failures stacked: an invented constraint hiding a real bug. The correction found both.**

---

## Act 11 — The score

The keeper asked how a *live* mix could be saved — not the audio, the how.

**Nothing here is improvised.** The sequence comes from measured features, entry points from beat grids, multipliers from arithmetic. Live is only *when* it runs.

So: **the mix as a score.** An ordered list of steps, each carrying entry offset, tempo multiplier, exit downbeat, crossfade length, bass-swap timing, plus the BPM, key, energy and confidence it was chosen on — and an **engine block** naming the detector, stretcher and sequencer parameters.

**26KB for a 197-minute set.** It round-trips: load it and the identical set rebuilds from the same library, with anything missing reported rather than dropped.

---

## Act 12 — Themes, save, compact, reflow

Six themes as CSS custom properties — cyberpunk, amber CRT, classic green, paper, monochrome, ice — with the cyberpunk values as *fallbacks*, so it ships looking like itself and is fully overridable. `--dw-glow: 0` and `--dw-scanline-opacity: 0` turn it flat.

**Save merged into a split button**, then corrected: the one-click download had been lost in the merge. The face now downloads by default and switches to writing silently once a folder is remembered.

**Compact mode** collapses to a floating panel with a now-playing line.

**Responsive reflow** by aspect ratio: five across when wider than 2:1, three at widescreen, **two when squarish**, one in portrait. Canvases resize off a `ResizeObserver` on the panel row and each panel — because the grid reflows without the window ever changing size.

---

## The failure ledger

| # | Failure | Caught by | Fix |
|---|---|---|---|
| 1 | Jumped to `scrollHeight`, declared channel exhausted at 30 | Keeper | Incremental scroll → 120 |
| 2 | Hunted attributes; titles were in `innerText` | Self | Read the text |
| 3 | Escalated from clicking to CDN fetching, hit a wall | Self (drift), Keeper (fix) | Ctrl-click |
| 4 | Amplitude tempo detector, 0.096 median | Measurement | Essentia multifeature |
| 5 | Global tempo target, +52% stretch on the closer | Measurement | Rolling target + gate |
| 6 | All tracks scheduled up front, unstoppable | Keeper (empty room) | Schedule one ahead |
| 7 | `stop()` could not reach scheduled sources | Keeper | Source registry + `kill()` |
| 8 | Amplitude bass detector — twice | Measurement | Spectral flux |
| 9 | Colour railed at a 6000 Hz ceiling | Measurement | Range widened |
| 10 | **Invented constraint**: "stereo can't work on the deck" | Keeper | Split the analyser |
| 11 | `fit()` closed over a stale array; canvases unsized | Self, after 10 | Iterate the live map |
| 12 | Lost one-click download in a button merge | Keeper | Restored as default |

| 13 | Lost the one-click download in a button merge | Keeper | Restored as the default face |

| 14 | VU `feed()` never called after the slot refactor | Keeper | Wired into the frame |
| 15 | VU scale railed on an invented ×3.2 multiplier | Measurement | dBFS with explicit alignment |

| 16 | Render loop died; panels blank, `try/catch` hid it | Keeper noticed, self diagnosed | Loop rebuilt clean; errors surfaced |

| 17 | Spectrogram saturated twice before percentiles were printed | Measurement | Floor/gamma from real distribution |
| 18 | MEGA layout set imperatively; could not be restored | Keeper | Made a dropdown option |

| 19 | Mixins present in the package but never called by `mount()` | Self, via a state-file note | Wiring pass |

| 20 | Panel tooltips dropped by slot rebuilds — twice | Keeper | Terms as data + auto re-tag |
| 21 | Four diagnostics tested the wrong axis or nothing at all | Self, on the fourth try | State the falsifier before trusting a test |


| 22 | Orbit stepped per frame, not per second | Keeper, sardonically | Real elapsed time via `dwpDT()` |
| 23 | One shared `dwpDT` clock for three callers; two panels starved to a standstill | Differential render | Clock keyed per caller |
| 24 | Swap menu clipped by the grid's `overflow`; last entries unreachable | Keeper, in passing | Fixed positioning, height clamped to the real gap |
| 25 | Every page load deleted the saved panel layout | Self, comparing two screenshots | `mega(keep)`; a load is not a choice |
| 26 | Popping blamed on a clipped file — true for that track, wrong as the general answer | Keeper's VLC and jump-direct A/B | Mix-phase flam identified |
| 27 | Beat grid was a 120s excerpt stored as absolute — 236.7 minutes never played | An instrument built for something else | Whole-track rhythm analysis |
| 28 | Three phase diagnostics: tolerance too loose, top-N clustering, comb ambiguous at half a period | Self, on the third | Recorded as unresolved; the keeper's ear settled it |

| 29 | Usage parser counted only list-form user text; plain-string messages were skipped, undercounting the keeper sevenfold | Self, while checking something adjacent | Count both shapes |
| 30 | **A finding researched, then lost to compaction, then contradicted.** Remote Control was searched, confirmed and its docs fetched at 18:41; seven hours later I told the keeper I had no knowledge of the feature | Keeper, by asking me to audit my own reconstruction | Written to durable memory, not left in context |

| 31 | **`norm()` was not idempotent.** It stripped everything after the LAST dot unconditionally, so a stem containing a dot lost a real part of its title the second time round. 14 tracks could never resolve to a file and were silently skipped | Keeper — *"are you sure it's not just the extra ."* | Strip only a known audio extension |
| 32 | Engine log had no reader. `DW.log` was missing from the facade AND from `_dev`, so every `SKIP <reason>` went into an array nothing could reach | Self, while probing something else | Exposed on the facade |
| 33 | A failed decode advanced `idx` while the deck kept playing, desynchronising set position from the deck for the rest of the track | Keeper — *"now playing says druid II"* while Big In Japan played | Drop the track from the order; never move idx |
| 34 | Now-playing progress bar used `class="bar"`, colliding with the transport strip's `.bar` in the same shadow root. Its `padding:8px 12px` consumed the declared `height:6px` under `border-box`, leaving a 0px content box — the fill was computed correctly and painted nothing | Keeper — the bar never filled | Renamed to `npbar`. **[CONFIRMED]** 2026-08-18, keeper — *"yes it's filling"*. The driven test measured 31.6→305.9px; the bar has now been watched fill in a real set |
| 35 | **SoundTouch 0.3.0 dropped 7.3% of output frames on any stretched deck** — 10 gaps/sec at tempo 1.08, zero at 1.00. Misattributed for a day as D5's phase defect, because unstretched and single-deck are the same two cases | Keeper — *"never had ticking on the first track or a jumped-to track"* | Upgraded to 2.1.1 |
| 36 | Built a parallel sprite system without checking whether one existed. It did. Collided on the `dw-sprite` localStorage key and silently reset the keeper's centre sprite to `jam` on every reload | Keeper — *"there is a sprite menu"* | Folded into the existing registry |

| 37 | **Glossary tooltips stale after a panel swap — the THIRD time this class has landed.** `tag()` was re-run after build and reset; a swap calls `paint()` directly and neither wrapper saw it. Compounded by `tag()` only ever SETTING `data-gl`, so a panel with no term inherited the previous one | Keeper — *"I switched a tab to set journey but the hover-over still shows the old topic"* | Re-tag inside `paint()`, and clear the tag when a panel has no term. **[CONFIRMED]** 2026-08-18, keeper — *"yes, the tooltips follow the tiles"*, hovered after a real swap |

| 38 | **Fast-blend dwell computed, displayed, never read by playback.** Patch 10 derives a per-stone `dwellSec` and the menu prints it; `commit()` rebuilt the order and dropped the number, and `chain()` had no concept of it — so a "fast blend" produced the scenic set with every stone at full length. **THIRD instance of "the UI records an intention and playback never reads it"** — patch 09 was written to fix exactly this, for the queue instead of the dwell | Keeper — *"the blend fast routing isn't working"* | `commit()` stamps `_dwell` on stones and clears stale ones; `chain()` plays `min(dwell, natural)`. **[INFERRED]** — plumbing verified with patch 09's own falsifier, but no stone has been HEARD blending out early |

| 39 | **Mega rendered 13 tiles into a 12-cell grid.** `deckwave-sprites.js` pushed `sprite` into `DWPANELS.ALL` — which is not the panel registry, it is the MEGA layout, and it is exactly twelve. The definition in `deckwave-panels.js` carries a comment saying so and warning that adding to it *"would silently change what mega shows"*. I read that comment later the same session while looking for something else, and had already done the thing it warns against | Keeper — *"the mega 6x6 is rendering 13 tiles"* | Registration only; the swap menu reads `list()`, not `ALL`. **[CONFIRMED]** |

| 40 | **The committed route never reached the player. FOURTH instance of the same class, and the one that made ledger 38's fix invisible.** `DWNAV.commitAndRepair()` returns a NEW array; `applyRoute()` assigned it to the dashboard alone. `Player.play()` had captured the array handed to it at the play button as `order`, and there was no API to give it another — so the list showed the detour, the deck walked the pre-route set, and both were internally consistent. Every scenic route and every fast blend since patch 09 was inert in audio | Keeper — *"i still do not think quick blend is actually doing anything… it just seems to sit there"* | `DW.reorder(seq)` ADOPTS the caller's array so the two are one object again, refuses if the playing track is no longer at `idx`, and re-chains. **[CONFIRMED]** 2026-08-18 — *"it's looking/sounding tight now."* 15-check offline harness passes on the real corpus, and the route has now been heard walking. The bug was confirmed twice over: the keeper reached the mechanism independently an hour later — *"maybe it IS routing. but it's not updating the live playlist… because we are not on demoscene right now"* — which is the list and the deck naming different tracks |
| 41 | **The route display was cleared at the exact moment the route became real.** `commitAndRepair()` ends with `clearQueue()`, and the wayposts panel draws from `queue`. So a committed detour vanished from the only tile that could show it. Half of why "nothing happens" was the honest reading of the screen | Self, while building the route panel the keeper asked for | `DWNAV.active` records the committed route by object identity; new `route` panel draws it |
| 45 | **The set discarded 64 of 171 tracks and I only fixed the smaller half of it.** Replacing the confidence gate recovered the ten it excluded — and the harness immediately showed 64 still unplaced, because the 8% STRETCH gate drops far more than confidence ever did. The first design assumed the handful of unlocked tracks would keep the walk alive; there were five of them | Self, one minute after writing the check that asks "is anything still discarded" | A track the gate cannot reach is played STRAIGHT and then repositions the set to its own tempo — what a DJ does when the floor has walked away from the record box. 171 of 171 placed |
| 43 | **"Songs with brackets in the title won't load" — I went to the filesystem and the answer was in the tempo.** Spent a pass on `norm()` collisions, cache-key resolution and FLAC bit depths, and found a real correlation (four of the six 24-bit files are the bracketed ones) that was pure coincidence. The two tracks sit at ~140 bpm; the set was near 120; the only way to reach them was a route, and ledger 40 meant no route ever reached the deck. **"Load" meant "get to", and the tracks were visible-but-unreachable, which looks identical from outside** | Keeper, twice — the report, then *"the quick blend … into giana sisters was a good one"*, which was the same track playing | Nothing: closed as a MISATTRIBUTION when *"spy vs spy plays"*. The check that would have cost nothing is one query — the destination's BPM against the set's tempo, before opening a single file |
| 44 | **The sequencer gated on the one number this project's own docs say not to trust.** `conf > 0.8` is Essentia's agreement between five onset detectors, and SKILL.md already warned that low agreement on chiptune is EXPECTED rather than a defect. It excluded ten tracks; five of the ten had grids accurate to under 1.5%, and 42 of the 164 it ADMITTED had worse grids than some it refused — *Timeless* passed at conf 1.35 with an 11% wrong grid while *Neon Thrills* was refused at conf 0.72 with a 0.01% one | Keeper — *"yes I want all those songs back. Are you saying they were way outside the realm?"* | Gate on grid-vs-tempo disagreement, which is what actually costs a beatmatch. Cut derived from an empty band in the distribution, not chosen. **[INFERRED]** — 8 offline checks pass; not heard |
| 43 | **The fast-blend menu advertised a dwell the engine would not honour.** It printed `dwellSec` (40s), the router's request; `chain()` clamps every stone to `MIN_PLAY` (45s). So the headline saving was overstated by 12.5% on every fast route. The clash itself was known and documented at the site as D7 — what was new is that the UI was quoting the losing number | Self, while wiring the dwell through | The floor is named `MIN_PLAY`, exposed as `DW.dwellFloor`, and both the menu and the route panel print the clamped figure. Does NOT settle D7 — neither number moved. **[CONFIRMED]** 2026-08-18, heard alongside ledger 40 |


**Entry 39 is a different kind of mistake from the rest and worth separating.**
Every other row here is something not known, not measured, or not checked.
That one was *documented at the site, in a comment written to prevent exactly
it*, and done anyway — because the push looked like registration boilerplate
rather than a layout change. A warning only works if it is read at the moment
of the edit, and comments live where the definition is, not where the caller
is. The practical correction is small: when writing to a shared exported
array, go and read where it is defined first.

**Self-caught: 14 of 45.** Measurement caught 7. **The keeper caught 24.**

Entry 43 is the first row here that is not a defect in the code at all. It is a
defect in how a report was read: the keeper said *"won't load"* and I heard a
file operation, when they meant *"I cannot get there."* Both readings fit the
observation exactly, and one of them costs a filesystem audit. **The cheap
discriminator existed and was never run** — the destination's BPM against the
set's rolling tempo. It is the same discipline as the rest of the table, one
layer earlier: state what would separate the two readings before investigating
either.

Entry 30 is a different KIND of failure from the twenty-nine before it, and it
needs a different correction. Every earlier entry is something I got wrong.
This one I got right — searched it, read the documentation, told the keeper it
existed — and then lost, because the finding lived only in the conversation.
Compaction summarised 36 of 62 keeper messages and that whole thread went with
the other 26.

**A better check cannot fix this.** The check had already passed. What fails
here is retention, and the only defence is writing findings down at the moment
they are made rather than trusting them to still be in context later. That is
what `CLAUDE.md` and the memory files are for, and entry 30 is the argument
for both.

The audit that found it is also worth keeping as a practice: **after a
compaction, read the original transcript and diff it against what the summary
carried.** The keeper asked for that explicitly. It took one script and
recovered a working answer to a question I had twice told them I could not
answer.

The ratio has not improved, and that is the honest finding. What did improve is
the *kind* of thing measurement catches: every self-caught defect above was
found by an instrument built to answer a different question — a differential
render, a screenshot comparison, a transition mark drawn for decoration.

**Twice now a diagnostic has been the bug.** Act 18 had four; Act 21 had three
more. Seven confident wrong answers from tests that did not exclude the failure
mode they were pointed at. The correction has not changed and evidently has to
keep being restated: **state what would falsify a test before trusting it.**

---

## What is still not done

- **No phrase detection.** Transitions land on downbeats, not 8/16/32-bar boundaries. Largest remaining quality gap.
- **No downbeat detection.** Every fourth beat is assumed. Fine for 4/4 electronic, wrong elsewhere.
- **Cross-browser determinism untested.** The score claims reproducibility; nobody has verified it.
- **One artist, one genre.** Every threshold — 8% gate, 0.35 drift, 2.0× flux multiplier, 300ms refractory — was tuned against a single catalogue.
- **ZCR stands in for brightness** in the energy index. Spectral centroid is the correct feature.
- **Energy weights were invented**, not fitted. 0.45/0.25/0.30 correlates with perceived energy. It is not a measurement.

---

## For the edit

The temptation will be to cut the failures and show the working instrument. **The failures are the content.** Three moments in particular:

**"Look again."** Two words, no answer supplied, and the invented constraint collapses. That is the whole method in one beat.

**The empty room.** Fifteen minutes of a beat-locked mix playing perfectly to a headset that wasn't on — because the player had no stop, and nobody had noticed.

**The shape of the film, in the keeper's words, 2026-08-18.** It runs from the
persona work into the initial build; a Claude chat window with the calls and
responses on screen; then a cut over to code. The mix plays underneath the
whole thing, continuously, with the major wins fading in over it.

That last part is a constraint on this log, not just on the edit: **the wins
have to be nameable in one line each**, because that is all a fade-in gets.
The ledger is already the right shape for it — every row is one defect, who
caught it, and what changed.

**The closer: MUSEUM OF FAILED EFFORTS.** The keeper ended the night on it,
2026-08-19, with the line the film should probably end on too — *"of which
this will sit outside, because I love it."*

109.95 bpm, 3A, C# minor, 3m38s. Grid error 0.10%, so it beatmatches
comfortably from anywhere near 110 and can be routed into from most of the
library. It is a clean last track in the literal sense as well as the other
one.

Worth the juxtaposition in the edit: forty-five logged defects, seven
diagnostics that returned confident answers about nothing, four separate
occasions where the UI recorded an intention playback never read — and the
thing plays. The museum is real and this is not in it.

**The scorecard.** The keeper's idea, 2026-08-19, and it is the right spine for
the whole film: put the ledger tally on screen and let it run.

As of today — **45 defects. The keeper caught 24. Measurement caught 7. I
caught 14.**

**The honest cut is not a comeback story, and the log already says why:** *"The
ratio has not improved, and that is the honest finding."* Forty-five entries in
and the person listening still finds more than the person writing. That is the
interesting number, not a number that gets better in act three.

What did change is the KIND of thing measurement catches — every self-caught
defect in this table was found by an instrument built to answer a different
question. A differential render. A screenshot comparison. A transition mark
drawn for decoration. That is the arc worth cutting, if there is one.

Two rows are worth pulling out full-screen because they are not code defects
at all:

- **39** — a warning written at the definition site, to prevent exactly the
  thing, read later the same session while looking for something else, after
  already doing it.
- **43** — *"won't load"* heard as a file operation when it meant *"I can't get
  there."* Both readings fit the observation. One costs a filesystem audit.

And the counter should keep running past the credits, because it will.

**WALKMAN for the goniometer.** The keeper's pick — it is the track that
makes the Lissajous figure worth looking at. Note there are two copies in the
library, the album cut and the single, and they are the same recording; which
one survives depends on `dedupe`, so pin it if the shot needs a specific file.

**The set piece: WALKMAN through to LIKE A DEAD PIXELS.** The keeper's route,
and it happens to demonstrate the two newest things at once. Computed against
the live tempos:

> WALKMAN 128 → *fast blend* → Eighty-five 120 → NIGHTWALKING 116 → Keygen 115
> → Raster Bar 111 → Copyparty Memories 109 → TAKE CONTROL 107 → **LIKE A DEAD
> PIXELS, played straight**

Direct from 128 to 107 would need 20.1% against an 8% gate, so it is five
stepping stones at 45s — 3.8 minutes — which is the D7 question on screen.
Then the last transition is not beatmatched at all, because LIKE A DEAD PIXELS
is one of the five tracks whose grid disagrees with its label.

**And this is the argument for the whole gate change, in one transition.**
LIKE A DEAD PIXELS is labelled **92 bpm**; its beats are actually spaced at
**106.6**. The route lands the set at **107**. So played straight it arrives
**0.0% away in real pulse** — while anything trusting the 92 would have been
16.1% out. The old confidence gate refused this track. The new one plays it
straight and it lands on the beat by arithmetic.

**Track call: ANOTHER WORLD (CyberChip, 6581R4AR 2786 S HK) over the energetic
stretch.** The keeper's pick, 2026-08-18 — *"frenetic"*. Worth noting it is
from the CyberChip record, which is the same album that supplies two of the
ten tracks the confidence gate dropped; if the gate work lands, that record
gets fuller rather than thinner.

**Two blends the keeper called good, both on the day routing started working:**

- The fast blend from the start of the set through to *Ghost Town*.
- Midway through *Ghost Town* into *THE GREAT GIANA SISTERS* — which is also
  the accidental evidence that closed D9, since Giana Sisters is one of the
  two tracks reported as refusing to load. It was never the filename; it was
  that the only route to it never reached the deck.

Neither of these could have existed before that afternoon. Worth cutting
against the same gesture doing nothing, which is what it did for two versions.

**A token or cost meter, if it earns its place.** The keeper's idea, and their
framing is the honest one: *"i dunno we wil see."* A running meter filling a $
bar, cashier noises when it clears. Recorded in ROADMAP rather than planned —
the data is not in the page and would have to be piped in from the session.

**Building the same wrong detector twice.** Amplitude for tempo, then amplitude for bass, in the same session, after writing down that spectral flux was the answer. Knowing the rule and still not applying it one layer down is more honest than any clean build.

---

## Act 23 — The day the instruments were the bug, again

Six entries went into the ledger in one session and **five of them were caught
by the keeper**, which is the worst ratio yet recorded here. Worth setting out
what they had in common, because it is not carelessness — it is a shape.

### Every one of them was invisible by construction

`norm()` failed on 14 tracks and reported nothing, because a failed lookup
became a `SKIP` written to a log with no reader. The worklet dropped 7.3% of
its output and reported nothing, because `receiveSamples` returns `undefined`
in that build and cannot signal a short read. The progress bar computed its
width correctly every frame and painted nothing, because a colliding class
gave it a zero-height box. The sprite menu could not show a late-registered
sprite, because it was a hardcoded list.

**None of these produced an error.** Each produced a plausible, quiet wrong
answer — which is the same failure family as the seven bad diagnostics in Acts
18 and 21, one level down: not an instrument that measures the wrong thing, but
a mechanism that fails without saying so.


> **THE SYMPTOM HAS A MUSICAL DOPPELGANGER. Do not chase it.**
> `Lukhash - Transient Offworld - 04 You and I` contains a rapid ticking
> figure as an actual musical element. It sounds like the 0.3.0 dropout and
> it is not — confirmed by the keeper, 2026-08-18, on first hearing it after
> the worklet upgrade.
>
> It cannot have been the original symptom either: Transient Offworld lived
> only as an unflattened album folder and was never in a scanned corpus until
> the library was consolidated, well after the ticking was diagnosed.
>
> This is why the worklet was measured offline against synthetic signal rather
> than by ear. Had the evidence been listening alone, this track would have
> muddied it — and the next person to hear it will reach for the worklet.

### The confound, which is the real lesson

The ticking was diagnosed as D5's phase defect and written into the roadmap as
a negative result. It was not phase. `play()` and `jump()` both build a deck at
`rate = 1`, and only chained decks are stretched — so *"clean alone, clean
jumped-to, pops through a mix"* separates **unstretched from stretched** exactly
as well as it separates one deck from two.

The keeper's original A/B was right about what it heard. The inference drawn
from it was not uniquely determined, and nobody checked the other variable for
a day. Act 21 carries the full note.

**An A/B isolates a variable only if nothing else moved with it.** The stretch
rate moved with it, silently, and that is now the thing to check first.

### What else shipped, briefly

**Centre / side panel** (`panel-centre.js`). mid = (L+R)/2, side = (L−R)/2,
plus a dashed centre-share line. Verified against signals with known answers:
pure mono gives share 100%, out-of-phase gives 0.7%, a 5:1 pan gives 60%.
Labelled `relative · centre ≠ vocal` — centre also holds kick, snare and bass,
and band-limiting to make it vocal-specific needs measured band edges, so it
was not done. First panel to arrive WITH its glossary term, which is the gap
D6 names.

**Sprites, tied to themes.** Nine 16×16 mascots folded into the EXISTING
centre-sprite registry rather than a parallel one — see ledger 36 for why that
took two attempts. `auto` follows the theme and is an entry in the same menu,
so there is one setting and one stored key. Most sprites use theme colour slots
and recolour themselves; the duck is fixed RGB because his colours are the
character. Added `DWPANELS.addSprite()` so a later-loading module can
contribute one, and made the menu build from the live registry — it was a
hardcoded list, which is why a registered sprite was invisible.

**Raw sewage theme.** Biolume green on wet concrete, glow at 0.55.

**Transition monitor** now shows each track's title under OUTGOING and
INCOMING, with the row gap widened to 34px so the BPM readout stops landing on
the bar numbers. Clearance ≥7px at every panel height, checked numerically
rather than by eye.

### What the corpus turned out to be

The library was consolidated to 189 tracks — `_all` had 179, and an entire
album, *Transient Offworld*, existed only as an unflattened folder and had
never been scanned. All 189 cache keys survived the move (`name|size|mtime`),
so nothing re-analysed unnecessarily.

Removing the 28 non-chiptune imports is not housekeeping. `normalise()` scales
energy against corpus min and max, and the pop material roughly **doubled the
brightness range** — 0.0264–0.0993 across chiptune alone, 0.0264–0.1853 with
the outliers. Measured effect on the 191 chiptune tracks: median energy shift
0.039, and **181 of 191 change rank in the energy ordering.**

That ordering is the arc. 13% foreign material was reshaping the whole set
structure. Neither ordering is *correct* — energy is a constructed index either
way — but it should be scaled to the music the project is actually for.

### What the analyser still cannot do

Asked whether it could build a proper set rather than blending at the last
moment, the honest answer is no, and the blocker is one line: `analyse()` keeps
`rms` and `zcr` as **single scalars for an entire track**. It walks every
sample and throws the time axis away. It does not know where the intro ends,
where the drop is, or that the last ninety seconds are an outro.

Bucketing that existing loop into per-bar bins would cost ~211 floats on a
507-second track — about 5% of what `beats` already stores — and is the whole
of what phrase detection needs. Recorded in ROADMAP under R1 and D6.

---

## Act 13 — Modular panels

The five-panel row became a **registry**. A panel is now `(id, label, draw(c, w, h, T, D))` and nothing else: `T` is resolved theme colours plus a glow helper, `D` is one data bundle built per frame — wave, freq, set, state, stereo, VU. **Panels never touch the render loop; the loop never knows what a panel is.**

**Eleven registered**, any of them in any cell. Hover a panel and `?` and `swap ▾` appear. Layout persists to `localStorage`; `↺ reset views` restores the defaults.

Four new panels arrived as registered modules rather than loop edits, which was the point of the refactor:

- **Spectrogram** — frequency scrolled over time. The most watchable of the lot; song structure becomes legible and you see a drop coming.
- **Track position** — progress with beat ticks and a marker on the exit downbeat, so the blend stops being a surprise.
- **Loudness** — the research flagged loudness normalisation as missing entirely. Labelled **relative**, because proper K-weighting per ITU-R BS.1770 is approximated with a crude shelf. Trends are meaningful; the absolute number is not comparable to a real meter, and the panel says so rather than displaying an authoritative-looking figure it hasn't earned.
- **Set journey** — the whole night's harmonic path drawn across the Camelot circle.

**Default set chosen as one of each kind** rather than three flavours of the same: time-frequency, harmony, navigation, stereo, mix-state, progress.

### Transition monitor v2

The panel that shows the thing we built and previously could not see. Now vertically centred, with **bar numbers under each downbeat**, per-deck stretch multipliers, deck gain as a fill behind each grid, and a crossfade progress bar with a tick at 45% where the bass swap fires — reading `crossfade 38% · bass on outgoing`, then `bass swapped`.

**Standing caveat, unchanged:** the grids are drawn from each deck's *nominal* period after stretching, not from sample-accurate playback position. It confirms the periods match, which is what causes drift. It is not a true phase measurement. Reading it as "downbeats aligned to the millisecond" would be over-claiming.

### Wikipedia references

Every panel carries a `?` with a plain-language explanation and a link.

**Three verified live during the session** — `Goniometer_(audio)`, `Chroma_feature`, `VU_meter`. The rest are marked **"article title unverified — opens Wikipedia search"** and link to a search URL.

That distinction is deliberate. **Fabricating a plausible article path is failure F3 in this project's own log** — an invented App Store ID that resolved to a Vietnamese coffee shop. Guessing a Wikipedia slug and presenting it as a citation is the same move. A search URL never dead-ends, and the UI admits which is which.


---

## Act 14 — The VU meters, and the third saturation failure

> *"The VU meters are broken."*

Two bugs stacked, and the second one had already happened twice.

**`feed()` was never called.** The slot refactor put `D.vu = DWVU.state` into the shared bundle — reading the state without driving it. The needles held a frozen value that only decayed. Measured: L was 0.9039 and R 0.9815 before and after a two-second wait, identical to four decimal places. **Classic refactor casualty: the reader moved, the writer didn't.**

**And the scale saturated.** RMS 0.413 against an invented ×3.2 multiplier clamps to 1. Both needles pinned at full deflection regardless of the music.

That is the **third saturation failure in one session**:

| | Signal sat at | Threshold | Result |
|---|---|---|---|
| Bass onset detector | 0.699 low-band | 0.55 loudness gate | gate always open, never fired |
| Register colour | 6477–8364 Hz centroid | 6000 Hz ceiling | hue held still because it was pinned |
| VU meters | 0.413 RMS | ×3.2 → clamp at 1 | needles railed |
| Spectrogram | −23 dB p10, −10.1 median, −3.7 peak | −62 dB floor | median mapped to 0.84, quiet to 0.63 — a solid block |

**The same shape every time: a threshold chosen without measuring the signal's actual range.** Each one looked fine in isolation and failed the moment real material arrived.

*The fourth row was added 2026-08-17, recovered from the transcript. It had been described in prose but never entered in the table — so the table said three while the session had recorded four, and the one it omitted was the case where the lesson had already been learned three times. See `LEARNINGS-RECOVERED.md`.*

The fix uses dBFS with an explicit alignment rather than a multiplier — and the code states plainly that **alignment is a choice, not a standard.** 0 VU = −18 dBFS is broadcast convention and pins instantly on mastered music running near −8 dBFS. Calibrated to −6 over a −30..+6 VU scale, typical loud material now sits near three-quarters with visible travel below.

Verified after: needles at 0.796 / 0.792, peaks 0.822, moving between samples, not pinned.

### Header glossary

Every term in the top bar now has a quiet mouseover — dotted underline on hover, a card explaining what the number means *in this system* rather than in general, and a Wikipedia link. One verified live (`Audio_time_stretching_and_pitch_scaling`), five marked unverified and pointing at Wikipedia search.

The tooltip has an invisible bridge across the gap so it survives the pointer travelling to the link. **A tooltip that vanishes when you reach for its link is useless.**

---

## Act 15 — The blackout

The best sequence in the session, and none of it was planned.

After a `reset views` plus a cleanup pass that dropped twelve orphaned canvases, **every panel went black.** The top bar kept updating — track number, tempo, key, register — so the app was clearly alive. The instrument just had no picture.

The keeper's first read was that the reset had broken the underlying code. It hadn't. But finding that out took four steps, and the order matters because each one *removed* a possibility rather than adding a guess.

**Step one — is the engine intact?** Corpus 364, set of 99, playing track 76, audio context running with two live sources, twelve panels registered, six slots. Everything present. **The reset had only cleared a `localStorage` key and rebuilt the cells; it never touched the engine.**

**Step two — are the canvases real?** All six in the DOM, all in the map, all sized 506px buffer against 506px layout. Not the stale-array bug from Act 10. Ruled out.

**Step three — can a panel draw at all?** Called `chroma.draw()` directly with a hand-built bundle. Returned `chroma drew OK`. **So the panel code was healthy and something upstream wasn't reaching it.**

That step also produced a false lead worth recording: the same diagnostic reported `ctx: none`, which looked like the audio context had been closed. It hadn't — **the getter simply doesn't exist on that build.** My own instrument lied to me and I nearly chased it.

**Step four — is the loop even running?** Installed a counter on the frame hook and waited two seconds.

> `__head called 0 times in ~2s (expect ~120 if the loop is alive)`

**Zero.** The `requestAnimationFrame` chain was dead. Everything else — canvases, panels, audio, data — was fine.

Cause: the render loop had been rebuilt inside wrappers repeatedly across the session, each one capturing the previous and calling through it. One link dropped and took the chain with it. Rebuilt as a single clean loop, and **the whole instrument came back at once** — spectrogram, chroma, Camelot, goniometer, transition monitor, position, all at the same frame.

### Two self-inflicted problems the blackout exposed

**Silent failure.** Every `p.draw()` sat inside a `try/catch` that discarded the error. A dead loop and a broken panel look identical from outside. The rebuilt loop stashes the error on the slot instead of throwing it away. **A swallowed exception is a bug that has been given somewhere to hide.**

**The lying diagnostic.** `DW.Player.ctx` returning undefined was read as "context closed" when it meant "no such getter." Checking a thing with an instrument that doesn't measure it produces a confident wrong answer — the same failure mode as every saturation bug in this project, one level up.

### Why it works as a video beat

Most of the session is *build, measure, correct*. This one is different: the thing that had been working stops, and the fix is not a repair but a **narrowing**. Four questions, each eliminating a possibility, until only one thing could be true. The payoff is that everything returns simultaneously rather than one panel at a time.

**Do not stage it in the edit.** The now-playing box appearing while the panels stayed dark is real — a fragment coming back mid-diagnosis, then the screen still dark, then all of it at once. That is what debugging actually looks like, and it is better than a clean build precisely because nobody arranged it.

---

## Act 16 — Mega-view, saved views, and the last mile

**MEGA layout.** All twelve panels at once, six across, two rows. Steps down to four columns under 1400px and three under 900px rather than shattering. It is now an entry in the `layout` dropdown, not something set imperatively — the first version was applied by hand and could not be got back, which is its own small lesson about state that lives only in a function call.

**Saved views.** A view is the whole arrangement, not just the panel list: which panels, column count, sidebar state, density, theme, and which panels are folded. Named, saved to `localStorage`, exportable as JSON so a layout can travel between machines.

**Collapsible panels.** A `▾` on each folds it against its neighbours; which are folded persists by panel id.

**Now playing, bottom right.** Track, BPM, key, energy, progress, and what is queued next. Dismissable, and restorable from the transport.

**Help moved onto the panel name.** A `?` on every panel was visual noise once there were twelve of them. The panel title now carries a dotted underline on hover and opens the same explanation card. Fewer affordances, same information.

**Two spectrogram passes, both wrong before the third.** The first read as printer static. The second — dB scale, octave axis — read as a solid block, because a −62 dB floor mapped the median to 0.84. Only after printing the actual percentile distribution (p10 −23 dB, median −10 dB, peak −3.7 dB) did the third version get a floor and gamma that spread the range. **Same lesson as the saturation table, learned again on the panel that most needed it.**

**The polygraph is the twelfth panel** and it answered two questions at once — the keeper asked for a lie-detector-looking thing and for ideas for a twelfth. A polygraph is a multi-channel strip chart, five pens on ruled paper, and every channel here is a real signal: bass, mid, high, spectral flux, stereo width.

---

## Act 17 — The wiring pass

The gap between *the code is saved* and *it runs*.

Every mixin existed in the package — `DWDASH.slots`, `DWDASH.folds`, `DWDASH.views`, `DWDASH.glossary` — and **`mount()` called none of them.** A fresh `index.html` load would have produced panels, no view selector, no fold controls, no help cards, and no now-playing card. All the code, none of the behaviour.

It was caught only because it was written into `STATE` as an outstanding item during a save, having already been lost track of once. **The note was the mechanism, not the memory.**

`mount()` now builds a single `dash` object and hands it to each mixin in order, then starts the loop, then builds the transport last — because half the controls drive the mixins and cannot be built before they exist.

Four modules were promoted from patches into the package proper: FLAC tag reading, the now-playing card, the render loop, and the spectrogram device-pixel fix. The loop in particular is now started **once**, from `mount()`, never wrapped.

### The load order matters and is not arbitrary

```
deckwave.js         engine — corpus, sequencer, player
deckwave-score.js   the portable mix score
deckwave-listen.js  tab capture, VU ballistics, stereo, register colour
deckwave-panels.js  the panel registry — twelve mega panels plus three extras
deckwave-visuals.js standalone visual widget (optional)
deckwave-tags.js    FLAC VORBIS_COMMENT reader
deckwave-nowplaying.js
deckwave-loop.js    the single render loop
deckwave-dashboard.js  mount() — wires all of the above
patch-01-spectrogram.js  loads LAST, replaces the registered panel
```

Patches load last by design: each replaces or adds exactly one thing, and loading them after the module they amend is what makes them droppable without editing the module.

### What this act is really about

**A saved file is not a shipped feature.** The zip had been "complete" for several turns while being unable to run. The only reason it did not ship that way was a line written into a state file by an instance that knew it was deep enough into a long context to forget.

---

## Act 18 — Four bad diagnostics, and the glossary

### The diagnostics that lied

The keeper reported the spectrogram looked wrong. Three tests said so; all three were measuring the wrong thing.

**Test one** sampled four points along a single horizontal row and found them identical and unchanging. Verdict: frozen. **But a spectrogram row IS one frequency over time** — steady music gives a steady row. The test was correct and meaningless.

**Test two** wrote the verdict string `now[0] > 10 ? 'history filling — scroll works'`, which does not test scrolling at all. It reported success while comparing nothing.

**Test three** probed the input and found it healthy — min 0, max 174, real variation. Which finally made it obvious the problem was in the test, not the panel.

**Test four**, sampling *vertically*, returned four distinct colours down the column. **The spectrogram had been working the whole time.**

Add the earlier `ctx: none` false alarm — a getter that does not exist on this build, read as "the audio context is closed" — and that is **four diagnostics in one session that produced confident wrong answers.**

> **The general form, and it is the same failure as every saturation bug one level up: an instrument that does not measure the thing you are asking about will still return a number, and the number will look like an answer.**

The correction is not "test more." It is: **before trusting a diagnostic, state what would falsify it.** A test whose pass condition does not exclude the failure mode is decoration.

### The glossary, and why the tooltips kept vanishing

Panel help cards disappeared twice. Both times the cause was identical: help was added by **patching slot construction**, so any rebuild — `reset`, `mega`, a layout change — recreated the cells without it.

The third fix is not a better patch. **Terms now live in `DWMSG` as data, and elements carry `data-gl="key"`.** Rebuilding re-tags rather than re-creates. Nothing can be dropped because nothing was ever stored in the DOM.

**32 terms**, each explaining what the word means *in this application* rather than in general — crossfade, downbeat, bass swap, spectral flux, Camelot, phase correlation, LUFS, stretch gate, rolling tempo target. Wikipedia links carry the verified/unverified split, same discipline as before.

One popup element is reused and repositioned rather than one per term: with twelve panels and a dozen header fields, that is 1 node instead of 40.

### Translation-readiness came free

Separating strings into `terms` and `ui` to build the glossary made the app translatable as a side effect. `DWMSG.exportJSON()` emits **flat key/value JSON** — the shape translatewiki.net and Weblate both expect — with term titles and descriptions as distinct keys so a translator sees them separately. `DWMSG.use(catalogue)` swaps a language at runtime.

**Honest note on venue:** translatewiki.net principally serves the MediaWiki ecosystem and accepts projects by request. **Weblate is the likelier home** for a project this size and reads the same format.

---

## Act 19 — The panels that starved themselves

The keeper watched the orbiting planets in the Camelot wheel and asked whether
they could follow the music's tempo. They could. One revolution per bar, four
beats to the bar, the same 4/4 assumption the rest of the engine makes.

The keeper's reply to the result:

> *"You made an orbit dependent on a framerate. Well, I guess we've been in
> chiptune mode all week, huh?"*

Correct, and entirely self-inflicted: the sprite advanced by a fixed step
**per frame** rather than per second, so it ran at whatever rate the display
happened to be running at. The fix was a `dwpDT()` helper returning real
elapsed seconds.

**That fix broke two other panels the same night, and it took a proper
measurement to see it.**

`dwpDT()` kept a single module-level `lastT`, and by then three things called
it every frame. Whoever drew first took the real elapsed time and reset the
clock; every later caller in that frame received about 0.3 milliseconds. The
sprite drew before the two history panels, so their shared buffer accumulated
at roughly 2% of real time, never reached its 0.1s step, never pushed a
sample, and both panels took their `n < 2` placeholder branch on every single
frame. They drew the word *building…* forever.

The keeper said only *"I don't know if those are working."* They were not.

**The check that found it, and the check that would not have.** Counting lit
pixels returned 14,925 — axis lines, labels and a placeholder string are all
non-background pixels. That is the same class of test that lied four times in
Act 18. The differential render — draw, wait 2.5 seconds of live audio, draw
again, diff only the plot area — returned **zero changed pixels**, against
`loudness` and `polygraph` moving on the same bundle. After the fix, 10,315.

> **A panel that renders a placeholder is indistinguishable from a panel that
> renders, if your instrument only asks whether anything was drawn.**

`dwpDT(key)` now keeps a last-time per caller, and the history buffer owns its
own clock rather than being handed one — two panels feed it in the same frame
and neither is in a position to know the correct interval.

### Making the buffer observable

The reason that bug shipped is that nothing outside could ask the buffer what
it held. `DWPANELS.hist()` now reports point count, span, oldest, newest and
whether it has begun scrolling. Same instinct as the `DW._dev` seam: **a
component with no way to report its own state can only be debugged by guessing
at pixels.**

It paid for itself immediately. When the keeper asked for the window to drop
from two minutes to sixty seconds, the rollover was verified as numbers —
600/600 points, span pinned at 59.91s, oldest advancing 9.94 → 11.54 — rather
than by staring at an axis label. Sample rate measured exactly 10Hz:
121/241/361/481 points at 12/24/36/48 seconds.

### loudtime

A third history panel: loudness alone, no band lines competing for the height.
Filled area is the VU average on 300ms ballistics; the thin line above is the
PPM peak on a 5ms attack. **The gap between them is crest factor by eye.**

Its vertical axis is deliberately unlabelled. It is a normalised VU scale
aligned to −6 dBFS, and that alignment is a choice made in this project, not a
standard. Printing decibel figures against it would lend a chosen number the
authority of a measured one — the exact move behind three saturation failures
already.

---

## Act 20 — Everything the grid was quietly eating

Two defects found from one screenshot, neither reported as a bug.

**The swap menu could not be scrolled to its last entries.** The keeper
mentioned it in passing. `.pmenu` was absolutely positioned inside its cell,
and `.tri` carries `overflow:hidden`: on the bottom row the menu was 428px
tall running to y=834 while the grid ended at y=645, so **189 pixels of it
were cut off and unreachable**. Its own `max-height:60vh` could not help,
because 60vh *is* 428px — taller than the space below the button — leaving the
internal scrollbar 11px of slack against 189px of hidden content.

The clipping had always been there. Three panels added that night took the
list from 13 entries to 16, which is what finally pushed it past the edge.

Verified by hit-testing rather than by inspection: for all twelve slots, open
the popup, scroll it to the bottom, and confirm `shadowRoot.elementFromPoint`
at the centre of the *last* entry returns that entry. **Checking the element
existed in the DOM would have passed before the fix too** — it did exist, it
was underneath the clip.

**Every page load was deleting the saved panel layout.** Found while checking
why one screenshot showed different panels than the one before it. Startup
calls `autoLayout(true)` → `DWDASH.mega()` → `slots.reset(ALL)`, and `reset()`
does a `localStorage.removeItem` *before* rebuilding. The arrangement was not
ignored on load; it was destroyed by it. Fold state went the same way.

The comment directly above `autoLayout` already argued that changing panels
unbidden would be hostile. It was happening on every load.

The keeper, on being told:

> *"i've just been manually changing them each time"*

**Nobody had reported it, because it had always been that way.** A defect that
predates every user of a feature reads as the design.

A theme called `stargaze` was added the same night, named for the track that
was playing when the history panels were first watched against real audio. Its
two accents sit far apart in hue — pale gold against ice blue — because
`loudtime` draws its average and its peak in exactly those two, and on heavily
limited material the traces converge. Close hues would render a squashed
passage as one thick line instead of two lines meeting, losing the reading the
panel exists to show.

---

## Act 21 — DJ Half-Tune

The keeper asked for a filling bar on the now-playing card with a mark showing
where the transition lands, and asked whether that mark could move when a
blend-now was chosen. It could — but only if it read the **schedule** rather
than recomputing from track length, because `chain()` snaps the exit to a
downbeat and `blendNow()` rewrites the exit outright.

So `DW.blend` was exposed, reading `A.outAt` — the same value the gain ramps
are scheduled against.

**Then the mark was drawn on the bar, and it sat at 30%.**

The track was 390 seconds long. The blend was scheduled at 119.6.

### The wall at 120 seconds

A scan of the entire analysis cache, 219 records, needing no decoding at all
because beat grids and durations were already stored:

| Measure | Value |
|---|---|
| Tracks longer than 120s | 212 of 219 |
| **Latest beat anywhere in the library** | **119.9s** |
| Median grid coverage of those tracks | 60.6% |
| Tracks exiting more than 20s early | 188 |
| **Music that never played** | **236.7 minutes** |
| Tracks reaching the 900-beat storage cap | 0 |

Not a distribution with a tail. **A wall.**

`analyse()` read a *centred 120-second excerpt* — deliberate, documented, and
discarding the buffer was the stated point. What was never reconciled is that
Essentia returns tick times relative to the signal it is handed, and those
excerpt-relative times were stored and then consumed as absolute positions in
the file.

**One mistake, two symptoms, both silent:**

1. **Coverage.** No grid reached past 120s. `downbeatNear()` has no way to say
   *I have nothing near the exit*, so it returned the last downbeat it held
   and the deck blended there. Worst case: *GONE TOO SOON*, 507 seconds long,
   last beat at 119.2, exiting **371.8 seconds early**. Six minutes of an
   eight-and-a-half minute track never played. The worst offender in a
   219-track library is called *Gone Too Soon*, and nobody wrote it that way.
2. **Phase.** `entry = beats[0]`, and `chain()` starts the incoming deck at
   that offset *on the outgoing deck's downbeat*. **That is the beat
   alignment.** An excerpt-relative `beats[0]` is a beat from the middle of a
   track applied near its start, so the incoming track entered at an arbitrary
   phase and its kicks landed beside the outgoing track's.

### The measurement I could not make, and the one the keeper could

The keeper reported popping on the beats. The first investigation measured the
graph properly and found the master clean — 11 clipped samples in 493,568 —
then measured the decoded source and found the *playing* track carrying 100
clipping events per second while the *queued* track carried exactly zero. That
conclusion was right for that track: the file was clipped, and VLC confirmed
it.

It was also the wrong general answer, and the keeper is what found that:

> *"I checked Big In Japan in VLC and it doesn't have the popping. But it has
> it playing from Deckwave. And it isn't popping when I jump directly to it."*

Clean in another player, clean when played alone, popping only through a mix.
That triangulates precisely onto phase: **played alone there is nothing to
flam against.**

> **CONFOUNDED, 2026-08-18. This inference had a second explanation nobody
> controlled for, and it was never ruled out.**
>
> `play()` builds the first deck at `rate = 1`, and `jump()` calls `play()` —
> so *played alone* and *jumped directly to* are BOTH unstretched. Only a
> chained deck gets `rate = tempo / bpm`. So "clean alone, pops through a mix"
> separates unstretched from stretched exactly as well as it separates one
> deck from two.
>
> And the stretched path drops samples. Measured on the vendored SoundTouchJS
> worklet v0.3.0, driven offline with 128-frame quanta: at `tempo = 1.00`,
> **0 gaps/sec**; at `tempo = 1.08`, **10 gaps/sec and 7.3% of output frames
> silent**. `process()` pushes 128 frames in, assumes 128 come back, and writes
> whatever `receiveSamples` failed to fill — a fresh zero-filled array — straight
> to the output. It cannot even detect this: `receiveSamples` returns
> `undefined` in that build.
>
> The keeper confirmed the pattern independently on 2026-08-18: *"I don't think
> we've ever had ticking on the first track or a jumped-directly-to-track. as
> soon as I blended it to a new track, popping."* First track and jumped track
> are the two rate-1.0 cases.
>
> **What this does and does not overturn.** The COVERAGE half of D5 was measured
> against the cache, not inferred from this A/B, and stands untouched — 119.9s
> was real. What is now unsupported is the claim that this A/B *established*
> a phase defect. It is equally consistent with the dropout mechanism, so it
> discriminates nothing.
>
> **The falsifier, and it is cheap once the worklet is fixed:** if the popping
> through a mix disappears entirely with a non-dropping worklet, phase was never
> audible here. If a doubled-attack flam survives, phase is still live and now
> has a clean test at last.
>
> The lesson is the one this project keeps relearning, one level up from the
> usual: the diagnostic was the keeper's ear, the ear was right about *what it
> heard*, and the error was in the inference drawn from it. An A/B only
> isolates a variable if nothing else changed with it — and here the stretch
> rate changed with it, silently.

Three attempts to measure that phase directly had already failed, and all
three are recorded here so that nobody repeats them:

| Attempt | Why it was worthless |
|---|---|
| Onset matching, ±0.5s tolerance | 1,222 onsets against 174 beats — 0.17s average spacing. *Every* candidate phase matched. Passed at offset 0 and at the excerpt offset equally |
| Top-N onsets by magnitude | All picks clustered in the loudest section, covering none of the timeline. Cost pinned at the clamp ceiling for every phase |
| Comb filter over the beat grid | Best phase landed at 0.29s against a 0.5967s period — half a period, exactly the ambiguity a comb cannot resolve. Contrast 1.63 |

> **Three more diagnostics returning confident numbers about nothing. Same
> family as Act 18's four. An instrument that does not measure the thing you
> asked about will still return an answer.**

The keeper's A/B settled in one sentence what three measurements could not.
**An ear is an instrument, and on this question it had better resolution than
anything built for it.**

### The fix

`RhythmExtractor2013` now runs on a mono mixdown of the **whole track**, so
ticks are relative to the start of the file — what every consumer already
assumed. Key, `kstr`, `rms` and `zcr` still read the centred excerpt
deliberately: they are not implicated, their values are calibrated, and the
energy index is built from `rms`.

**BPM and confidence change for every track** — the same detector reading more
signal. Unavoidable, and the reason `ANALYSIS_V` exists: records are keyed by
`name|size|mtime`, which cannot know that *our* analysis changed, so v1
records would have been reused forever.

The beat cap went 900 → 4000. It bounded the cache, and against a 120-second
excerpt nothing ever came close — **0 of 219 records reached it.** A
whole-track grid does: 507s at 100bpm is ~845 beats. The old cap would have
quietly reintroduced the very truncation the change exists to remove.

### The evidence

The pre-fix cache was exported before any re-scan could overwrite a record,
because re-running the analyser now writes v2 and that state cannot be
regenerated. 219 records, all v1, in `evidence/`.

> **The instrument you build to show one thing will show you things you did not
> intend. The transition mark was a cosmetic request. It found four hours of
> music that had never been played.**

The keeper named the failure mode, and it is going in the history books:

> *"people won't want their songs cutting off too early. I had a friend like
> that. We called him DJ Half-Tune."*

## Act 22 — The re-scan, and what the whole track had to say

179 tracks re-analysed at `ANALYSIS_V = 2`, 2026-08-18. Zero failures. This is
the run Act 21 wrote the cheque for.

### Running it without the folder picker

`showDirectoryPicker` is a native OS dialog. Nothing inside the browser can
open it and nothing outside the browser can answer it, so a scan cannot be
started except by a person clicking. The analyser itself does not care: it
takes a `File`. So the files were served over a second loopback port and the
`File` objects built from the bytes, with `lastModified` set to the real disk
mtime.

**The falsifier for "this is the same thing a folder pick would do" is the
record id, and it is a clean one.** Records are keyed `name|size|lastModified`.
If the constructed ids were wrong in any way the store would have grown from
219 records to 398, because 179 new keys would have been added beside the old
ones. **It stayed at 219.** All 179 overwrote their own v1 record in place, so
the ids are byte-identical to ids that a real folder pick produced. The
keeper's own SCAN will read these as cache hits.

Two mtimes were checked against the v1 cache before the run as well: 185 of
185 matched exactly.

### Cost — it was never going to be the problem

| | |
|---|---|
| Tracks | 179 |
| Audio | 601.8 minutes (10.0 hours) |
| Analysis wall clock | **718s — 12.0 minutes** |
| Per track | mean 4.01s, median 3.88s, worst 9.70s |
| Per second of audio | **19.9 ms — about 50x faster than realtime** |

The projection asked for from the first three tracks was 21.2 ms per audio
second, giving 12.8 minutes. The actual figure was 12.0. **The three-track
projection was 6.6% high**, which is the useful part: cost here is very nearly
linear in duration, so three tracks really do predict 179.

Two costs are NOT in that number and both favour the real scan being slower,
not faster: the harness held its bytes in memory, so no disk read is inside
the measured window, and `walk()` over the tree is not counted.

### Peak memory — measured from outside, because nothing inside could see it

Neither the decoded `AudioBuffer` nor the Essentia WASM heap lives on the V8
heap, so `performance.memory` cannot see either — it is reported in the run
log and it is not the number used. Worse, `RhythmExtractor2013` blocks the main
thread for seconds at a time, so nothing running *in* the page can sample a
peak while the peak is happening. The renderer process working set was sampled
from outside the browser instead, every 250ms, and the renderer identified by
which process grew — "a chrome process got bigger" is not evidence about this
page.

| | |
|---|---|
| Idle baseline | 74 MB |
| **Peak working set** | **851 MB** |
| Peak private bytes | 941 MB |
| Median across the pass | 642 MB |

**The question four tracks could not answer was whether that plateaus or
climbs**, and it is the question that decides whether a 179-track pass
survives. Peak by quarter of the run: **833, 851, 820, 821 MB.** Flat. The
ceiling is set by the single longest track and 175 further tracks did not move
it. Memory is bounded by the longest file in the library, not by the size of
the library.

Worth knowing anyway: the working set never returns to baseline between
tracks, because the WASM heap only ever grows. A library holding a 15-minute
track would peak proportionally higher, and that is a prediction, not a
measurement.

### The grid now reaches the end of the track

| | v1 | v2 |
|---|---|---|
| Latest beat anywhere in the library | 119.9s | **506.23s** (of a 507.0s track) |
| Median grid coverage | 60.6% | **99.71%** |
| Worst grid coverage | 23.5% | **99.18%** |
| Tracks with an empty grid | — | 0 of 179 |
| Largest grid | 278 beats | 1044 beats |

Every one of the 179 covers at least 99% of its track. The largest remaining
shortfall is **0.97 seconds**, median 0.58s — under one beat period, which is
what "the last beat lands before the last sample" looks like.

Four grids still end before 121s. All four are tracks *shorter* than 121s, at
99.2–99.6% coverage. That distinction matters: the old symptom was a grid
stopping at 120s regardless of duration, and it is gone.

**Exactly one track passed the old 900-beat cap** — GONE TOO SOON, at 1044.
So the cap raise was load-bearing for one file in the library, and the new
4000 is not approached by anything.

### What the extra signal cost, and it is not nothing

BPM barely moved: median absolute change **0.06 bpm**, and 80 of 175 changed
by less than 0.05. Seven moved more than 2 bpm.

**Three of those are octave flips, and the grid doubled with them** — checked
by deriving tempo from beat spacing rather than trusting the reported figure,
which is the only way to tell "the label changed" from "the grid changed".

| Track | v1 | v2 |
|---|---|---|
| CyberChip — 01 Perpetual Motion | 93.99 | 184.57 |
| BETTER THAN REALITY — 06 PROXIMA | 90.01 | 178.21 |
| Galaxy | 80.87 | 162.09 |

All three still pass the confidence gate, so all three will enter a set at
double tempo, against neighbours chosen for a tempo they no longer have.
**This is a decision, not a bug to be reasoned away** — nothing here should
move without the keeper hearing it.

Confidence fell almost everywhere: **median 2.181 → 1.783**, down on 156 of
175, up on 15. On the Essentia 0–5.32 scale, which is not comparable to any
other detector's number. The consequence is the gate: tracks passing
`conf > 0.8` went **170 → 160**. Ten tracks left the pool. Per the standing
rule that is the gate working, and the ten are named in the run log.

### What was not established

- **Phase is still not confirmed.** `beats[0]` is now a real beat near the
  start of every file, which is the mechanism, but the symptom was audible and
  so is the confirmation. It needs the keeper's ear against a mix.
- **`downbeatNear()` still cannot refuse.** With 99%+ coverage it should stop
  mattering; it is still unable to say *I have nothing near there*.
- **40 records in the store are still v1** — the mp3s and a handful of others
  that live outside the scanned folder. They keep excerpt-relative grids.

---

## Act 24 — The fourth time an intention was recorded and never read

The keeper's report was three sentences and all three were load-bearing:

> yes it's filling · yes, the tooltips follow the tiles · **i still do not
> think quick blend is actually doing anything** … in my mind it should start
> immediately going through about 6 songs to get to the right one with a
> different energy. but it just seems to sit there. **is there a tile that
> shows re-routing?** maybe that would help me diagnose when things are not
> doing what you think they should be.

The first two confirm ledger 34 and 37 — both flip to **[CONFIRMED]**. The
third was right, and the fourth is the correction to how this keeps happening.

### The bug, and why ledger 38 did not fix it

Patch 09's opening comment describes the failure as if it were finished:

> The queue was populated the whole time and NOTHING IN THE PLAYBACK PATH EVER
> READ IT. The feature recorded intentions and discarded them.

Patch 09 fixed that by splicing the route into the SET, so the player would
walk it by construction. Ledger 38 found the same shape one layer up — the
per-stone dwell computed, printed, and dropped by `commit()` — and fixed it.

Both fixes were correct. Both were downstream of the actual break:

    function applyRoute(entry, label) {
      const r = N.commitAndRepair(set);
      dash.set = r.set;                 // <- and nothing else
    }

`commitAndRepair` returns a **new array** — `commit()` starts with
`set.slice()` and `resequenceTail()` ends with `head.concat(out)`.
`Player.play(seq)` had done `order = seq`, capturing the array it was given
when playback started. There was no API to hand it a different one. So
`dash.set` and `order` became two arrays: one with the detour spliced in and
re-sequenced, one without, and the deck read the second.

Every other steering operation had got this right by accident. `blendNow()`
and `queueNext()` both go through `placeNext()`, which *mutates in place* —
and the dashboard comment says exactly why:

> Both of these mutate the play order IN PLACE inside the Player, and the
> dashboard's `set` is that same array — so the list follows without being
> reassigned. **Reassigning would desync the two silently.**

The comment naming the hazard is four lines above the line that does it.
That is ledger 39's lesson again: a warning only works if it is read at the
moment of the edit.

### Why nothing looked wrong

Both halves stayed internally consistent. The list re-rendered with the
stepping stones in it. `state.idx` kept advancing. The now-playing bar kept
filling. Nothing threw. The only observable was the audio, and the audio was
the one thing no instrument here was reading.

Worse, the one tile that *could* have shown a route was blinded by design.
`commitAndRepair()` ends with `clearQueue()` — correct, the intention has
become the set — and the wayposts panel draws `DWNAV.queue`. So the dashed
spiral through the wayposts disappeared at the instant the route committed.
The keeper watched a detour start and saw the display go back to "no
destination". Ledger 41.

### The fix, and the falsifier that now lives on screen

`DW.reorder(seq, opts)` **adopts** the caller's array rather than copying into
its own — a copy would leave two equal-but-separate arrays and put the desync
straight back. It refuses when `seq[idx]` is not the playing track, because
that is the ledger-33 failure (position and deck naming different tracks) and
it should be a refusal, not a repair. Then it cancels the pending blend and
re-chains, because `chain()` commits the next deck the moment a track starts
and that choice predates the route.

`opts.now` is what separates the two menu entries, and it is what the keeper
was actually asking for. **Blend fast** now leaves the current track at the
next downbeat — *"in my mind it should start immediately"* — while **scenic
route** still lets it finish. Before this, both waited out the current track
in full *and then* walked a route the deck could not see.

The check that would have caught all of it is one line, and the new `route`
panel draws it in red when it fails:

    D.set[state.idx] === DW.nowMeta

Identity, not the name string. Under the bug the names still matched for a
while — the detour is spliced *after* the current track — so a name comparison
would have passed for exactly as long as it took to stop being interesting.

### The keeper found the other half of it while I was writing this

An hour after the first report:

> hmmmmmmmm wait a minute. maybe it IS routing. but it's not updating the live
> playlist like i expected it would. **because we are not on demoscene right
> now.**

That is the same bug seen from the other side, and it is better evidence than
anything in the harness. The route DID reach the list — `dash.set = r.set`
re-rendered it with the stepping stones spliced in. What did not follow was the
deck. So one handover after a commit the list advances to the first stone while
the deck advances to the *old* next track, and from then on the panel names one
track and the speakers play another.

`commit()` preserves index `at`, so the highlight stays correct for exactly as
long as the current track lasts. It goes wrong at the first blend — which is
why it reads as "it did nothing" at first and "it is showing the wrong song"
a few minutes later.

**Two displays were reading the list's opinion rather than the deck's**, and
both are now fixed to ask the deck:

- `deckwave-nowplaying.js` took `S[st.idx]`. It now prefers `DW.nowMeta`, the
  meta object on the playing deck, which cannot be wrong about what is
  audible.
- `renderList()` marked `.now` by index. It now finds the playing track by
  identity and marks that row, and says so in the side header when the playing
  track is not in the list at all.

This is ledger 33 again — *"now playing says Druid II"* while Big In Japan
played — and the correction is the same one, applied to the two places that
still derived the answer instead of asking for it. **The rule this keeps
teaching: when a component can be told the truth, do not let it infer the
truth.** `DWPANELS.hist()`, `DW._dev`, `DW.blend` and now `DW.nowMeta` all
exist for that reason.

### The stepping stones are longer than advertised

Ledger 42. The menu printed the router's requested dwell; `chain()` clamps
every stone to a floor that was written inline as a bare `45`. Both numbers
are chosen, D7 says so, and neither has moved. What changed is that the floor
is now named `MIN_PLAY`, exposed as `DW.dwellFloor`, and quoted by the two
places that used to quote the other number.

Measured on the real corpus, from 130 bpm to a 151 bpm destination: 4 stones,
**3.0 minutes**, not the 2.7 the menu claimed.

### Settling a stretched deck — built, off, unheard

The keeper, mid-session: *"if i make a bad blend we need to eventually speed
it back to the song's normal speed."*

That is a real gap. A forced blend leaves the incoming deck stretched for its
whole length — force +14% and the track is 14% fast until it ends. The DJ
answer is to ride the pitch fader back.

**The obstacle was structural, not musical.** Every beat-to-wall-clock
conversion in the engine was `* (1 / rate)`, which is true only while the rate
never changes. Three of them: the exit chosen in `chain()`, the downbeat found
by `nextDownbeatAfter()`, and the track length in the `blend` accessor. A ramp
makes all three wrong.

So the deck now carries a map instead of a divisor — `pos(t)` integrates the
rate, `when(p)` inverts it — and with no ramp scheduled both reduce to exactly
the old arithmetic. That equivalence is checked, not assumed:
`tools/check-route.js` asserts `pos(t) === t * rate` and `when(p) === p / rate`
**exactly**, for five rates across 400 seconds, and `|when(pos(t)) - t| < 1e-9`
under ramps in both directions (worst observed 1.2e-13 s).

It is **off by default** and there is a toggle in the transport that says so.
Turning it on changes more than one track: a settled deck hands over at its own
BPM instead of at the 35%-drift target, so the rolling tempo becomes the
current track's BPM and every gate test downstream is measured from somewhere
else. That is a musical change, and 45 seconds is a chosen number. It has not
been heard.

### What the harness does and does not establish

`tools/check-route.js` runs 15 checks against the real 189-track chiptune
corpus and the real cache, with a falsifier printed beside each. It builds a
set with the actual `sequence()`, finds the destination needing the most hops,
commits a fast route, and asserts the splice, the dwell stamping, the gate, and
that `commitAndRepair` returns a different array — the last of those being the
mechanism of the bug, so if it ever passes trivially the diagnosis was wrong.

It does **not** touch audio. It cannot: the whole failure was that a correct
data structure was not being played. The route panel rendered correctly against
real records in-browser and threw nothing. **Whether a fast blend now sounds
like a fast blend is the keeper's to say**, and the stated tell is a stepping
stone leaving after about 45 seconds instead of playing out.

---

## Act 25 — The gate was measuring the wrong thing, and the docs already said so

The keeper, on being shown the ten tracks the sequencer had dropped:

> yes I want all those songs back. Are you saying they were way outside the
> realm or something? **Ideally you wouldn't discard any of the songs that
> people have put in. maybe we find a way to gracefully still reach them.**

### The measurement, and it is not close

The sequencer excluded anything with `conf <= 0.8` — Essentia's `RhythmExtractor2013`
confidence, the agreement between five onset-detection functions. The falsifier
for "low confidence means a bad grid" is cheap: **if the grid were wrong, the
measured beat spacing would disagree with the declared tempo.**

| conf | declared | grid says | error | |
|---|---|---|---|---|
| 0.72 | 107.44 | 107.43 | **0.01%** | Neon Thrills — *refused* |
| 0.78 | 131.76 | 130.86 | **0.68%** | Under Your Skin — *refused* |
| 0.65 | 107.83 | 108.88 | **0.97%** | Magic Gateway ×2 — *refused* |
| 1.35 | 84.99 | 94.44 | **11.04%** | Timeless — *admitted* |
| 2.07 | 140.14 | 130.33 | **7.00%** | Beginning Of Anxiety — *admitted* |

Five of the ten refused tracks were metronomic. **42 of the 164 admitted
tracks have worse than 1% grid error, up to 11%.** The gate had it backwards,
and SKILL.md had already written down why: *"Beat detection on chiptune is
unstudied. Treat low-confidence results on that material as expected, not as
a bug."* We gated on the number the documentation warns about.

### The number that actually costs something

The engine stretches by `tempo / meta.bpm` — the DECLARED tempo — while the
beats it aligns to come from `meta.beats`. If those disagree by 6%, the
transition is 6% out no matter how good the crossfade is. **Grid error IS
beatmatch error.** That is why it belongs in the gate and confidence does not:
one is a property of the mix, the other is a detector's opinion of itself.

Deliberately not octave-aware. Comparing against `bpm/2` and `bpm*2` and
taking the best would hide exactly the half-time and double-time disagreements
this is meant to surface.

### The one threshold here that was derived rather than chosen

Over all 179 rescanned tracks the distribution of grid error has **an empty
band: nothing at all between 7.50% and 11.04%.** Every cut inside that band
selects the identical five tracks, so the choice is insensitive across three
and a half points. 9 sits in the middle, furthest from both edges.

This is what the project has been asking for since the first calibration
failure — a threshold picked from where the data separates rather than from
where a number felt right.

**And it is still not settled.** The other defensible answer is about 3%: grid
error adds to the stretch budget, we already refuse 8% of stretch because it
wobbles, so tolerating 9% of grid error on top of it is generous. That cut
plays 22 tracks straight instead of 5. Both are arguments and neither is an
ear. `DW.lock.maxGridErrPct` is live; move it, rebuild, listen.

### Not excluding is not the same as pretending

A track that cannot be trusted is not thrown away and it is not quietly mixed
either. It plays **straight** — its own speed, no stretch, no claim of a
beatmatch — which is what a DJ does with a record that will not grid. The list
marks it, the route panel says `∿ grid` instead of a stretch percentage, and
`inspect()` counts it separately, because printing `0.0%` against an unmatched
transition would make it look like the best one on screen.

### The half I did not fix, caught by the check that asks the question directly

The new harness asks one thing plainly: *is anything still discarded?* It said
**64 of 171 never placed.**

Recovering the confidence-gated ten had done nothing about the STRETCH gate,
which drops far more. The greedy walk ends when nothing remains within 8% of
the rolling tempo, and I had assumed the handful of unlocked tracks would keep
it alive. There were five of them.

So there are two ways to be unlocked, and they are opposites:

- **grid** — we do not believe its BPM, so it plays straight AND DOES NOT
  STEER. Letting a bad grid drift the rolling target spreads one bad number
  across every transition after it. A parenthesis in the set.
- **reach** — its grid is fine, we simply could not stretch to it. It plays
  straight and **then repositions the set to its own tempo**, because its
  tempo is trustworthy and moving the set is the entire reason for playing it.
  Locked mixing resumes on the very next track.

That second case is a DJ dropping one in clean when the floor has walked away
from the record box. It is also the difference between a set that ends at 107
and one that plays the library: **171 of 171 placed, 9 of them straight — 5
untrusted grids and 4 out of reach. 162 still fully beatmatched.**

### What the harness establishes, and one thing to watch

`tools/check-pool.js`, eight checks, each printing its falsifier: the two
gates rank tracks differently (5/10 overlap, so swapping them buys something);
every locked track is still inside the 8% budget; no unlocked track is
stretched; a grid-unlocked track never moves the tempo target; a reach-unlocked
one always does.

Two of its checks failed on first run and both were real — one a genuine gap
in the design, one a bug in the harness itself. **`sequence()` stamps `_stretch`
and `_tempoAt` on the shared corpus objects, so calling it twice restamps the
first set's tracks** and every assertion afterwards reads the wrong build. That
hazard is live in the app too: build twice and the earlier set's rows are
rewritten underneath it. `commit()` already has to `delete out[i]._dwell` for
exactly this reason. Not fixed here; written down.

### And then the other harness caught the same half-a-fix again

`tools/check-route.js` builds a set, commits a 15-hop route and re-plans the
tail. It reported **35 tracks dropped** — because `resequenceTail()` had its
own copy of `if (!ok.length) break;`. The no-discard promise held for BUILDING
a set and silently did not hold for REPAIRING one after a detour.

That is ledger 45 twice in one session: fix the mechanism you were looking at,
miss the identical mechanism one file over. The correction is not a better
rule, it is the harness — both times the check that asked *"is anything still
discarded?"* answered in seconds.

Fixing it broke `DWNAV.verify()`, which then reported **11 transitions over the
gate, max stretch 94.6%**. Every one of those numbers was correctly computed
and none of them measured anything real: a track played straight is not
stretched, so a stretch figure against it describes an event that does not
happen. verify() now models the two straight modes the way playback does — a
reach track repositions the target to its own BPM, a grid track moves it
nowhere. After the fix: 162 kept, 0 dropped, 4 straight, max stretch 8%.

**The thing to listen for:** the four reach transitions are big — 167 → 100 bpm
in one case, 140 → 172 in another. They are honest, and they are abrupt.
Smoothing them is what routing to the tail with stepping stones would do, and
that option is still on the table.

