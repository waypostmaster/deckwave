# Deckwave

**Version 0.7.0 · 2026-08-18**

Analyse your whole local music library in the browser, build a beat-locked harmonically-mixed DJ set from it, and save the mix as data rather than audio.

Nothing is uploaded. Files are read through a folder you pick, analysed locally, and the audio buffers are discarded immediately. The only things that persist are a few hundred bytes of features per track, in your own browser's storage.

**Chromium only** — `showDirectoryPicker` is not implemented in Firefox or Safari.

---

## What it does

**Analyses a corpus.** One folder pick walks the whole tree. Each track is decoded, measured **whole** with Essentia.js for tempo, beat grid, key and confidence, and the buffer released. (Through 0.5.0 only a 120-second excerpt was measured, and the grid it produced was stored as if absolute — so anything past two minutes had no beats at all.) Results cache to IndexedDB, so a rescan after adding music only pays for the new files. 364 tracks fit comfortably.

**Sequences a set.** A rolling tempo target drifts toward each incoming track rather than holding one global BPM, with a hard gate refusing anything needing more than 8% time-stretch. Candidates are scored on Camelot key compatibility, tempo proximity, and distance from an energy arc. **If nothing qualifies, the set ends rather than degrading.**

**Plays it beat-locked.** Each deck runs through a SoundTouch AudioWorklet that matches tempo without changing pitch. Crossfades land on detected downbeats with a three-band bass swap, so only one kick sounds at a time. Tracks decode one ahead and release behind — memory stays flat regardless of set length.

**Shows you what's happening.** Oscilloscope, log-spaced spectrum, chromagram pitch wheel, dual-ring Camelot wheel with the harmonic path drawn, spectral-flux bass onsets, goniometer with phase correlation, VU meters with real 300ms ballistics, and the whole set's energy and tempo arc with a playhead.

**Saves the mix as a score.** ~26KB of JSON describes a 197-minute set: every entry point, tempo multiplier, exit downbeat, crossfade and EQ timing, plus an engine block naming the detector and stretcher. Load it back and the identical set rebuilds. A standard `.cue` comes with it.

**Listens to other things.** Point it at another tab via `getDisplayMedia` and every visual works on Spotify, YouTube, anything — no analysis or mixing, but the instrument runs.

---

## Quick start

```js
await DW.scan(console.log)      // pick a folder, walks the tree, caches
DW.confidence()                 // how much to trust the tempo figures
const set = DW.build({ length: 120 })
DW.inspect(set)                 // READ THIS before playing
await DW.openLibrary()          // re-resolve files for playback
await DW.play(set)
DW.stop()                       // reaches scheduled sources, not just current
```

---

## Read the numbers honestly

`inspect()` returns the figures that decide whether a set is worth playing. **`maxStretchPct` above 15 will audibly wobble** — that is perceptual, not taste. **`keyWeak`** counts clashing transitions.

**Confidence is on Essentia's scale (0–5.32)**, where 1.5–3.5 is moderately confident. It is not comparable to any other detector's number.

**Energy is a constructed index** — 45% loudness, 25% brightness, 30% tempo, normalised across the corpus. It correlates with perceived energy. It is not a measurement, and the weights were chosen rather than fitted.

**When the sequencer returns fewer tracks than asked for, that is the gate working** — though since 0.7.0 it should be rare. A track the stretch gate cannot reach is played straight rather than dropped: its own speed, no stretch, and no claim of a beatmatch. The set marks those, and `inspect()` counts them separately. **A track played straight is not a worse track**; it is one we are not pretending to beatmatch.

---

## Theming

Every colour, font, radius, glow and scanline is a CSS custom property whose *fallback* is the default look. A host page overrides what it likes without forking:

```css
deckwave-app {
  --dw-color-bg: #faf8f3;
  --dw-color-accent: #2a2118;
  --dw-glow: 0;                /* kills the neon */
  --dw-scanline-opacity: 0;    /* kills the CRT */
}
```

Six presets ship in `themes/themes.css`. Structural elements expose `part=` for `::part()` overrides.

---

## Known limits, all real

- **Chromium only.** No `showDirectoryPicker` in Firefox or Safari.
- **No phrase detection.** Transitions land on downbeats, not 8/16/32-bar boundaries. This is the largest quality gap.
- **No downbeat detection.** Every fourth beat is assumed — fine for 4/4 electronic music, wrong elsewhere.
- **Beat detection on chiptune is unstudied.** No published accuracy figures exist for square-wave percussion. Low confidence there is expected.
- **Thresholds were tuned against one artist's catalogue.** They may be wrong for other genres and are untested on live drums or variable tempo.
- **Cross-browser determinism of the score is untested.**
- **Long offline renders may exhaust memory.** `OfflineAudioContext` allocates the whole output up front.

---

## Licence and dependencies

Deckwave is **AGPL-3.0**, because Essentia.js is AGPL-3.0 and this is a combined work.

| Dependency | Licence |
|---|---|
| [Essentia.js](https://github.com/MTG/essentia.js) (MTG–UPF) | AGPL-3.0 — also available commercially |
| [SoundTouchJS AudioWorklet](https://github.com/cutterbl/SoundTouchJS) | MPL-2.0 in current versions — **pin your version** |
| [libflac.js](https://github.com/mmig/libflac.js) | MIT |
| libFLAC (Xiph) | BSD-style |

See `NOTICE`.

## Influences

The visual vocabulary follows **Strudel** (strudel.cc) — scope, spectrum, punchcard, pitchwheel — which is the JavaScript descendant of **TidalCycles** by Alex McLean. Independent implementations built on the Web Audio AnalyserNode; no Strudel code is used or copied. Pointed there by **Switch Angel**'s live-coding work.

VU ballistics follow ANSI C16.5-1942 (300ms to 99% deflection). The goniometer is the classic Lissajous stereo display. The general debt is to **Winamp**, AVS and Milkdrop, and the era when a music player was something you reskinned.

Analysis is **Essentia** (Music Technology Group, Universitat Pompeu Fabra).

## Playing your own music

Files are read locally from a folder you choose. Nothing is uploaded, bundled or fetched. Playing music you own, on your machine, needs no permission.

Rendering a mix to a file is the same act. **Sharing that file is not** — it contains the full recordings. That decision is yours.

---

See `docs/BUILD-LOG.md` for how this was built, failures included.
