#!/usr/bin/env python3
"""Development server for Deckwave.

Deckwave needs a secure context: the File System Access API is unavailable
otherwise, so window.showDirectoryPicker is undefined and the app reports
"unsupported browser". http://localhost counts as secure; a LAN IP does not.
So local runs can be plain HTTP, and LAN runs need TLS.

    python tools/serve.py                     localhost only, HTTP,  port 8777
    python tools/serve.py --lan               all interfaces, HTTPS, port 8443
    python tools/serve.py --lan --port 9000   same, different port
    python tools/serve.py --stop              stop the one already running

Starting it twice is safe: the second invocation notices the first, says so,
and exits 0 rather than failing or — worse, and this is a Windows-specific
trap — binding the same port a second time. See ONE SERVER, below.

--lan requires a certificate. Generate one covering your LAN address, and keep
it OUTSIDE this repository so the private key can never be committed:

    openssl req -x509 -newkey rsa:2048 -nodes -days 825 \
      -keyout ../deckwave-tls/key.pem -out ../deckwave-tls/cert.pem \
      -config ../deckwave-tls/san.cnf

Point --certdir at wherever that lives. Self-signed means one browser warning
per device; proceeding past it makes the origin a real secure context.

WHAT THIS REFUSES TO SERVE
The repository contains its full git history and the original source archives.
Serving the working tree on a network hands both to anyone who finds the port,
which is source disclosure of unpublished work. Dotted paths and _source/ are
blocked here rather than left to the operator to remember.

ONE SERVER, AND A WINDOWS TRAP
http.server.HTTPServer sets allow_reuse_address = 1, which on Linux only
affects sockets in TIME_WAIT. WINDOWS IS DIFFERENT: SO_REUSEADDR there lets a
second process bind a port a LIVE process is already listening on. Both
sockets exist, which of them answers a given request is not defined, and
stopping one leaves the other serving. That looks exactly like a server that
will not die — the symptom that caused this to be written.

So reuse is off on Windows, and a start probes the port first: if Deckwave is
already answering there, this says so and exits 0 instead of stacking a second
copy. A PID file next to the system temp directory — never in the repo, which
is served — lets --stop find it.
"""
import argparse
import atexit
import http.server
import os
import signal
import socket
import ssl
import sys
import tempfile
import urllib.error
import urllib.request

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Never served, on any interface. Blocking at the handler rather than relying
# on the server being local means the rule survives someone adding --lan later.
DENY_DIRS = {"_source", "tools", "deckwave-patches"}
DENY_EXACT = {"/.git", "/.gitignore"}


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=REPO, **kw)

    def _forbidden(self, path):
        clean = path.split("?", 1)[0].split("#", 1)[0]
        parts = [p for p in clean.split("/") if p]
        if any(p.startswith(".") for p in parts):      # .git, .env, anything dotted
            return True
        if parts and parts[0] in DENY_DIRS:
            return True
        return clean in DENY_EXACT

    def send_head(self):
        if self._forbidden(self.path):
            self.send_error(403, "Not served")
            return None
        return super().send_head()

    def list_directory(self, path):
        # No directory indexes. Knowing the layout is half of finding anything.
        self.send_error(403, "No directory listing")
        return None

    def end_headers(self):
        # No caching. Editing a module and reloading should show the edit —
        # stale assets cost real debugging time during this project.
        self.send_header("Cache-Control", "no-store, must-revalidate")
        self.send_header("X-Content-Type-Options", "nosniff")
        # How a second invocation recognises US rather than some other service
        # that happens to hold the port. Without it, "something answered on
        # 8777" would be taken as proof, and it is not.
        self.send_header("X-Deckwave-Serve", "1")
        super().end_headers()

    def log_message(self, fmt, *args):
        sys.stderr.write("%s %s\n" % (self.address_string(), fmt % args))


def pidfile_for(port):
    # Temp, not the repo: anything in the working tree is served, and a stray
    # pid file surviving a hard kill should not become a tracked artefact.
    return os.path.join(tempfile.gettempdir(), "deckwave-serve-%d.pid" % port)


def probe(port, scheme="http"):
    """Is a Deckwave server already answering here? Returns its pid, or None.

    Identity comes from the X-Deckwave-Serve header, not from "the port is
    busy" — the port being busy says nothing about who has it."""
    url = "%s://127.0.0.1:%d/" % (scheme, port)
    try:
        req = urllib.request.Request(url, method="HEAD")
        ctx = ssl._create_unverified_context() if scheme == "https" else None
        with urllib.request.urlopen(req, timeout=1.5, context=ctx) as r:
            if r.headers.get("X-Deckwave-Serve") != "1":
                return None
    except urllib.error.HTTPError as e:
        if e.headers.get("X-Deckwave-Serve") != "1":
            return None
    except Exception:
        return None
    try:
        with open(pidfile_for(port)) as f:
            return int(f.read().strip())
    except Exception:
        return -1          # ours, but we cannot name the process


def stop(port, scheme="http"):
    pid = probe(port, scheme)
    if pid is None:
        print("nothing of ours on port %d" % port)
        return 0
    if pid == -1:
        print("a Deckwave server holds port %d but left no pid file - "
              "stop it in the terminal that owns it" % port)
        return 1
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError as e:
        print("could not stop pid %d: %s" % (pid, e))
        return 1
    try:
        os.remove(pidfile_for(port))
    except OSError:
        pass
    print("stopped pid %d on port %d" % (pid, port))
    return 0


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lan", action="store_true",
                    help="bind all interfaces over HTTPS (needs a certificate)")
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--certdir", default=os.path.join(os.path.dirname(REPO), "deckwave-tls"))
    ap.add_argument("--stop", action="store_true",
                    help="stop the Deckwave server already on this port")
    args = ap.parse_args()

    port = args.port or (8443 if args.lan else 8777)
    host = "0.0.0.0" if args.lan else "127.0.0.1"
    scheme = "https" if args.lan else "http"

    if args.stop:
        sys.exit(stop(port, scheme))

    # Idempotent start. Restarting the app should not require anyone to know
    # whether a server is already up, and must never leave two of them.
    running = probe(port, scheme)
    if running is not None:
        print("Deckwave is already serving on %s://127.0.0.1:%d/ - reusing it"
              % (scheme, port))
        print("  stop it with: python tools/serve.py --stop"
              + (" --lan" if args.lan else ""))
        return

    # See ONE SERVER in the module docstring: on Windows this default lets a
    # second process bind a port a live one already holds.
    if os.name == "nt":
        http.server.ThreadingHTTPServer.allow_reuse_address = False

    try:
        httpd = http.server.ThreadingHTTPServer((host, port), Handler)
    except OSError as e:
        sys.exit("port %d is held by something that is not Deckwave (%s)" % (port, e))

    pf = pidfile_for(port)
    with open(pf, "w") as f:
        f.write(str(os.getpid()))
    atexit.register(lambda: os.path.exists(pf) and os.remove(pf))
    # SIGTERM is how --stop asks; without a handler the atexit hook never runs
    # and the next start would find a stale pid file.
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))

    if args.lan:
        cert = os.path.join(args.certdir, "cert.pem")
        key = os.path.join(args.certdir, "key.pem")
        if not (os.path.exists(cert) and os.path.exists(key)):
            sys.exit("no certificate in %s - see the header of this file" % args.certdir)
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(cert, key)
        httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
        print("serving %s over HTTPS" % REPO)
        print("  https://localhost:%d/" % port)
        print("  https://%s:%d/     <- other machines on the LAN" % (lan_ip(), port))
        print("self-signed: one certificate warning per device, then proceed")
        print("REACHABLE ON YOUR NETWORK. Stop it when you are done testing.")
    else:
        print("serving %s over HTTP" % REPO)
        print("  http://127.0.0.1:%d/     (localhost only)" % port)

    print("not served: dotted paths, %s" % ", ".join(sorted(DENY_DIRS)))
    print("Ctrl-C to stop")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")


if __name__ == "__main__":
    main()
