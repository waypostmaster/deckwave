/* Does the sequencer still discard anything?

   The keeper's instruction was "Ideally you wouldn't discard any of the songs
   that people have put in. maybe we find a way to gracefully still reach
   them." This checks that, and checks that the price of keeping them was not
   paid by the tracks that were already fine.

   Every check states what would falsify it. A check whose pass condition does
   not exclude the failure mode it is pointed at is decoration — this project
   has a table of seven that were.

   CAVEAT, STATED UP FRONT: the only full beat arrays in the repo are the v1
   cache, which holds 120-second-excerpt grids. So the grid errors computed
   here are NOT the v2 figures quoted in ROADMAP; they come from a shorter
   span and will differ. What is under test is the LOGIC — classify, place,
   never stretch an unlocked track, never let one steer the tempo — not which
   particular track lands on which side. The live app computes from v2 grids.

       node tools/check-pool.js
*/
const fs = require('fs');

let fails = 0, checks = 0;
const ok = (name, cond, falsifier) => {
  checks++;
  if (!cond) { fails++; console.log('  FAIL  ' + name + '\n        ' + falsifier); }
  else console.log('  pass  ' + name);
};

const src = fs.readFileSync('assets/deckwave.js', 'utf8');
const grab = (re, what) => {
  const m = src.match(re);
  if (!m) { console.log('FATAL: could not extract ' + what); process.exit(1); }
  return m[0];
};

global.window = global;
/* ONE eval, not six: `const LOCK` inside its own eval() call is scoped to
   that call and invisible to a function eval'd afterwards, which is exactly
   how the first version of this file died with "LOCK is not defined". */
eval([
/* arc() is exactly two lines and does not end on a line that is just "};",
   so a lazy [\s\S]*? match for that terminator runs straight past it and
   swallows LOCK and gridError as well -- which then get declared a second
   time by their own grab() and throw "Identifier 'LOCK' has already been
   declared". Match the two lines. */
  grab(/const arc = \(i, n\) =>[^\n]*\n[^\n]*\n/, 'arc'),
  grab(/const LOCK = \{[^}]*\};\n/, 'LOCK'),
  grab(/function dedupe\(corpus, opts\) \{[\s\S]*?\n\}\n/, 'dedupe'),
  grab(/function gridError\(t\) \{[\s\S]*?\n\}\n/, 'gridError'),
  grab(/function camScore\([\s\S]*?\n\}\n/, 'camScore'),
  grab(/function sequence\(corpus, opts\) \{[\s\S]*?\n\}\n/, 'sequence')
/* `const` declared inside eval() stays in the eval's own lexical scope, so the
   functions above can see LOCK and this file cannot. Hand it out deliberately
   rather than re-typing the numbers here -- a copy would let the test and the
   code disagree about the very threshold under test. */
].join('\n') + '\nglobalThis.__LOCK = LOCK;');
const LOCK = globalThis.__LOCK;

const normf = s => s.toLowerCase().replace(/\.(flac|mp3|wav|aiff|m4a|ogg)$/, '')
                    .replace(/[^a-z0-9]/g, '');
const LIB = process.env.DECKWAVE_LIB || 'C:/Claude/Music/LukHash';
let files = null;
try {
  files = new Set(fs.readdirSync(LIB).filter(f => /\.(flac|mp3|wav)$/i.test(f)).map(normf));
} catch (e) {
  console.log('  NOTE: ' + LIB + ' unreadable — using every cached record.');
}
const corpus = JSON.parse(fs.readFileSync('evidence/deckwave-cache-v1-2026-08-17.json', 'utf8')).data
  .filter(r => !files || files.has(normf(r.name)))
  .map(r => ({ id: r.id, name: r.name, bpm: r.bpm, conf: r.conf, dur: r.dur,
               camelot: r.camelot, energy: r.energy != null ? r.energy : 0.5,
               beats: Array.isArray(r.beats) ? r.beats : [] }));

console.log('\n── corpus ──────────────────────────────────────────────────');
console.log('  ' + corpus.length + ' tracks, grids from the v1 cache (120s excerpts)');

/* ── 1. classification ────────────────────────────────────────────────── */
console.log('\n── classification ──────────────────────────────────────────');
const sane = dedupe(corpus, {}).filter(t => t.bpm > 60 && t.dur > 75);
const withErr = sane.map(t => ({ t, e: gridError(t) }));
const lockedN = withErr.filter(x => x.e != null && x.e <= LOCK.maxGridErrPct).length;
console.log('  cut at ' + LOCK.maxGridErrPct + '%  ->  ' + lockedN + ' locked, ' +
            (sane.length - lockedN) + ' unlocked');

/* gridError must be beatmatch error, so it must be computable independently
   from the same beats. Falsifier: any disagreement with a second calculation. */
let worst = 0;
withErr.forEach(({ t, e }) => {
  if (e == null) return;
  const b = t.beats, mine = Math.abs(60 * (b.length - 1) / (b[b.length - 1] - b[0]) - t.bpm) / t.bpm * 100;
  worst = Math.max(worst, Math.abs(mine - e));
});
ok('gridError() reproduces from the beats alone', worst < 1e-9,
   'recomputation differed by ' + worst + ' — the function is doing something else');

/* Confidence and grid error must be measuring DIFFERENT things, or replacing
   one with the other changes nothing and this whole exercise is theatre.
   Falsifier: the two orderings agree. */
const bothWays = withErr.filter(x => x.e != null);
const byConf = bothWays.slice().sort((a, b) => a.t.conf - b.t.conf).map(x => x.t.name);
const byErr = bothWays.slice().sort((a, b) => b.e - a.e).map(x => x.t.name);
const top10 = new Set(byErr.slice(0, 10));
const overlap = byConf.slice(0, 10).filter(n => top10.has(n)).length;
ok('the old gate and the new one disagree about who is worst (' + overlap + '/10 overlap)',
   overlap < 7, 'the two rankings largely agree, so swapping them buys nothing');

/* ── 1b. dedupe: the name nominates, the audio decides ─────────────────── */
console.log('\n── dedupe ──────────────────────────────────────────────────');
const everything = dedupe(corpus, { dedupe: false });
const merged = dedupe(corpus, {});
console.log('  ' + corpus.length + ' records -> ' + merged.length +
            ' after merge   (keep-all mode returns ' + everything.length + ')');

ok('dedupe:false keeps every record', everything.length === corpus.length,
   'keep-all returned ' + everything.length + ' of ' + corpus.length);

/* Two survivors must never be the same recording, or the set can play one
   track twice. Falsifier: any surviving pair matching on duration AND tempo.
   Those two fields are stable; `conf` is NOT — two encodes of one master
   differ by about 0.001 there, and building the signature from it made an
   earlier version of this check reject five correct merges. */
const sameRec = (a, b) => Math.abs(a.dur - b.dur) < 0.15 && Math.abs(a.bpm - b.bpm) < 0.05;
let survivingDupes = 0, dupeEg = '';
for (let i = 0; i < merged.length; i++)
  for (let k = i + 1; k < merged.length; k++)
    if (sameRec(merged[i], merged[k])) {
      survivingDupes++;
      if (!dupeEg) dupeEg = merged[i].name.slice(-32) + ' / ' + merged[k].name.slice(-32);
    }
ok('no two survivors are the same recording', survivingDupes === 0,
   survivingDupes + ' duplicate pairs survived, e.g. ' + dupeEg);

/* The opposite failure, and the worse one: a track thrown away that had no
   audio-matching twin. That is a real song silently lost to a name collision,
   which is what the keeper warned about -- "there may be some tracks with
   same-ish names but differing somehow". Falsifier: any dropped record with no
   survivor within 1% on duration. */
const keptNames = new Set(merged.map(t => t.name));
const dropped = corpus.filter(t => !keptNames.has(t.name));
const orphaned = dropped.filter(d => !merged.some(m =>
  Math.abs(m.dur - d.dur) / Math.max(m.dur, d.dur) <= 0.01 &&
  Math.abs(m.bpm - d.bpm) / Math.max(m.bpm, d.bpm) <= 0.01));
ok('nothing was dropped without an audio-matching twin', orphaned.length === 0,
   orphaned.length + ' dropped with no twin, e.g. ' + (orphaned[0] && orphaned[0].name));
console.log('  ' + dropped.length + ' merged away, all with a matching twin');

/* ── 2. nothing is discarded ──────────────────────────────────────────── */
console.log('\n── nothing discarded ───────────────────────────────────────');

/* ORDER MATTERS HERE, and getting it wrong is how this file first reported a
   phantom failure. sequence() stamps _stretch / _tempoAt / _locked / _unlocked
   ON THE SHARED CORPUS OBJECTS, so a second call restamps the first call's
   results and any assertion made afterwards is reading the wrong build. Run
   the comparison build FIRST, keep only its length, then build the real one.
   (The same hazard is live in the app: build twice and the first set's tracks
   are restamped. commit() already has to `delete out[i]._dwell` for exactly
   this reason.) */
const oldCount = sequence(corpus, { length: 500, minConf: 0.8, maxGridErr: 1e9 }).length;

const set = sequence(corpus, { length: 500 });
const inSet = new Set(set.map(t => t.id));
const missing = sane.filter(t => !inSet.has(t.id));
console.log('  pool ' + sane.length + '  ->  set ' + set.length +
            '   (' + set.filter(t => t._unlocked).length + ' played straight: ' +
            set.filter(t => t._unlockReason === 'grid').length + ' grid, ' +
            set.filter(t => t._unlockReason === 'reach').length + ' reach)');
ok('every track that survives the sanity filter is placed', missing.length === 0,
   missing.length + ' never placed: ' + missing.slice(0, 6).map(t => t.name.slice(-30)).join(', '));

/* Falsifier: if the old settings also placed everything, nothing was ever
   being discarded and this whole change is solving an imagined problem. */
console.log('  old gate (conf>0.8, everything locked): ' + oldCount + ' placed');
ok('the old configuration really did drop tracks', oldCount < sane.length,
   'the old settings placed ' + oldCount + ' of ' + sane.length + ' — nothing was lost, so there was nothing to fix');

/* ── 3. the price ─────────────────────────────────────────────────────── */
console.log('\n── what the locked tracks still guarantee ──────────────────');
const lockedRows = set.filter(t => !t._unlocked);
const overGate = lockedRows.filter(t => Math.abs(t._stretch - 1) > 0.08 + 1e-9);
ok('every LOCKED track is still inside the 8% stretch gate', overGate.length === 0,
   overGate.length + ' locked tracks over the gate, worst ' +
   Math.max(0, ...overGate.map(t => +((Math.abs(t._stretch - 1)) * 100).toFixed(1))) + '%');

const badStretch = set.filter(t => t._unlocked && t._stretch !== 1);
ok('no UNLOCKED track is stretched', badStretch.length === 0,
   badStretch.length + ' unlocked tracks carry a stretch other than 1');

/* A GRID-unlocked track must not steer the rolling target — its BPM is the
   number we distrusted. Falsifier: the track after it sees a different tempo. */
let steered = 0, steerEg = '';
for (let i = 0; i < set.length - 1; i++) {
  if (set[i]._unlockReason !== 'grid') continue;
  if (set[i + 1]._tempoAt !== set[i]._tempoAt) {
    steered++;
    if (!steerEg) steerEg = set[i].name.slice(-28) + ': ' + set[i]._tempoAt + ' -> ' + set[i + 1]._tempoAt;
  }
}
ok('a GRID-unlocked track does not move the tempo target', steered === 0,
   steered + ' moved it, e.g. ' + steerEg);

/* A REACH-unlocked track MUST steer, or the walk faces the same dead end on
   the next iteration and the tail degenerates into an unmixed playlist.
   Falsifier: the track after it still sees the old tempo. */
let stuck = 0, stuckEg = '';
for (let i = 0; i < set.length - 1; i++) {
  if (set[i]._unlockReason !== 'reach') continue;
  if (set[i + 1]._tempoAt !== Math.round(set[i].bpm)) {
    stuck++;
    if (!stuckEg) stuckEg = set[i].name.slice(-28) + ': expected ' +
      Math.round(set[i].bpm) + ', next saw ' + set[i + 1]._tempoAt;
  }
}
ok('a REACH-unlocked track repositions the set to its own tempo', stuck === 0,
   stuck + ' did not, e.g. ' + stuckEg);

let runs = 0;
for (let i = 1; i < set.length; i++) if (set[i]._unlocked && set[i - 1]._unlocked) runs++;
console.log('  back-to-back unlocked pairs: ' + runs +
            (runs ? '  (allowed only when nothing else qualified)' : ''));

console.log('\n── played straight, and why ────────────────────────────────');
set.filter(t => t._unlockReason === 'grid')
   .sort((a, b) => (b._gridErr || 0) - (a._gridErr || 0))
   .forEach(t => console.log('   grid   ' + String(t._gridErr).padStart(6) + '%  conf ' +
       t.conf.toFixed(2) + '  ' + t.name.replace('.flac', '').slice(-42)));
const reach = set.filter(t => t._unlockReason === 'reach');
console.log('   reach  ' + reach.length + ' tracks the stretch gate could not get to');
reach.slice(0, 8).forEach(t => console.log('          from ' + String(t._tempoAt).padStart(3) +
    ' to ' + String(Math.round(t.bpm)).padStart(3) + ' bpm   ' +
    t.name.replace('.flac', '').slice(-40)));
if (reach.length > 8) console.log('          ... and ' + (reach.length - 8) + ' more');

console.log('\n' + (fails ? fails + ' FAILED' : 'all passed') + ' of ' + checks + ' checks');
process.exit(fails ? 1 : 0);
