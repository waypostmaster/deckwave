# Changelog

Versions are recorded here and in the package filename. Earlier packages from
the 2026-08-17 session were overwritten in place and no longer exist — this
file begins the lineage that will be preserved.

## 0.7.0 — 2026-08-18 · nothing gets discarded

**The pool gate was measuring the wrong number, and this project's own docs
said so.** Tracks were excluded at `conf <= 0.8` — Essentia's agreement
between five onset detectors — while SKILL.md already warned that low
agreement on chiptune is expected rather than a defect. Measured: five of the
ten excluded tracks had beat grids accurate to under 1.5%, and 42 of the 164
admitted had worse grids than some that were refused. *Timeless* passed at
conf 1.35 with an 11% wrong grid; *Neon Thrills* was refused at conf 0.72 with
a 0.01% one.

**The replacement measures what actually costs a beatmatch.** The engine
stretches by the declared tempo and aligns to the detected beats, so when
those two disagree by 6% the transition is 6% out however good the crossfade
is. Grid error IS beatmatch error. `DW.lock.maxGridErrPct` defaults to 9,
**derived rather than chosen**: the distribution over 179 tracks has an empty
band between 7.50% and 11.04%, and every cut inside it selects the identical
five tracks. About 3% is the other defensible answer and has not been heard.

**Nothing is dropped from a set any more.** A track that cannot be trusted or
cannot be reached is played STRAIGHT — its own speed, no stretch, no claim of
a beatmatch — which is what a DJ does with a record that will not grid. Two
kinds, and they behave as opposites:

- *grid* — its BPM is the number we distrust, so it does not steer. Letting a
  bad grid drift the rolling target would spread one bad number across every
  transition after it.
- *reach* — its grid is fine, the stretch gate simply could not get there. It
  plays straight and then repositions the set to its own tempo, because moving
  the set is the entire reason for playing it.

Measured on the real corpus: **171 of 171 placed, 9 straight (5 grid, 4
reach), 162 fully beatmatched.** The old configuration placed 107.

The list marks a straight transition, the route panel prints `∿ grid` or
`∿ reach` rather than a stretch figure, and `inspect()` counts them
separately — printing `0.0%` against an unmatched transition would make it
look like the best one on screen.

**`dedupe` is optional.** *keep duplicate versions* in the transport. It merges
17 tracks in this library — the same recording on an album and on a single —
and removing anything the owner put in their own folder should be their call.

**`DW.classify()`** reports who can be beatmatched and shows its working:
declared tempo, what the beats actually say, the disagreement, and the tracks
whose classification would flip at the other threshold.

**Repairing a set stopped discarding too, and only because a harness asked.**
`resequenceTail()` re-plans the remainder after a route is spliced in, and it
was still dropping whatever the gate could not reach — build a set with all 171
tracks, take one scenic route, and 35 vanished. The no-discard promise held for
BUILDING a set and quietly did not hold for repairing one. Same answer applied:
unreachable tracks play straight and reposition the tail. Measured after a
15-hop route: **162 kept, 0 dropped, 4 played straight, max stretch 8%.**

`DWNAV.verify()` had to learn about it as well. It was counting straight
transitions as gate violations — 11 of them, "max stretch 94.6%" — a real
number measuring something that never happens, which is the exact failure mode
this project keeps a table about.

**`tools/check-pool.js`** — eight checks against the real corpus, each printing
what would falsify it. Two failed on the first run and both were real: one a
genuine gap (64 of 171 still unplaced, because fixing the confidence gate did
nothing about the stretch gate), one a bug in the harness (`sequence()` stamps
its results on the shared corpus objects, so calling it twice restamps the
first build).

**dedupe was keying on a pattern any hyphen could derail.** It stripped two
prefixes with `^[^-]+-`, and that stops at the first hyphen ANYWHERE rather
than at the " - " separator — so `WALKMAN -Single-`, `CYBERNINJA -Single-`,
`HONGDAE -Single-`, `EIGHTY-FIVE -EP-` and `8-Bit Warrior` all keyed
differently from their album copies and the same recording could play twice.
It caught 17 of the 27 duplicate groups in this library.

**And the name is now only a hypothesis.** A title match nominates a pair; they
merge only if the audio agrees too, on duration and tempo within 1%. A remix, a
radio edit or a re-recording sharing a title is kept, because silently dropping
a real track is the worst failure available here and the tolerance is set far
to the keeping side. Verified both ways against the corpus: no two survivors
are the same recording, and nothing was dropped without an audio-matching twin.

**The tiebreak is grid error, not confidence.** When two copies really are one
recording, keep the one whose beat grid agrees with its own tempo — the copy
that can be beatmatched. Confidence differs by about 0.001 between two encodes
of the same master, which is noise being asked to make a decision.

**Superseded:** `deckwave-0.6.0.zip`, preserved.

## 0.6.0 — 2026-08-18 · routing that reaches the deck

**Every route was inert in audio, and had been since 0.4.0.**
`DWNAV.commitAndRepair()` returns a NEW array; the dashboard assigned it to
itself and nothing else. `Player.play(seq)` had captured the array it was
handed as `order`, and there was no API to give it another. So a committed
route existed in two versions — one on screen with the stepping stones spliced
in, one in the speakers without them — and both were internally consistent.
The fourth occurrence of *the UI records an intention and playback never reads
it*; patch 09 was written to fix exactly that, for the queue instead of the
order.

`DW.reorder(seq, opts)` **adopts** the caller's array, so the list and the
player are one object again — the invariant every in-place steering operation
already relied on. It refuses when the playing track is no longer at `idx`
rather than repairing it, and re-chains, because the next deck is committed the
moment a track starts and that choice predates the route.

**Blend fast now leaves the current track at the next downbeat.** Scenic route
still lets it finish. Previously both waited out the current track in full and
then walked a route the deck could not see.

**New `route` panel.** The committed detour: stepping stones with the dwell
that will actually be honoured, the destination, the tempo ladder, progress to
the scheduled exit, and live stretch. It draws `set[state.idx] === DW.nowMeta`
as **LIST ≠ DECK** in red — the one identity check that would have caught this
defect, ledger 33 and ledger 38.

The wayposts panel draws `DWNAV.queue`, which `commitAndRepair()` clears on its
last line, so a route vanished from the display at the instant it became real.
`DWNAV.active` now records the committed route by object identity.

**Now-playing and the track list read the deck, not the list index.** Both
derived the playing track from `set[state.idx]`, which is only right while the
two arrays agree. `DW.nowMeta` is the meta object on the playing deck and
cannot be wrong about what is audible.

**Stepping stones are 45 seconds, not the 40 the menu advertised.** `chain()`
clamps every dwell to a floor that was an inline literal; the router asked for
40 and the menu printed the request. The floor is now `MIN_PLAY`, exposed as
`DW.dwellFloor`, and quoted by both places that used to quote the other number.
Neither number moved — that clash is ROADMAP D7 and it is an ear question.
Measured on the live corpus: 130 → 151 bpm is 4 stones, **3.0 min**, not 2.7.

**`settle` — riding a stretched deck back to its own speed after a bad blend.
Built, and OFF.** The obstacle was structural: every beat-to-wall-clock
conversion divided by a constant `rate`. Decks now carry `pos()`/`when()`,
which integrate the rate and reduce to exactly the old arithmetic when no ramp
is scheduled — asserted with `===`, not a tolerance. Turning it on makes a deck
hand over at its own BPM instead of the 35%-drift target, so it changes the
whole tempo plan downstream. 45 seconds is chosen, not measured. ROADMAP D8.

**`DW.audit(set)` and an `audit set` button.** Decodes every track with the
same `decodeAudioData` call playback makes and reports the failures with the
decoder's own message and the stage — `find`, `read` or `decode`, which have
completely different fixes. A track that will not decode is spliced out of the
order with one log line nobody is watching, so the symptom is "that one never
plays" with no evidence afterwards. Also flags any track whose decoded length
disagrees with the analysed length, which means the beat grid is mapped onto a
different length of audio than it was measured on.

**`tools/check-route.js`** — 15 offline checks against the real corpus and the
real cache, each printing what would falsify it. It does not touch audio, and
says so: the whole failure was a correct data structure that was not being
played.

**`expanse` theme and the `roci` sprite.** Vacuum blue-black, hull-display
teal against MCRN orange — the two accents a long way apart in hue, for the
reason every theme since stargaze has had to obey: loudtime draws its average
in one and its peak in the other, and on a limited track those traces meet.
The Rocinante is drawn on the theme slots rather than fixed RGB, so she
recolours under every theme.

**`tools/package.py`.** The CHANGELOG's own first line records that earlier
packages were built by hand and overwritten, and two shipped missing files the
page loads. The file list is now DERIVED from `index.html` — every `src` and
`href` is resolved and must exist or the build refuses — and it will not
overwrite an existing version without `--force`.

**Superseded:** `deckwave-0.5.0.zip`, preserved.

## 0.5.0 — 2026-08-17 · fast blends, queue as a list

**Fast blends.** The rolling target advances 35% per *track played*, not per
second — so a stepping stone shifts the tempo the same whether it plays 40
seconds or four minutes. Intermediates in a route now play only long enough to
blend in, hold, and blend out.

Measured from 125 BPM: 151 BPM in **4.0 min** instead of 21.0; 90 BPM in
**7.3 min** instead of 38.5. Same hops, same tempo movement, same 8% gate on
every transition.

**The queue is a list.** Several destinations can be queued, reordered and
removed, each with its own mode. `DWNAV.queue` still returns the head, so the
wayposts panel and route commit needed no changes.

**Queue panel**, bottom left: per-entry tempo ladder, wall-clock estimate,
reorder and remove, and a commit action. Badges distinguish fast, scenic,
direct and forced.

**Superseded:** `deckwave-0.4.0.zip`, preserved.

## 0.4.0 — 2026-08-17 · steering

**Steering a running set.** Clicking a track no longer jumps; it opens a menu
with options that each state their cost.

- **`DWNAV` router.** The rolling target moves 35% toward each track played,
  so a track unreachable now may be reachable after a hop. Getting to a
  destination becomes a shortest-path search with the stretch gate as the edge
  condition. One hop gains at most **3.04%** tempo — derived, not guessed.
- **Wayposts panel.** The corpus as a navigable space: angle is Camelot
  position, radius is log tempo, and the lit annulus is everything the gate
  permits from here. A long harmonic tempo climb draws itself as a spiral.
- **Route commit.** A chosen route is spliced into the set rather than
  intercepted at playback, so the player walks it by construction.
- **Tail repair.** A detour changes the tempo state and breaks the rest of the
  set; `resequenceTail` re-plans it. Verified: zero tracks over the gate.
- **Corpus cache export/restore**, with integrity comparison on restore.

**Bug fixed in this release:** the router, steering menu and panel all shipped
in a state where the queue was populated and **nothing in the playback path
read it.** The feature recorded intentions and discarded them. Caught by the
keeper noticing the set was not walking anywhere.

**Measured:** at 109 BPM on 189 tracks — 123 BPM in 2 hops; 139 BPM in 7 hops
and ~25 min; 79 BPM in 13 hops and ~46 min; 172 BPM genuinely unreachable, the
corpus lacks the rungs.

**Superseded:** `deckwave-0.3.0.zip`, which is preserved.

## 0.3.0 — 2026-08-17 · RECONSTRUCTED

Marked RECONSTRUCTED because it is the surviving state of a package that was
rebuilt in place roughly eight times during a single session. The intermediate
states are gone. Nothing here is uncertain — the contents are known and
verified — but the *history* of the artifact was destroyed and cannot be
recovered.

**Contents:** engine, panel registry with twelve panels, portable score format,
FLAC tag reading, listen mode, now-playing card, single render loop, glossary
with 32 terms and translation export, six themes, saveable named views,
collapsible panels, MEGA layout. `mount()` wires every mixin; the loop starts
once. 21 files, all modules syntax-checked.

**Known unverified:** a cold load of `index.html` has never been tested. All
development ran through live injection into an already-running page.

**Superseded in this release:** nothing preserved. See note above.
