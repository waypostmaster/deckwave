# Deckwave

**Version 0.8.0 · public from 2026-08-24** — eight bars of four; the phrase boundary the engine still cannot hear.

Analyse your whole local music library in the browser, build a beat-locked harmonically-mixed DJ set from it, and save the mix as data rather than audio.

Nothing is uploaded. Files are read through a folder you pick, analysed locally, and the audio buffers are discarded immediately. The only things that persist are a few hundred bytes of features per track, in your own browser's storage.

**Best on Chromium — desktop and Android 132+; runs on Firefox, Safari and iOS.** Chromium has the File System Access API, so one folder pick walks a whole tree (Chrome for Android has it from 132). Everywhere else the folder and the tracks come in through `<input type="file">` — whole folders on desktop Firefox/Safari, iOS 18.4+ and Firefox Android 142+; individual tracks (multi-select from the system picker) on older mobile browsers. FLAC that the browser's own decoder refuses is decoded by the vendored libflac instead. One thing does not exist outside Chromium: tab/system audio capture (listen mode) on phones. **Measured 2026-08-19 on an iPhone 16 Pro Max (iOS 26.6): a 189-track library analysed on the device, including an eight-and-a-half-minute track, and a set played.** A phone layout (two panels per screen, a `☰ set` screen, the log line first), an installable manifest, a `phone:` option that keeps the screen awake or routes the mix through a media element for the lock screen, and a `serve.py --music` root to get a library onto the phone in one zip are all there; what is and is not heard on a phone is in `docs/LISTENING.md`.

---

## What it does

**Analyses a corpus.** One folder pick walks the whole tree. Each track is decoded, measured **whole** with Essentia.js for tempo, beat grid, key and confidence, and the buffer released. (Through 0.5.0 only a 120-second excerpt was measured, and the grid it produced was stored as if absolute — so anything past two minutes had no beats at all.) Results cache to IndexedDB, so a rescan after adding music only pays for the new files. 364 tracks fit comfortably.

**Sequences a set.** A rolling tempo target drifts toward each incoming track rather than holding one global BPM, with a hard gate refusing anything needing more than 8% time-stretch. Candidates are scored on Camelot key compatibility, tempo proximity, and distance from an energy arc. Two builds: **all tracks** — nothing is discarded; a track the gate cannot reach, or whose beat grid disagrees with its own tempo label, is played *straight* (its own speed, a plain crossfade, no claim of a beatmatch) and the set carries on — or **best matches**, which keeps only what can be beatmatched from where the set is and ends when the gate is exhausted, saying what it left out.

**Plays it beat-locked.** Each deck runs through a SoundTouch AudioWorklet that matches tempo without changing pitch. Crossfades land on detected downbeats with a three-band bass swap, so only one kick sounds at a time. Tracks decode one ahead and release behind — memory stays flat regardless of set length.

**Shows you what's happening.** Oscilloscope, log-spaced spectrum, chromagram pitch wheel, dual-ring Camelot wheel with the harmonic path drawn, spectral-flux bass onsets, goniometer with phase correlation, VU meters with real 300ms ballistics, and the whole set's energy and tempo arc with a playhead.

**Saves the mix as a score.** ~26KB of JSON describes a 197-minute set: every entry point, tempo multiplier, exit downbeat, crossfade and EQ timing, plus an engine block naming the detector and stretcher. Load it back and the identical set rebuilds. A standard `.cue` comes with it.

**Listens to other things.** Point it at another tab via `getDisplayMedia` and every visual works on Spotify, YouTube, anything — no analysis or mixing, but the instrument runs. (Desktop only; no phone browser exposes tab audio.)

**Is honest about what it has not heard.** Every chosen number in the engine is documented as chosen, every measured one as measured, and `docs/LISTENING.md` lists what is built and unheard, with what each answer would change. The build log's failure ledger — 59 rows — is the content, not the appendix.

**Licence.** AGPL-3.0, because Essentia.js is; see `NOTICE`. Every third-party library is vendored and pinned in `vendor/` with its licence and hash; the page fetches nothing off-origin.

---

## Quick start

```bash
python tools/serve.py          # http://localhost:8777 — Chromium gets the folder walk
python tools/serve.py --lan    # HTTPS on 8443 for a phone on the same network (cert outside the repo)
python tools/serve.py --lan --music "C:/Music"   # also serve that folder read-only at /music/ — tap "download all" on the phone
```

Then **scan** (pick the folder), **build set · all tracks** or **build · best matches**, **▶ play**. Everything else is one click away in the transport; the glossary explains every panel and figure on hover.

From the console, the same thing:

```js
await DW.scan(console.log)      // pick a folder, walks the tree, caches
DW.confidence()                 // how much to trust the tempo figures
const set = DW.build({ length: 120 })
DW.inspect(set)                 // READ THIS before playing
await DW.openLibrary()          // re-resolve files for playback
await DW.play(set)
DW.stop()                       // reaches scheduled sources, not just current
```

---

## Read the numbers honestly

`inspect()` returns the figures that decide whether a set is worth playing. **`maxStretchPct` above 15 will audibly wobble** — that is perceptual, not taste. **`keyWeak`** counts clashing transitions.

**Confidence is on Essentia's scale (0–5.32)**, where 1.5–3.5 is moderately confident. It is not comparable to any other detector's number.

**Energy is a constructed index** — 45% loudness, 25% brightness, 30% tempo, normalised across the corpus. It correlates with perceived energy. It is not a measurement, and the weights were chosen rather than fitted.

**When the sequencer returns fewer tracks than asked for, that is the gate working** — though since 0.7.0 it should be rare. A track the stretch gate cannot reach is played straight rather than dropped: its own speed, no stretch, and no claim of a beatmatch. The set marks those, and `inspect()` counts them separately. **A track played straight is not a worse track**; it is one we are not pretending to beatmatch.

---

## Theming

Every colour, font, radius, glow and scanline is a CSS custom property whose *fallback* is the default look. A host page overrides what it likes without forking:

```css
deckwave-app {
  --dw-color-bg: #faf8f3;
  --dw-color-accent: #2a2118;
  --dw-glow: 0;                /* kills the neon */
  --dw-scanline-opacity: 0;    /* kills the CRT */
}
```

Six presets ship in `themes/themes.css`. Structural elements expose `part=` for `::part()` overrides.

---

## Known limits, all real

- **Harnesses need the library for two of their checks.** `node tools/check-*.js` runs five offline harnesses; `check-route.js` and `check-flac.js` look for the keeper's library at `C:/Claude/Music/LukHash` (override with `DECKWAVE_LIB`) and fall back or skip without it — that is not a failure of the code.
- **Chromium is the full experience, including Chrome for Android 132+.** Elsewhere: no folder walk (files/folders via `<input type=file>`, which on iOS below 18.4 and Chrome Android below 132 means tracks not folders); no tab/system listen mode on any phone (no `getDisplayMedia` on iOS or Android — mic works); a set on a phone stops when the screen locks (WebKit suspends the AudioContext — not worked around); and whether the whole-track analysis of a long FLAC fits in an iOS tab is **unmeasured** — the analyser now releases the decoded buffer before the WASM pass, which is the structural part, but nobody has run it on an iPhone.
- **No phrase detection.** Transitions land on downbeats, not 8/16/32-bar boundaries. This is the largest quality gap.
- **No downbeat detection.** Every fourth beat is assumed — fine for 4/4 electronic music, wrong elsewhere.
- **Beat detection on chiptune is unstudied.** No published accuracy figures exist for square-wave percussion. Low confidence there is expected.
- **Thresholds were tuned against one artist's catalogue.** They may be wrong for other genres and are untested on live drums or variable tempo.
- **Cross-browser determinism of the score is untested.**
- **Long offline renders may exhaust memory.** `OfflineAudioContext` allocates the whole output up front.

---

## Licence and dependencies

Deckwave is **AGPL-3.0**, because Essentia.js is AGPL-3.0 and this is a combined work.

| Dependency | Licence |
|---|---|
| [Essentia.js](https://github.com/MTG/essentia.js) (MTG–UPF) | AGPL-3.0 — also available commercially |
| [SoundTouchJS AudioWorklet](https://github.com/cutterbl/SoundTouchJS) | MPL-2.0 in current versions — **pin your version** |
| [libflac.js](https://github.com/mmig/libflac.js) | MIT |
| libFLAC (Xiph) | BSD-style |

See `NOTICE`.

## Influences

The visual vocabulary follows **Strudel** (strudel.cc) — scope, spectrum, punchcard, pitchwheel — which is the JavaScript descendant of **TidalCycles** by Alex McLean. Independent implementations built on the Web Audio AnalyserNode; no Strudel code is used or copied. Pointed there by **Switch Angel**'s live-coding work.

VU ballistics follow ANSI C16.5-1942 (300ms to 99% deflection). The goniometer is the classic Lissajous stereo display. The general debt is to **Winamp**, AVS and Milkdrop, and the era when a music player was something you reskinned.

Analysis is **Essentia** (Music Technology Group, Universitat Pompeu Fabra).

## Playing your own music

Files are read locally from a folder you choose. Nothing is uploaded, bundled or fetched. Playing music you own, on your machine, needs no permission.

Rendering a mix to a file is the same act. **Sharing that file is not** — it contains the full recordings. That decision is yours.

---

See `docs/BUILD-LOG.md` for how this was built, failures included.
