---
name: deckwave
description: Analyse a local music library and play or render a beat-locked, harmonically-mixed DJ set in the browser. Use when the user wants their own music analysed for tempo, key and energy; wants an automatic mix, set or playlist built from a folder of audio; asks for beatmatching, crossfades, harmonic or Camelot mixing, an energy arc, or a mix rendered to a file; or wants music that reacts to what an agent is doing. Runs entirely on the user's machine — no audio is uploaded, bundled or fetched, and the third-party libraries are vendored in the tree rather than fetched at runtime. Best on Chromium, desktop and Android 132+ (File System Access API); runs on Firefox, Safari and iOS via file inputs. Not for generating music, not for streaming services, and not for anything that would distribute the user's audio. [v0.8.0]
---

# Deckwave

Corpus analysis and an automatic DJ, running in the page.

**Serve the folder and open `index.html`** (`python tools/serve.py`, then http://localhost:8777). The engine is `window.DW`; every module is a plain script, so `assets/deckwave.js` can still be pasted into a console or loaded via `javascript_exec` — that is how it was built — but the page is the supported way to run it.

## The short version

```js
await DW.scan(console.log)        // pick a folder → walks the tree, analyses, caches
DW.classify()                     // who can be beatmatched, who will play straight
const set = DW.build({ length: 60 })
DW.inspect(set)                   // straight count, stretch budget, keys — READ THIS
await DW.openLibrary()            // re-pick the folder to resolve files for playback
await DW.play(set)
DW.stop()                         // stops everything, including scheduled sources
DW.kill()                         // last resort: closes the AudioContext
```

## What it does

**Analyses** each track with Essentia's `RhythmExtractor2013` in multifeature mode — five onset-detection functions fused by agreement. Also extracts key, maps it to Camelot, and computes loudness and brightness. **Decodes the whole track, measures it, then discards the buffer**; only a few hundred bytes of features per track are kept. That is what makes a several-hundred-track library possible at all.

**Caches** to IndexedDB keyed by name, size and modified time. The first scan costs seconds per track; every scan after is instant, and re-running after adding music only pays for the new files.

**Sequences** with a rolling tempo target that drifts with the set rather than a fixed BPM, scored on Camelot compatibility, tempo proximity and distance from an energy arc. A track that cannot be reached inside the stretch budget, or whose beat grid disagrees with its own declared tempo, is **played straight rather than dropped** — see below.

**Plays** beat-locked: each deck runs through a SoundTouch AudioWorklet that stretches tempo without changing pitch, so both decks share a tempo and do not drift. Crossfades land on downbeats, with a three-band bass swap so only one kick sounds at a time. Tracks decode one ahead and release behind.

## Locked or straight

Every track in a set is one of two things, and everything below refers back to it:

- **Locked** — the detected beat grid agrees with the declared tempo, so the track can be stretched onto the running tempo and beatmatched.
- **Straight** — the track plays at its own speed, unstretched, and the set repositions its tempo to match. Either the grid disagrees with the tempo (`_unlockReason: 'grid'`) or the tempo was out of stretch reach (`'reach'`).

**Grid error IS beatmatch error, and that is a derivation rather than a metaphor.** The engine stretches by `tempo / meta.bpm` while aligning to `meta.beats`. If those two disagree by 6%, the transition is 6% out however good the crossfade is. That is why the pool is gated on grid disagreement and **not** on Essentia confidence — confidence measures agreement between onset detectors, which is a different question, and gating on it excluded tracks with near-perfect grids while admitting tracks with badly wrong ones.

`DW.classify()` shows the decision before you build: per track the declared tempo, what the beats actually say, and `gridErrPct` between them. `wouldChangeAt` lists the tracks whose classification flips if the threshold moves to the other defensible value — if that list is empty the threshold does not matter for this corpus, and if it is long it is the list to listen to.

`DW.lock.maxGridErrPct` is live and defaults to 9. **It was derived, not chosen**: the distribution over 179 tracks has an empty band from 7.50% to 11.04%, and every cut inside it selects the identical five tracks. About 3% is the other defensible answer. **Neither has been tested by ear** — say so if asked to justify the number.

## Rules that matter

**Report `inspect()` before playing, and lead with the bad numbers.** `maxStretchPct` above 15 will audibly wobble — that is the perceptual limit, not a style preference. `keyWeak` counts clashing transitions. `straight`, `straightGrid` and `straightReach` count the tracks that are not being beatmatched at all. If the numbers are poor, say so rather than pressing play.

**Never print `0.0%` stretch against a straight track.** `maxStretchPct` is computed over LOCKED tracks only, deliberately: an unlocked track has `_stretch === 1` by construction, so including it would pull the figure toward *everything is fine*. Reported per-track, that 0.0% makes the least beatmatched transition in the set read as the best one on screen. It is unstretched because it is not being beatmatched — a different fact.

**Never quote a confidence figure as if it were comparable to another detector's.** Essentia's runs 0–5.32 on its own scale. A different algorithm's 0.9 and Essentia's 0.9 mean nothing to each other, and treating them as a before-and-after is the easiest lie to tell with this tool.

**Energy is a constructed index, not a measurement** — 45% loudness, 25% brightness, 30% tempo, normalised across the corpus. It correlates with what a listener would call energy. It is not the same thing, and a loud sparse track can land beside a quiet busy one.

**Nothing is discarded from a set, and this reversed in 0.7.0.** A track the sequencer cannot reach, or whose grid it cannot trust, is now played straight instead of dropped. So a build coming back materially short is **worth investigating rather than reporting as a constraint satisfied** — which is the opposite of what this file said before 0.7.0, and the opposite of what a shortfall used to mean.

**`stop()` must reach scheduled sources.** Every source goes into a registry; stop iterates the registry, not the current deck pointers. A source scheduled for a future time is unreachable any other way — this is the bug that made an early version unstoppable, and it is why `kill()` exists as a guaranteed backstop.

## Playing the user's own music

Files are read locally through a folder the user picks. **Nothing is uploaded, bundled or fetched.** Playing music someone owns, on their machine, is not a licensed act and needs no permission.

**Rendering a mix to a file is the same act; sharing that file is not.** A rendered mix contains the full recordings. If the user asks about distributing it, say plainly that it is a different question, and leave the decision with them — do not lecture, and do not refuse to build the export.

## Limits, all real

- **Chromium is the full experience.** Without the File System Access API, folders and tracks come in through `<input type="file">` (`webkitdirectory` for folders — desktop Firefox/Safari, iOS 18.4+, Firefox Android 142+; multi-select tracks below that; Chrome for Android 132+ has the real API). FLAC the browser refuses is decoded by the vendored libflac. No phone has tab-audio capture; iOS suspends audio on screen lock; no phone has been measured for the analyser's peak memory.
- **The worklet is served same-origin from `vendor/`.** It needs a fetchable URL with CORS and cannot be inlined, so it is vendored rather than fetched from a CDN; `DW.assets.allowCDN = true` re-enables runtime fetching and is off by default.
- **Beat detection on chiptune is unstudied.** No published accuracy figures exist for square-wave or noise percussion. Treat low-confidence results on that material as expected, not as a bug.
- **Stretch beyond ±15% degrades audibly.** The budget defaults to 8% for that reason. Since 0.7.0 it decides whether a track is beatmatched or played straight, not whether it is admitted.
- **No downbeat detection** — bar position is assumed as every fourth beat from the first. Works for 4/4 electronic music, fails elsewhere.
- **No phrase detection.** Transitions land on downbeats, not on 8- or 16-bar boundaries. That is the single largest quality gap.
- **Long offline renders may exhaust memory.** `OfflineAudioContext` allocates the whole output up front; past about 15 minutes, render in segments.

See `references/design.md` for the evidence behind these choices and what remains untested.
