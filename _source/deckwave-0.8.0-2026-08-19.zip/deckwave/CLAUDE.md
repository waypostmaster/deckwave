# Deckwave — working agreements

Beat-locked, harmonically-mixed DJ set built from the user's own music library,
running entirely in the browser. Vanilla JS IIFE modules, shadow DOM, no build
step. Essentia.js (WASM) for analysis, SoundTouch AudioWorklet for stretching.

Read `docs/ROADMAP.md` for planned work and carried debt (D1–D9, R1–R11),
`docs/BUILD-LOG.md` for how each subsystem came to be the way it is, and
**`docs/LISTENING.md` for the six things that are built, measured and unheard**
— exact tracks, what to do, and what each answer changes. Most
"why is this so strange" questions are answered there.

## Hard constraints

**No bundler, framework, transpiler, or toolchain needed to RUN or TEST it.**
Restated 2026-08-19 (keeper's call: *"keep it web-based for now, update the
rule to mitigate for fossils"*). The property that matters is that a fresh
clone runs from a static file server and every harness runs with bare `node`
— no `node_modules`, nothing third-party executing that the vendored, pinned
four do not already account for. That stays.

What is a FOSSIL and not a rule: that every module is an IIFE hanging a
global off `window`, loadable by pasting into a console. That was the
development method (live-patching a playing page — see the `_dev` seam in
`deckwave.js`, `deckwave-patches/`, SKILL.md's "load into the console") and
it is why the harnesses regex-extract functions out of `deckwave.js` and
`eval` them, which is how they all died on a CRLF checkout. Native ES modules
(`<script type="module">`, `import`/`export`, served as plain files) are
INSIDE the rule, not a breach of it, and are the right move the day there is
a concrete driver — the harnesses importing real modules, or a wrapper shell
— and churn without one. Do not add a bundler to get there; do not refuse
`import` to avoid it.

**Never change a threshold, calibration constant, or detector by reasoning.**
Every threshold here was set by measuring live signal, and four were wrong the
first time because a number was chosen without measuring the range. If a change
would move one, say so and ask the user to test it. This applies to detector
inputs too: changing what a detector *sees* changes its output.

**Claims that must be preserved.** These are load-bearing honesty, not hedging:

- Confidence is on Essentia's 0–5.32 scale and is NOT comparable to any other
  detector's number.
- Energy is a CONSTRUCTED index (45% loudness, 25% brightness, 30% tempo), not
  a measurement. The weights were chosen, not fitted.
- The chromagram is NOT a piano roll.
- The loudness panel is RELATIVE — K-weighting is approximated.
- Score determinism across browsers is UNTESTED.
- When the sequencer returns fewer tracks than requested, that is the gate
  working, not a failure. **As of 2026-08-18 it should almost never happen:**
  a track the gate cannot reach is now played STRAIGHT rather than dropped.
  If a build still comes back short, that is worth investigating.
- **Grid error IS beatmatch error, and that is a derivation, not a metaphor.**
  The engine stretches by `tempo / meta.bpm` while aligning to `meta.beats`;
  if those disagree by 6% the transition is 6% out. That is why the pool gate
  measures it and no longer measures Essentia confidence.
- **"Played straight" is not a quality judgement.** An unlocked track is
  unstretched because it is not being beatmatched — never print `0.0%` stretch
  against one, it reads as the best transition on screen.
- **The 9% grid cut is DERIVED but UNTESTED BY EAR.** The distribution has an
  empty band from 7.50% to 11.04% and any cut inside it selects the same five
  tracks. About 3% is the other defensible answer and plays 22 straight.
  `DW.lock.maxGridErrPct` is live; it needs the keeper, not an argument.

**Do not label an axis with numbers the project chose.** The VU scale is
aligned to −6 dBFS by decision, not standard. Printing dB against it would
lend a chosen number the authority of a measured one.

## Verification discipline

This is the project's recurring failure: **seven diagnostics across two
sessions returned confident answers about nothing.** See BUILD-LOG Acts 18 and
21 for all seven and why each was worthless.

**State what would falsify a check before trusting it.** A test whose pass
condition does not exclude the failure mode is decoration.

Specifically, these do NOT work and have all lied here:

- Counting lit or non-background pixels — a placeholder, an axis, and a flat
  line are all non-zero.
- Checking an element exists in the DOM — it can exist under a clip.
- Onset matching with loose tolerance — onsets outnumber beats; everything
  matches.

What works: **draw twice with real signal between, and diff.** Hit-test with
`elementFromPoint`. Read state from an accessor rather than inferring it from
rendering — `DWPANELS.hist()` and `DW._dev` exist because unobservable
components can only be debugged by guessing.

**Write the ledger row as you catch it, tagged — do not wait for me.**
A finding that needs my confirmation still gets written; mark it
**`[INFERRED]`** and say what would confirm it. I flip it to **`[CONFIRMED]`**
when I have heard or seen the thing. Changing a tag costs nothing; recovering
a finding lost to compaction costs a session, and has.

**Write findings down when you make them.** A researched answer that lives
only in the conversation is lost at the next compaction — that has already
happened once here, and I contradicted my own earlier research seven hours
later. After any compaction, read the original transcript in
`~/.claude/projects/` and diff it against what the summary carried; it
recovered a working answer that the summary had dropped entirely.

**The user's ear is an instrument.** On the beat-phase question it resolved in
one A/B what three measurements could not. Take their reports seriously and
literally; "it doesn't pop when I jump directly to it" was the whole diagnosis.

## Current state

- **2026-08-19, keeper away: a cold-read session, ledger rows 46–59, version
  0.7.1.** Read BUILD-LOG Act 26 first. The two that change what the deck
  does: **`chain()` now re-bases the rolling target after a REACH track**
  (it never did; only the planner did — ledger 49, confirmed live on a
  synthetic corpus), and **stepping stones are pulled from the tail when a
  route commits** so nothing plays twice (46, measured). Plus: a plan token
  guards `chain()`'s decode await; a cancelled scheduled deck puts the target
  back; `reorder({now})` survives an undecodable incoming track; queuing an
  already-played row keeps `idx` on the deck. **None heard.**
- **Four offline harnesses now, all `node tools/check-*.js`:** `check-pool`
  (18), `check-route` (18), `check-player` (28 — the Player IIFE under a fake
  AudioContext), `check-panels` (39 — every panel against six bundle states,
  captured text, and the D6 glossary map). Each new check was run against the
  old source first and failed there. **They are CRLF-proof now; they were
  not, and a fresh checkout on this machine killed all three with FATAL.**
- **The render bundle carries the deck: `D.now next prev prevRate deck
  nextDeck`** (20 entries — PROMPTS.md §1 tracks the count). Every panel, the
  header and the card read the deck first and the list index as fallback,
  and none prints a stretch against a straight track. `DW.nextDeck` and
  `DW.prevDeck` exist for the same reason.
- **The score format gained `straight` and `dwellSec` per step** (additive,
  still version 1) and `load()` restores the classification; SCORE-FORMAT.md
  has it. A score saved before this day loads unchanged.
- **D1 closed** (`▾ save cache` / `▴ load cache`), **D6 half-closed** (every
  panel has a term, the map is audited at startup and in the harness, stale
  gate/stretch/corpus text corrected, unverified links are search links; the
  flags are still false). `serve.py` no longer serves dotted or denied paths
  under %-encoding or a different case.
- **iOS, 2026-08-19 (0.7.2, BUILD-LOG Act 27):** the boot gate asks for
  WebAssembly + AudioWorklet, not `showDirectoryPicker`; folders/tracks fall
  back to `<input type=file>` (`webkitdirectory` is REAL on iOS 18.4+ —
  checked); FLAC the browser refuses goes through `DWFLAC` (vendored libflac,
  measured against Chromium's decode to one LSB; **24-bit comes from libflac.js
  as 4-byte int32**); `analyse()` releases the decoded buffer before WASM and
  the excerpt is a bit-identical slice of the whole-track mono. **Nothing has
  run on an iPhone; analyser peak on iOS is unmeasured; screen-lock suspension
  and no tab capture on iOS are not solved.** `tools/check-flac.js` needs the
  library on disk. **Android:** Chrome 132+ has the File System Access API
  (desktop path, no fallback); below 132 `webkitdirectory` is files-only and
  **131 crashes on a directory pick**, so `folderInputUsable()` refuses it by
  UA there. No `getDisplayMedia` on any phone. ROADMAP "Android — 2026-08-19".
  **Background play:** `phone:` select (DWPHONE) — `keep screen on` (wake lock,
  known to work) and `lock-screen audio` (mix → MediaStream → `<audio>` +
  Media Session; **the experiment — WebKit may or may not keep the feeding
  graph alive at lock; falsifier in ROADMAP "Background play"**). Off by
  default; `DW.outputStream(on)` swaps the sink, nothing upstream changes.
- **The deny-list fix is on disk but the server that was already running
  predates it** — `python tools/serve.py --stop` then start again to pick it
  up. Assets are served from disk, so everything else was live immediately.

- **The re-scan has RUN.** 2026-08-18, 179 tracks at `ANALYSIS_V = 2`, zero
  failures, 12.0 minutes, peak 851 MB. Every grid now covers at least 99% of
  its track (median 99.71%, worst shortfall 0.97s); the latest beat in the
  library went 119.9s → 506.23s. BUILD-LOG Act 22 has the full account.
- **The library moved and grew.** `C:\Claude\Music\LukHash`, **189 tracks**,
  flat, 4.47 GB. All 189 cache keys survived the move (`name|size|mtime`), so
  nothing re-analysed. `Transient Offworld` (10 tracks) had never been scanned
  — it existed only as an unflattened album folder. **SCANNED 2026-08-18** and
  confirmed by the keeper: 219 records in the cache, all ten Transient Offworld
  records now v2. The library is live at the new path and the corpus the
  sequencer builds from is chiptune only.

  Consequence, and it is the one to remember: **`normalise()` has now re-run
  against a pure-chiptune corpus**, so every energy figure and the whole arc
  differ from anything measured before this date. Comparisons across that line
  are not like-for-like.
- **The corpus is chiptune only now, and that changes the arc.** The 28
  non-chiptune imports roughly doubled the brightness range that `normalise()`
  scales against; removing them shifts energy on 191 tracks by a median 0.039
  and **changes the rank of 181 of them**. No purge needed: `DB.all()` is never
  called, `corpus` starts empty each load and is filled only by `ingest()`, so
  scanning the new folder is sufficient. BUILD-LOG Act 23.
- **PHASE: RESOLVED, and it was never phase.** 2026-08-18, after the worklet
  upgrade the keeper reported the popping gone. That was the stated falsifier:
  a non-dropping worklet removing the symptom entirely means phase was never
  audible here. D5's audible half closes as a MISATTRIBUTION, not a fix — the
  whole-track grid was still right for coverage, which was measured separately.
  One report, one pair of tracks; if popping returns on other material, reopen.
- **How it was confounded, kept because it will happen again.** The grid
  coverage half of D5 is verified. The popping-through-a-mix half rested on
  "clean alone, clean jumped-to, pops through a mix" — but the first deck and
  any jumped-to deck run at `rate = 1.0`, and only chained decks are stretched.
  The old SoundTouch worklet (0.3.0) dropped samples ONLY when stretching: 0
  gaps/sec at 1.00, 10 gaps/sec at 1.08. So that A/B separated stretched from
  unstretched just as well as one deck from two, and discriminates nothing.
  BUILD-LOG Act 21 carries the full note.
- **Worklet upgraded 0.3.0 → 2.1.1 (LGPL-2.1 → MPL-2.0), 2026-08-18.** Not a
  drop-in: `tempo` is gone, the source changes speed and the worklet
  compensates pitch. Measured clean offline and verified to load in-browser.
  **How it SOUNDS is unverified** — and if the popping through a mix now goes
  away entirely, phase was never audible here. That is the test.
- **The re-scan moved two things nobody asked for.** Three tracks flipped to
  double tempo with the grid doubling to match (Perpetual Motion, PROXIMA,
  Galaxy) and all three still pass the confidence gate; and confidence fell
  corpus-wide, median 2.181 → 1.783, taking the sequencer pool from 170 to 160.
  Both need the user's ear and decision — do not adjust a threshold to hide
  either.
- **Build is a CHOICE since 2026-08-19:** `build set · all tracks` (the
  no-discard build below, still the default) or `build · best matches` —
  locked grids only, every transition inside the gate, the set ENDS when the
  gate is exhausted and the log says what was left out. `DW.build({mode:
  'best'})`. So "fewer tracks than requested is the gate working" is true
  again — for `best`, by design.
- **Nothing is discarded from a set any more, 2026-08-18.** The confidence
  gate is gone (it was measuring the wrong thing — BUILD-LOG Act 25) and the
  stretch gate no longer ends the set: an unreachable track plays straight and
  repositions the set to its own tempo. Measured on the real corpus: **171 of
  171 placed, 9 straight (5 untrusted grid, 4 out of reach), 162 beatmatched.**
  **[INFERRED]** — 8 offline checks pass; nobody has heard a straight
  transition yet, and the reach jumps are large (167 → 100 bpm in one case).
  **Correction 2026-08-19: "repositions the set" was true of the PLAN only.
  The deck did not re-base until ledger 49** — so a straight transition heard
  before that date would have been followed by a wrongly-stretched track.
- **`sequence()` mutates the shared corpus objects.** `_stretch`, `_tempoAt`,
  `_locked`, `_unlocked` are stamped on the metas, so building twice restamps
  the first set's rows underneath it. Known, not fixed, and it produced a
  phantom test failure once already. `commit()` deletes `_dwell` for the same
  reason.
- **Routing reached the deck for the first time, 2026-08-18.** Every scenic
  route and fast blend since patch 09 was inert in audio: `commitAndRepair()`
  returns a NEW array and `applyRoute()` gave it to the dashboard only, while
  the Player kept the array captured at play(). `DW.reorder(seq)` now adopts
  the caller's array so the two are one object again. **Fast blend also leaves
  the current track at the next downbeat now** — that is a behaviour change,
  not just a fix. BUILD-LOG Act 24, ledger 40. **[CONFIRMED]** by the keeper
  2026-08-18 — *"it's looking/sounding tight now"* — after they had already
  reached the mechanism themselves: *"we are not on demoscene right now."*
- **Now-playing and the track list read the DECK now, not the list index.**
  `DW.nowMeta` is the meta object on the playing deck. The keeper caught the
  old behaviour with *"we are not on demoscene right now"* — the panel naming
  a track they were not hearing. Ledger 33 and 40 are the same class; when a
  component can be TOLD the truth, do not let it infer it.
- **The route panel is the standing check.** It draws
  `set[state.idx] === DW.nowMeta` as `LIST ≠ DECK` in red. That one line is
  what would have caught ledger 40, 33 and 38, and it is now on screen instead
  of in a comment.
- **`settle` exists and is OFF.** Riding a stretched deck back to its own speed
  after a bad blend. Turning it on makes the rolling tempo the current track's
  BPM instead of the 35%-drift target, so it changes the whole plan downstream,
  and 45s is chosen not measured. ROADMAP D8. Do not switch it on for the
  keeper without saying what it changes.
- **"Songs with brackets won't load" is CLOSED as a misattribution.** It was
  ledger 40, not the filenames: those tracks sit at ~140 bpm, outside the gate
  from most of the set, so the only way to reach them was a route — and routes
  never reached the deck. Both named tracks now play. The lesson is cheap and
  worth keeping: **"won't load" from the keeper may mean "can't get there"** —
  check the BPM against the set tempo before touching the filesystem. ROADMAP
  D9. `audit set` stays; it is a real instrument either way.
- **THE PHONE WORKS, 2026-08-19.** iPhone 16 Pro Max / iOS 26.6 / Safari:
  189 tracks scanned to completion on the device (507 s track included), set
  plays. Library arrived as one zip over `serve.py --music`; folder picked via
  iOS 18.4+ `webkitdirectory`. Unknown still: scan time net of interruptions,
  native-vs-libflac decode (`◎ audit set` log line). ROADMAP "iOS, what is
  solved" §3 updated. The `phone:` select and the lock-screen experiment are
  next.
- **Confirmed by the keeper 2026-08-19, by ear, on `build · best matches`:**
  Moments → Alive → FINAL CHAPTER → ROCK 64 — *"hot. Nice mix."* Recorded in
  LISTENING.md "Heard". First ear-level report on the best-matches build.
- **Confirmed by the keeper 2026-08-18:** the now-playing bar fills (ledger 34),
  tooltips follow a swapped tile (ledger 37), and **set journeys sound fine** —
  their words, *"they seem quite fine"*, which is the first ear-level
  confirmation the arc holds on the pure-chiptune corpus.
- `evidence/` holds the pre-fix cache, 219 records, none with a beat past
  119.9s. It cannot be regenerated.
- **Publishing: LAUNCH IS 2026-08-24, on GitHub, no later** (keeper,
  2026-08-19). `docs/LAUNCH.md` is the checklist — what must be decided before
  the push (private research, `_source/`), what the tree needs, what does not
  have to be true by then. The push itself is the keeper's act: the patent
  gate is lifted, but until that day nothing is published and there is no git
  remote. Do not create one or push without being asked.
  **`docs/research/` (2026-08-19) holds the 23 research artefacts behind that
  decision** — four adversarial IP reviews all say "novel integration, not
  invention; publish defensively"; the rest are engine/platform/business
  research plus an `adjacent/` set from the persona project. Several are
  marked *private* in its README (finances, corporation, patent strategy) —
  decide about that directory before anything is ever published. Whether the
  provisional draft in there was ever filed is not recorded; the keeper knows.

## Running it

```bash
python tools/serve.py          # localhost, 8777. Safe to run twice
python tools/serve.py --stop   # stop it
python tools/serve.py --lan    # LAN, HTTPS, 8443 — cert already exists
```

`.claude/launch.json` declares it so the harness owns the lifecycle.

Reloading the page destroys the loaded set and any listen-mode capture. **Say
so before reloading during a listening session** — it costs the user their
work, not just a page.
