#!/usr/bin/env python3
"""Cut a canonical package: _source/deckwave-<VERSION>.zip

WHY THIS EXISTS. The CHANGELOG opens with "Earlier packages from the
2026-08-17 session were overwritten in place and no longer exist." They were
built by hand, so the contents were whatever was remembered at the time.
Two packages shipped missing files that index.html loads.

So the file list is DERIVED FROM index.html rather than typed here. Every
src= and href= the page references is resolved and must exist, or the build
refuses. A package that cannot run is worse than no package: it looks like a
restore point and is not one.

Refuses to overwrite an existing version — the lineage is the point.
Pass --force only to rebuild one you have just deleted on purpose.

    python tools/package.py
    python tools/package.py --force
"""
import os, re, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Everything not reachable from index.html, listed explicitly. Directories are
# taken whole; a missing one is a hard error, a missing file inside is not.
EXTRA_FILES = ['index.html', 'VERSION', 'CHANGELOG.md', 'README.md', 'SKILL.md',
               'LICENSE', 'NOTICE', 'CLAUDE.md']
EXTRA_DIRS = ['docs', 'references', 'tools', 'themes', 'vendor']
# Never packaged: the source archives (recursive), the evidence set (large and
# separately preserved), and anything git ignores.
SKIP_DIRS = {'_source', 'evidence', '.git', '__pycache__', 'deckwave-patches',
             # docs/research holds private IP, financial and corporate
             # material (see its README); the package is the software
             'research'}
SKIP_EXT = {'.pyc', '.pem', '.key', '.pfx', '.p12'}


def referenced_by_index():
    """Every local path index.html asks the browser to load."""
    html = open(os.path.join(ROOT, 'index.html'), encoding='utf-8').read()
    hits = re.findall(r'(?:src|href)\s*=\s*["\']([^"\']+)["\']', html)
    out = []
    for h in hits:
        if h.startswith(('http://', 'https://', '//', 'data:', '#')):
            continue
        out.append(h.lstrip('./'))
    return out


def main():
    force = '--force' in sys.argv
    version = open(os.path.join(ROOT, 'VERSION'), encoding='utf-8').read().strip()
    out = os.path.join(ROOT, '_source', 'deckwave-%s.zip' % version)

    if os.path.exists(out) and not force:
        print('refusing: %s already exists.' % os.path.relpath(out, ROOT))
        print('Bump VERSION, or pass --force to rebuild it deliberately.')
        return 1

    # 1. everything the page loads — missing means the package cannot run
    wanted, missing = [], []
    for rel in referenced_by_index():
        (wanted if os.path.isfile(os.path.join(ROOT, rel)) else missing).append(rel)
    if missing:
        print('refusing: index.html references files that do not exist:')
        for m in missing:
            print('   ' + m)
        return 1

    # 2. the fixed extras
    for rel in EXTRA_FILES:
        if os.path.isfile(os.path.join(ROOT, rel)):
            wanted.append(rel)
    for d in EXTRA_DIRS:
        base = os.path.join(ROOT, d)
        if not os.path.isdir(base):
            print('refusing: expected directory %s is missing' % d)
            return 1
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [x for x in dirnames if x not in SKIP_DIRS]
            for f in filenames:
                if os.path.splitext(f)[1].lower() in SKIP_EXT:
                    continue
                wanted.append(os.path.relpath(os.path.join(dirpath, f), ROOT)
                              .replace(os.sep, '/'))

    seen, files = set(), []
    for rel in wanted:
        if rel not in seen:
            seen.add(rel)
            files.append(rel)
    files.sort()

    os.makedirs(os.path.dirname(out), exist_ok=True)
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for rel in files:
            z.write(os.path.join(ROOT, rel), 'deckwave/' + rel)

    size = os.path.getsize(out)
    print('%s  ·  %d files  ·  %.1f MB'
          % (os.path.relpath(out, ROOT), len(files), size / 1048576.0))
    scripts = [f for f in files if f.startswith('assets/')]
    print('  %d assets, all %d files index.html loads verified present'
          % (len(scripts), len(referenced_by_index())))
    return 0


if __name__ == '__main__':
    sys.exit(main())
