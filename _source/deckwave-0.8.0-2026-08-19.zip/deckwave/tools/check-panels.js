/* Every registered panel, drawn against the bundle states that have broken
   panels before: no set, a set with nothing playing, a straight (unlocked)
   track on the deck, a crossfade in progress, a loaded set where the list
   and the deck disagree, and the listen-mode bundle with no set at all.

   Two kinds of check, each stating its falsifier:
     · it must not THROW. The loop stashes a panel's error, so a throw is
       one dead tile — but the fixed strips had no stash at all until
       2026-08-19, and a throw there took every panel with it.
     · it must not PRINT A STRETCH FIGURE against a track played straight.
       The text a panel writes is captured from fillText/strokeText and
       searched for the patterns CLAUDE.md forbids: ×1.000, +0.0%, 0.0%.
       Falsifier: any such string while the deck's track is _unlocked.

   Pixel counting is not a check and none is done here.

       node tools/check-panels.js
*/
const fs = require('fs');
let fails = 0, checks = 0;
const ok = (name, cond, falsifier) => {
  checks++;
  if (!cond) { fails++; console.log('  FAIL  ' + name + '\n        falsifier hit: ' + falsifier); }
  else console.log('  pass  ' + name);
};

/* ── a browser-shaped global, just enough to load the panel files ─────── */
const store = {};
global.window = global;
global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } };
global.performance = { now: () => Date.now() };
global.document = { createElement: () => ({ style: {}, getContext: () => ctx(), appendChild() {}, classList: { add() {}, remove() {}, contains: () => false } }),
                    getElementById: () => null, addEventListener() {} };
global.requestAnimationFrame = () => 0; global.cancelAnimationFrame = () => {};
global.console.warn = () => {};

/* a 2D context that records text and never throws */
const texts = [];
const gradient = () => ({ addColorStop() {} });
function ctx() {
  const c = { canvas: { width: 320, height: 200 }, fillStyle: '', strokeStyle: '', lineWidth: 1, font: '',
    textAlign: '', textBaseline: '', globalAlpha: 1, shadowBlur: 0, shadowColor: '', lineCap: '', lineJoin: '',
    fillRect() {}, strokeRect() {}, clearRect() {}, beginPath() {}, closePath() {}, moveTo() {}, lineTo() {},
    arc() {}, arcTo() {}, ellipse() {}, rect() {}, fill() {}, stroke() {}, save() {}, restore() {},
    translate() {}, rotate() {}, scale() {}, setTransform() {}, resetTransform() {}, clip() {},
    setLineDash() {}, getLineDash: () => [], quadraticCurveTo() {}, bezierCurveTo() {},
    createLinearGradient: gradient, createRadialGradient: gradient,
    measureText: s => ({ width: String(s).length * 4.6 }),
    fillText(s) { texts.push(String(s)); }, strokeText(s) { texts.push(String(s)); },
    drawImage() {}, getImageData: (x, y, w, h) => ({ data: new Uint8ClampedArray(w * h * 4), width: w, height: h }),
    putImageData() {}, createImageData: (w, h) => ({ data: new Uint8ClampedArray(w * h * 4), width: w, height: h }) };
  return c;
}

/* engine surface the panels read */
const mkTrack = (name, bpm, o) => Object.assign({ name, bpm, camelot: '8A', key: 'A', scale: 'minor', energy: .5,
  dur: 240, conf: 1.2, beats: Array.from({ length: 480 }, (_, i) => +(i * 60 / bpm).toFixed(3)) }, o || {});
const T0 = mkTrack('LukHash - A - 01 one', 120, { _stretch: 1 });
const T1 = mkTrack('LukHash - A - 02 two', 124, { _stretch: 0.968 });
const TS = mkTrack('LukHash - A - 03 straight', 151, { _stretch: 1, _unlocked: true, _unlockReason: 'grid', _gridErr: 28.3 });
const TR = mkTrack('LukHash - A - 04 reach', 100, { _stretch: 1, _unlocked: true, _unlockReason: 'reach' });
const T2 = mkTrack('LukHash - A - 05 five', 102, { _stretch: 0.98 });
const SET = [T0, T1, TS, TR, T2];

let DWstate = { idx: 0, of: 0, tempo: 0, now: null, next: null, live: 0, ctx: 'none' };
let deck = null, nextDeck = null, nowMeta = null, nextMeta = null, blend = null, elapsed = 0;
global.DW = {
  get state() { return DWstate; }, get deck() { return deck; }, get nextDeck() { return nextDeck; },
  get nowMeta() { return nowMeta; }, get nextMeta() { return nextMeta; }, get blend() { return blend; },
  get elapsed() { return elapsed; }, get dwellFloor() { return 45; },
  camScore: (a, b) => (a === b ? 1 : .5), corpus: SET, lock: { maxGridErrPct: 9 },
  Player: { analyser: null }, log: []
};
global.DWNAV = { queue: null, active: null, GATE: .08, DRIFT: .35, reachable: (T, t) => Math.abs(T / t.bpm - 1) <= .08,
  history: [], stretchFor: (T, b) => Math.abs(T / b - 1) };
global.DWREGISTER = { col: () => null, mode: { on: false }, update: () => ({ centroidHz: 0, band: '', hue: 0 }), tau: .985 };
global.DWVU = { state: { L: .3, R: .3, pkL: .4, pkR: .4 }, feed() {} };
global.DWSTEREO = () => ({ rmsL: .3, rmsR: .3, width: .5, corr: .9 });
global.DWLISTEN = { active: false, analyser: null, L: null, R: null };
global.DWMSG = { term: () => null };

for (const f of ['assets/deckwave-panels.js', 'assets/deckwave-sprites.js', 'assets/patch-01-spectrogram.js',
                 'assets/panel-wayposts.js', 'assets/panel-centre.js', 'assets/panel-route.js']) {
  try { eval(fs.readFileSync(f, 'utf8').replace(/\r\n/g, '\n')); }
  catch (e) { console.log('FATAL loading ' + f + ': ' + (e.stack || e)); process.exit(1); }
}
const P = global.DWPANELS;
/* list() returns {k, n, hint}. The first version of this file mapped `x.id`,
   got 19 undefineds, P.get() returned nothing for each, and every "no panel
   throws" check passed without drawing a single panel — the exact vacuous
   pass this project keeps a table about. Resolve every id to a draw function
   up front and refuse to run if any does not. */
const ids = P.list().map(x => x.k);
const unresolved = ids.filter(id => !P.get(id) || typeof P.get(id).draw !== 'function');
if (!ids.length || unresolved.length) {
  console.log('FATAL: panel ids did not resolve to draw functions: ' + JSON.stringify(unresolved));
  process.exit(1);
}

const wave = new Uint8Array(2048).fill(128), freq = new Uint8Array(1024).map((_, i) => Math.max(0, 200 - i));
const Tk = { bg: '#000', line: '#111', dim: '#777', ac: '#0ff', ac2: '#f0f', bad: '#f55', fn: 'monospace', g() {} };
const bundle = o => Object.assign({ wave, freq, set: SET, state: DWstate, L: wave, R: wave,
  stereo: { rmsL: .3, rmsR: .3, width: .5, corr: .9, L: wave, R: wave }, vu: global.DWVU.state,
  hits: [], flux: .01, hit: false, transLeft: null, blend, elapsed,
  now: nowMeta, next: nextMeta, prev: null, prevRate: 1, deck, nextDeck }, o || {});

let drawn = 0;
function drawAll(label, D, assertNoStretchText) {
  let threw = [];
  for (const id of ids) {
    const p = P.get(id);
    texts.length = 0; drawn++;
    /* draw three times — history buffers and per-panel state need a second
       and third frame to reach the branches that read them */
    for (let k = 0; k < 3; k++) {
      try { p.draw(ctx(), 320, 200, Tk, D); }
      catch (e) { threw.push(id + ': ' + e.message); break; }
    }
    if (assertNoStretchText) {
      const bad = texts.filter(s => /×1\.000|(^|[^0-9.])[+\-]?0\.0%/.test(s));
      ok(label + ' · ' + id + ' prints no stretch figure against the straight deck', bad.length === 0,
         JSON.stringify(bad.slice(0, 3)));
    }
  }
  ok(label + ' · no panel throws', threw.length === 0, threw.join(' | '));
}

console.log('\n── panels: ' + ids.length + ' registered ──────────────────────────────────');

/* 1. nothing loaded at all */
DWstate = { idx: 0, of: 0, tempo: 0, now: null, next: null, live: 0, ctx: 'none' };
drawAll('no set', bundle({ set: [], wave: null, freq: null, L: null, R: null, stereo: null }));

/* 2. a set built, nothing playing (idx survives stop) */
DWstate = { idx: 4, of: 5, tempo: 0, now: null, next: null, live: 0, ctx: 'none' };
drawAll('set built, stopped, idx at the end', bundle({}));

/* 3. idx beyond the end of a SHORTER set loaded while stopped — the P.arc case */
DWstate = { idx: 7, of: 5, tempo: 120, now: null, next: null, live: 0, ctx: 'none' };
drawAll('idx past the end of the list', bundle({ set: SET.slice(0, 3) }));

/* 4. a locked track playing normally, next scheduled */
nowMeta = T0; nextMeta = T1; elapsed = 60;
deck = { meta: T0, name: T0.name, bpm: 120, camelot: '8A', rate: 1, startRate: 1, playedBpm: 120, stretchPct: 0,
         settling: false, settleLeft: 0, dwell: null, stepping: false, elapsed };
nextDeck = { meta: T1, name: T1.name, bpm: 124, camelot: '8A', rate: 120 / 124, straight: false, reason: null, startsAt: 300, entry: 0 };
blend = { in: 164, at: 224, dur: 240, xfade: 16, frac: 224 / 240, fadeFrac: 16 / 240 };
DWstate = { idx: 0, of: 5, tempo: 120, now: T0.name, next: T1.name, live: 2, ctx: 'running' };
drawAll('locked track playing', bundle({ transLeft: 164 }));

/* 5. a STRAIGHT track on the deck, locked one next: no panel may print a stretch */
nowMeta = TS; nextMeta = TR; elapsed = 30;
deck = { meta: TS, name: TS.name, bpm: 151, camelot: '8A', rate: 1, startRate: 1, playedBpm: 151, stretchPct: 0,
         settling: false, settleLeft: 0, dwell: null, stepping: false, elapsed };
nextDeck = { meta: TR, name: TR.name, bpm: 100, camelot: '8A', rate: 1, straight: true, reason: 'reach', startsAt: 300, entry: 0 };
blend = { in: 194, at: 224, dur: 240, xfade: 16, frac: 224 / 240, fadeFrac: 16 / 240 };
DWstate = { idx: 2, of: 5, tempo: 120, now: TS.name, next: TR.name, live: 2, ctx: 'running' };
drawAll('straight track on the deck', bundle({ transLeft: 194 }), true);

/* 6. a crossfade in progress, 4s after the handover: prev is the outgoing */
nowMeta = T1; nextMeta = TS; elapsed = 4;
deck = { meta: T1, name: T1.name, bpm: 124, camelot: '8A', rate: 120 / 124, startRate: 120 / 124, playedBpm: 120, stretchPct: -3.23,
         settling: false, settleLeft: 0, dwell: null, stepping: false, elapsed };
nextDeck = null; blend = { in: 220, at: 224, dur: 232, xfade: 16, frac: 224 / 232, fadeFrac: 16 / 232 };
DWstate = { idx: 1, of: 5, tempo: 121.4, now: T1.name, next: null, live: 2, ctx: 'running' };
texts.length = 0;
{
  const D = bundle({ transLeft: 220, prev: T0, prevRate: 1 });
  let err = null;
  try { for (let k = 0; k < 2; k++) P.get('transition').draw(ctx(), 320, 200, Tk, D); } catch (e) { err = e.message; }
  ok('transition monitor draws a crossfade in progress', !err, 'threw: ' + err);
  const crossfade = texts.find(s => /crossfade \d+%/.test(s));
  ok('transition monitor shows crossfade PROGRESS, not 0%, four seconds into a 16s fade',
     !!crossfade && !/crossfade 0%/.test(crossfade), 'texts: ' + JSON.stringify(texts.filter(s => /crossfade|blend|OUT|IN/.test(s))));
  ok('OUTGOING is the previous track, INCOMING the deck', texts.includes('OUTGOING') && texts.includes('INCOMING') &&
     texts.some(s => /\bone\b/.test(s)) && texts.some(s => /\btwo\b/.test(s)),
     'texts: ' + JSON.stringify(texts.slice(0, 12)));
}
drawAll('crossfade in progress', bundle({ transLeft: 220, prev: T0, prevRate: 1 }));

/* 7. list ≠ deck: the deck plays a track the list no longer holds at idx */
nowMeta = T2; nextMeta = null; elapsed = 10;
deck = { meta: T2, name: T2.name, bpm: 102, camelot: '8A', rate: 1, startRate: 1, playedBpm: 102, stretchPct: 0,
         settling: false, settleLeft: 0, dwell: null, stepping: false, elapsed };
blend = { in: 214, at: 224, dur: 240, xfade: 16, frac: 224 / 240, fadeFrac: 16 / 240 };
DWstate = { idx: 1, of: 5, tempo: 102, now: T2.name, next: null, live: 1, ctx: 'running' };
texts.length = 0;
{
  const D = bundle({ set: [T0, T1, TS], transLeft: 214 });
  let err = null; try { P.get('route').draw(ctx(), 320, 200, Tk, D); } catch (e) { err = e.message; }
  ok('route panel draws with the deck playing a track not in the list', !err, 'threw: ' + err);
  ok('route panel flags LIST ≠ DECK', texts.some(s => /LIST ≠ DECK/.test(s)), 'no red line; texts ' + JSON.stringify(texts.slice(0, 6)));
  texts.length = 0; err = null;
  try { P.get('position').draw(ctx(), 320, 200, Tk, D); } catch (e) { err = e.message; }
  ok('position panel names the DECK\'s track, not the list\'s', !err && texts.some(s => /five/.test(s)) && !texts.some(s => /\btwo\b/.test(s)),
     (err ? 'threw: ' + err : 'texts ' + JSON.stringify(texts)));
}
drawAll('list ≠ deck', bundle({ set: [T0, T1, TS], transLeft: 214 }));

/* 8. listen mode, no set */
nowMeta = null; nextMeta = null; deck = null; nextDeck = null; blend = null; elapsed = 0;
global.DWLISTEN.active = true;
DWstate = { idx: 0, of: 0, tempo: 0, now: null, next: null, live: 0, ctx: 'none' };
drawAll('listen mode, no set', bundle({ set: [] }));

/* ── ROADMAP D6: every panel has a glossary term, every term exists ──────
   The dashboard's PANEL/HEAD maps are extracted from the source and checked
   against DWMSG and the registry, both directions. Falsifier: a registered
   id with no entry, an entry naming no registered id, or a value that
   DWMSG.term() cannot resolve. */
console.log('\n── glossary ↔ panel registry (ROADMAP D6) ───────────────────');
{
  const dsrc = fs.readFileSync('assets/deckwave-dashboard.js', 'utf8').replace(/\r\n/g, '\n');
  const pm = dsrc.match(/const PANEL = (\{[\s\S]*?\});/), hm = dsrc.match(/const HEAD = (\{[^}]*\});/);
  ok('PANEL and HEAD maps found in the dashboard source', !!(pm && hm), 'regex did not match — map moved?');
  if (pm && hm) {
    delete global.DWMSG;
    eval(fs.readFileSync('assets/deckwave-messages.js', 'utf8').replace(/\r\n/g, '\n'));
    const PANEL = eval('(' + pm[1] + ')'), HEAD = eval('(' + hm[1] + ')');
    const term = k => global.DWMSG.term(k);
    const noTerm = ids.filter(id => !PANEL[id]);
    ok('every registered panel has a glossary entry', noTerm.length === 0, 'missing: ' + noTerm.join(', '));
    const noPanel = Object.keys(PANEL).filter(id => !ids.includes(id));
    ok('every glossary entry names a registered panel', noPanel.length === 0, 'stale: ' + noPanel.join(', '));
    const unresolved = Object.keys(PANEL).filter(id => !term(PANEL[id])).map(id => id + '→' + PANEL[id])
      .concat(Object.keys(HEAD).filter(id => !term(HEAD[id])).map(id => id + '→' + HEAD[id]));
    ok('every mapped term resolves in DWMSG', unresolved.length === 0, 'unresolved: ' + unresolved.join(', '));
    const direct = global.DWMSG.all().filter(t => t.w && !t.verified && !/Special:Search/.test(t.w));
    ok('every unverified Wikipedia link is a search link, as the file header and tooltip promise',
       direct.length === 0, direct.map(t => t.key).join(', '));
  }
}

/* the harness must have actually drawn something, or every pass above is hollow */
ok('panels were actually drawn (' + drawn + ' draws across ' + ids.length + ' panels)', drawn >= ids.length * 7,
   'only ' + drawn + ' draws happened — the loop is not reaching the panels');

console.log('\n' + (fails ? fails + ' FAILED' : 'all passed') + ' of ' + checks + ' checks');
process.exit(fails ? 1 : 0);
