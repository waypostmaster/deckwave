/* Does the Player survive a plan change while a decode is in flight?

   chain() awaits LIB.decode() in the middle. cancelPending(), stop() and a
   second play() can all run during that await, and until 2026-08-19 the
   stale continuation carried on: it built a deck for the old next track,
   overwrote B (orphaning the deck the new plan had just scheduled, which then
   played alongside it) and re-armed the handover timer against the old exit.
   Narrow window — a decode takes a second or two and the replan has to land
   inside it — but ▶ pressed twice, or ⚡ blend fast clicked right after a
   handover, lands inside it.

   The Player IIFE is evaluated with a fake AudioContext and a LIB.decode whose
   promises this file resolves by hand, so the interleavings are exact rather
   than raced. Every check states its falsifier.

       node tools/check-player.js
*/
const fs = require('fs');
let fails = 0, checks = 0;
const ok = (name, cond, falsifier) => {
  checks++;
  if (!cond) { fails++; console.log('  FAIL  ' + name + '\n        falsifier hit: ' + falsifier); }
  else console.log('  pass  ' + name);
};

/* ── extract the Player from the real source ──────────────────────────── */
/* CRLF-proof. core.autocrlf=true checks the source out with CRLF on
   Windows, and every regex below is written against LF; on a fresh clone
   all three harnesses died with FATAL before testing anything. */
const src = fs.readFileSync(process.env.DECKWAVE_SRC || 'assets/deckwave.js', 'utf8').replace(/\r\n/g, '\n');
const a = src.indexOf('\nconst Player = (() => {');
const b = src.indexOf('\n})();\n', a);
if (a < 0 || b < 0) { console.log('FATAL: could not find the Player IIFE'); process.exit(1); }
const playerSrc = src.slice(a + 1, b + 6).replace(/^const Player = /, '');

/* ── fakes: just enough Web Audio to schedule against ─────────────────── */
const started = [];                    /* every source.start() call, in order */
const param = () => ({ value: 0, cancelScheduledValues() {}, setValueAtTime() {},
  linearRampToValueAtTime() {}, setTargetAtTime() {} });
const node = () => ({ playbackRate: param(), gain: param(), type: '', frequency: { value: 0 },
  Q: { value: 0 }, threshold: { value: 0 }, ratio: { value: 0 }, fftSize: 0,
  smoothingTimeConstant: 0, connect() {}, parameters: { get: () => param() },
  start(at, off) { this._started = { at, off }; started.push(this); },
  stop() { this._stopped = true; }, onended: null });
let now = 100;
function AC() {
  return { get currentTime() { return now; }, state: 'running',
    async resume() {}, async suspend() {}, close() {},
    audioWorklet: { async addModule() {} },
    createGain: node, createDynamicsCompressor: node, createAnalyser: node,
    createBufferSource: node, createBiquadFilter: node };
}
const AudioWorkletNode = function () { return node(); };
const ASSETS = { base: 'vendor/', files: { soundtouch: 'x' }, allowCDN: false };
const CDN = {}; const assetURL = k => ASSETS.base + ASSETS.files[k];

/* decode() hands back a promise per call; the test resolves them by name */
const pending = new Map();
const LIB = { decode(meta) {
  return new Promise((res, rej) => pending.set(meta.name, { res, rej, meta }));
} };
const settle = name => { const p = pending.get(name); pending.delete(name);
  p.res({ duration: p.meta.dur, name }); return new Promise(r => setTimeout(r, 0)); };
const fail = name => { const p = pending.get(name); pending.delete(name);
  p.rej(new Error('decode failed (test)')); return new Promise(r => setTimeout(r, 0)); };
const tick = () => new Promise(r => setTimeout(r, 0));

global.window = global;
const Player = eval(playerSrc);
const D = Player._dev;

/* a small set: grids every 0.5s so every track is 120 bpm, no stretch */
const grid = n => Array.from({ length: n }, (_, i) => +(i * 0.5).toFixed(2));
const mk = (name, dur) => ({ name, bpm: 120, camelot: '8A', dur, beats: grid(dur * 2) });
const set = [mk('t1', 240), mk('t2', 240), mk('t3', 240), mk('t4', 240)];
const x = mk('x', 200);

(async () => {
  console.log('\n── a replan during chain()\'s decode ───────────────────────');
  /* play: decode t1 → A starts, chain() begins decoding t2 */
  const p = Player.play(set, 0);
  await tick(); await settle('t1'); await p; await tick();
  ok('play() started the first deck and chain() is decoding the next',
     started.length === 1 && pending.has('t2'),
     'started ' + started.length + ' sources; pending ' + [...pending.keys()]);

  /* keeper clicks a track: blendNow(x). Its decode resolves FIRST. */
  const bn = Player.blendNow(x, { lead: 1 });
  await tick(); await settle('x'); await bn; await tick();
  ok('blendNow scheduled x as the next deck', D.B && D.B.track.meta === x,
     'B is ' + (D.B && D.B.track.meta.name));
  const bDeck = D.B;

  /* now the ORIGINAL chain()'s decode of t2 comes back, late */
  await settle('t2'); await tick();
  /* Falsifier for the fix: a third source started (t2's deck), or B no
     longer the blend-now deck. Under the old code both happened. */
  ok('the stale chain() built nothing — still exactly two decks started',
     started.length === 2, started.length + ' sources started; t2 was scheduled by a stale plan');
  ok('B is still the blend-now deck, not overwritten by the stale plan',
     D.B === bDeck && D.B.track.meta === x, 'B is now ' + (D.B && D.B.track.meta.name));
  ok('the blend-now target is next in the order', D.order[D.idx + 1] === x,
     'order[idx+1] is ' + (D.order[D.idx + 1] && D.order[D.idx + 1].name));

  console.log('\n── ▶ pressed twice while the first decode is in flight ───────');
  Player.stop(); started.length = 0; pending.clear();
  const set2 = [mk('u1', 240), mk('u2', 240)];
  const p1 = Player.play(set, 0);
  await tick();
  const p2 = Player.play(set2, 0);
  await tick();
  await settle('t1');          /* the FIRST play's decode lands after the second ▶ */
  const r1 = await p1; await tick();
  await settle('u1'); const r2 = await p2; await tick();
  ok('the first play() stood down', r1 === 'superseded', 'first play returned ' + JSON.stringify(r1));
  ok('only the second set is on the air', D.A && D.A.track.meta.name === 'u1' &&
     started.filter(s => s._started).length === 1,
     'A=' + (D.A && D.A.track.meta.name) + ', ' + started.length + ' sources started');
  ok('the second play() reports normally', /^1\/2$/.test(r2), 'second play returned ' + JSON.stringify(r2));

  console.log('\n── reorder({now}) when the incoming track will not decode ────');
  Player.stop(); started.length = 0; pending.clear();
  /* a fresh order — scenario 1's placeNext() spliced x into `set` in place,
     which is the in-place idiom the dashboard relies on, and exactly why a
     second scenario must not reuse that array */
  const set3 = [mk('t1', 240), mk('t2', 240), mk('t3', 240), mk('t4', 240)];
  const p3 = Player.play(set3, 0);
  await tick(); await settle('t1'); await p3; await tick();
  await settle('t2'); await tick();             /* normal chain: t2 is B */
  ok('baseline: t2 is scheduled next', D.B && D.B.track.meta.name === 't2', 'B=' + (D.B && D.B.track.meta.name));
  /* new order: t1 (playing), then a track that will not decode, then t3 */
  const bad = mk('bad', 240);
  const seq = [set3[0], bad, set3[2], set3[3]];
  const ro = Player.reorder(seq, { now: true, lead: 1 });
  await tick();
  ok('reorder is decoding the bad track', pending.has('bad'), 'pending: ' + [...pending.keys()]);
  await fail('bad');                            /* decode rejects */
  await tick(); await tick();
  /* the fallback chain() tries the bad track again, fails, splices, moves on */
  if (pending.has('bad')) await fail('bad');
  await tick(); await tick();
  ok('chain() fell back and is now decoding the track after the bad one',
     pending.has('t3'), 'pending: ' + [...pending.keys()] + ' — the set is stalled with no exit planned');
  await settle('t3'); const ror = await ro; await tick();
  ok('the bad track was spliced out of the order', !seq.includes(bad), 'bad is still at ' + seq.indexOf(bad));
  ok('the playing deck has an exit scheduled again', D.A && D.A.outAt != null,
     'A.outAt is ' + (D.A && D.A.outAt) + ' — the track will play to its end and the set stops');
  ok('t3 is now the next deck', D.B && D.B.track.meta.name === 't3', 'B=' + (D.B && D.B.track.meta.name));
  ok('reorder said what it did', /cannot load bad/.test(ror) && /skipped/.test(ror), 'returned ' + JSON.stringify(ror));
  ok('list and deck still agree', seq[D.idx] === D.A.track.meta, 'LIST ≠ DECK');

  console.log('\n── the DECK re-bases after a reach track, like the planner ───');
  /* sequence(), resequenceTail() and verify() all reposition the rolling
     target to a reach track's own bpm. chain() did not — both straight modes
     left the target alone — so the first locked track after a 167 → 100
     reach jump was chained at 167/bpm: ×1.67 on a track the plan printed at
     0%. Falsifier: the deck built for `after` has rate ≠ reach.bpm/after.bpm. */
  Player.stop(); started.length = 0; pending.clear();
  const a0 = mk('a0', 240); a0.bpm = 167;
  const reach = mk('reach', 240); reach.bpm = 100; reach._unlocked = true; reach._unlockReason = 'reach'; reach._locked = true;
  const after = mk('after', 240); after.bpm = 102;
  const gridT = mk('gridT', 240); gridT.bpm = 140; gridT._unlocked = true; gridT._unlockReason = 'grid'; gridT._locked = false;
  const after2 = mk('after2', 240); after2.bpm = 104;
  const set4 = [a0, reach, after, gridT, after2];
  const p4 = Player.play(set4, 0);
  await tick(); await settle('a0'); await p4; await tick();
  await settle('reach'); await tick();
  ok('the reach track is chained straight (rate 1)', D.B && D.B.rate === 1 && D.B.entry === 0,
     'B rate ' + (D.B && D.B.rate) + ' entry ' + (D.B && D.B.entry));
  ok('the target has moved to the reach track\'s bpm', D.tempo === 100, 'tempo is ' + D.tempo + ', expected 100');
  /* hand over by hand — the timer is real-time and the exit is minutes away */
  D.setIdx(1); D.setDecks(D.B, null); D.chain();
  await tick(); await settle('after'); await tick();
  ok('the locked track after a reach jump is stretched from the reach bpm, not the old target',
     D.B && Math.abs(D.B.rate - 100 / 102) < 1e-9,
     'rate ' + (D.B && D.B.rate) + ' — expected ' + (100 / 102).toFixed(4) + ', the old code gave ' + (167 / 102).toFixed(3));
  /* and a GRID track still moves it nowhere */
  D.setIdx(2); D.setDecks(D.B, null); D.chain();
  await tick(); await settle('gridT'); await tick();
  const tBefore = D.tempo;
  ok('a grid-unlocked track is chained straight', D.B && D.B.rate === 1, 'rate ' + (D.B && D.B.rate));
  D.setIdx(3); D.setDecks(D.B, null); D.chain();
  await tick(); await settle('after2'); await tick();
  ok('the target did not move for the grid track', D.tempo !== 140 && D.B && Math.abs(D.B.rate - tBefore / 104) < 1e-9,
     'tempo ' + D.tempo + ' rate ' + (D.B && D.B.rate) + ' — a distrusted bpm steered the set');

  console.log('\n── cancelling a scheduled deck puts the target back ───────────');
  /* chain() moves the rolling target the moment it schedules B — drift for a
     locked track, a re-base for a reach track. cancelPending() threw B away
     and left the target where B had moved it, so the replacement was chained
     against a tempo nothing was playing. Falsifier: after blendNow replaces
     a scheduled reach track, the new deck's rate is not oldTarget/bpm. */
  Player.stop(); started.length = 0; pending.clear();
  const c0 = mk('c0', 240); c0.bpm = 100;
  const cReach = mk('cReach', 240); cReach.bpm = 120; cReach._unlocked = true; cReach._unlockReason = 'reach'; cReach._locked = true;
  const cX = mk('cX', 240); cX.bpm = 104;
  const set6 = [c0, cReach, cX];
  const p6 = Player.play(set6, 0);
  await tick(); await settle('c0'); await p6; await tick();
  await settle('cReach'); await tick();
  ok('scheduling the reach track moved the target to 120', D.tempo === 120, 'tempo ' + D.tempo);
  const bn6 = Player.blendNow(cX, { lead: 1 });
  await tick(); await settle('cX'); await bn6; await tick();
  ok('cancelling it put the target back to 100', D.B && Math.abs(D.B.rate - 100 / 104) < 1e-9,
     'cX chained at ' + (D.B && D.B.rate) + ' — expected ' + (100 / 104).toFixed(4) + ' (old code: ' + (120 / 104).toFixed(4) + ')');

  console.log('\n── queuing a row that has already played ─────────────────────');
  /* placeNext() pulls the row from wherever it is. From BEFORE the playing
     track that shifts the playing track down one and idx used to stay put,
     so state.idx named the track AFTER the deck and the planned next track
     was skipped at the handover. Falsifier: order[idx] !== A.track.meta. */
  Player.stop(); started.length = 0; pending.clear();
  const set5 = [mk('q1', 240), mk('q2', 240), mk('q3', 240), mk('q4', 240), mk('q5', 240)];
  const p5 = Player.play(set5, 2);
  await tick(); await settle('q3'); await p5; await tick(); await settle('q4'); await tick();
  const qn = Player.queueNext(set5[0]);           /* q1 — already played */
  await tick(); await settle('q1'); await qn; await tick();
  ok('list and deck agree after queuing an already-played row', set5[D.idx] === D.A.track.meta,
     'idx ' + D.idx + ' names ' + set5[D.idx].name + ' while ' + D.A.track.meta.name + ' plays');
  ok('the queued row sits right after the playing track', set5[D.idx + 1] && set5[D.idx + 1].name === 'q1',
     'order after the deck: ' + set5.slice(D.idx + 1).map(t => t.name).join(','));
  ok('the planned next track is still in the set after it', set5.map(t => t.name).join(',') === 'q2,q3,q1,q4,q5',
     'order is ' + set5.map(t => t.name).join(','));
  const self = await Player.queueNext(D.A.track.meta);
  ok('queuing the playing track itself is refused', /already playing/.test(self), 'returned ' + JSON.stringify(self));
  const selfB = await Player.blendNow(D.A.track.meta);
  ok('blending the playing track into itself is refused', /already playing/.test(selfB), 'returned ' + JSON.stringify(selfB));

  Player.stop();
  console.log('\n' + (fails ? fails + ' FAILED' : 'all passed') + ' of ' + checks + ' checks');
  process.exit(fails ? 1 : 0);
})().catch(e => { console.log('FATAL: ' + (e.stack || e)); process.exit(1); });
