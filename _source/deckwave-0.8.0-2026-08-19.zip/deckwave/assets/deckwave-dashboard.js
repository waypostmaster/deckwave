/* ─────────────────────────────────────────────────────────────────────────
   DECKWAVE · DASHBOARD
   The instrument. Five panels, a track list, a transport, and the transport's
   worth of decisions that took a whole session to get right.

   Notes worth keeping, because each one was a bug first:

   · fit() iterates the LIVE canvas map, never a captured array. A stale
     snapshot leaves later-added canvases at the browser's default 300x150
     while stretched across the layout — they draw perfectly into a buffer
     nobody sized, which looks exactly like a broken renderer.

   · Panels reflow by ASPECT RATIO, and the grid can reflow without the window
     ever changing size. So the ResizeObserver watches the panel row and each
     panel, not just the window.

   · Stereo comes from whichever source is live — listen mode, or the deck's
     own analyser split into L/R. An AnalyserNode is a pass-through, so
     splitting from its output is always available. Claiming otherwise was an
     invented constraint that hid a real bug underneath it.

   · Every colour is read from a CSS custom property each frame, so a theme
     change lands on the next frame with no reload.
   ───────────────────────────────────────────────────────────────────────── */

window.DWDASH = (function () {
'use strict';

/* Last mounted dashboard, for the live-patching seam. See DW._dev — same
   rules: nothing in this application may read it, and anything built on it is
   a session experiment until it is ported into the module. */
let lastDash = null;

/* Escape before ANY interpolation into innerHTML.

   Track names are not trusted input. They come from filenames, and from the
   `name` field of a loaded score — and a score is a file this project intends
   to accept from strangers (paste a JSON, load one from a share link). A name
   of the form  Artist - Track<img src=x onerror=…>  executed here; confirmed,
   not theoretical.

   It matters more than a usual local XSS because of what the page is holding:
   live FileSystemDirectoryHandle objects for the music folder, plus ordinary
   network access. Injected script inherits both.

   Anything derived from a filename, a score field, or a prompt() goes through
   this. Values the code itself produced do not need it, but escaping them
   costs nothing and removes the judgement call from every future edit. */
const esc = s => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

const PITCH = ['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'];

const CSS = `
:host{all:initial;
  --bg:var(--dw-color-bg,#04010f); --surf:var(--dw-color-surface,#0b0424);
  --line:var(--dw-color-line,#22125c); --txt:var(--dw-color-text,#e6ddff);
  --dim:var(--dw-color-dim,#7d6eb0); --ac:var(--dw-color-accent,#22e8ff);
  --ac2:var(--dw-color-accent-2,#ff2d95); --warn:var(--dw-color-warn,#ffb02e);
  --bad:var(--dw-color-bad,#ff5470); --good:var(--dw-color-good,#3ee68a);
  --fn:var(--dw-font-mono,ui-monospace,Menlo,monospace);
  --glow:var(--dw-glow,1); --scan:var(--dw-scanline-opacity,.26);
  --rad:var(--dw-border-radius,0px);
  display:block;height:100%;font-family:var(--fn);color:var(--txt)}
*{box-sizing:border-box;margin:0}
.app{display:grid;grid-template-columns:1fr minmax(230px,clamp(230px,22vw,340px));
  grid-template-rows:auto 1fr auto;height:100vh;background:var(--bg);gap:1px}
.app::before{content:'';position:fixed;inset:0;pointer-events:none;z-index:99;
  background:repeating-linear-gradient(180deg,transparent 0 2px,rgba(0,0,0,var(--scan)) 2px 3px)}
@media(max-width:720px){.app{grid-template-columns:1fr;grid-template-rows:auto auto 1fr auto}}
.bar{grid-column:1/-1;display:flex;align-items:center;gap:clamp(8px,2vw,22px);
  padding:8px 12px;background:var(--surf);border-bottom:1px solid var(--ac2);flex-wrap:wrap}
.bar h1{font-size:clamp(11px,1.4vw,15px);letter-spacing:.3em;color:var(--ac2);
  text-shadow:0 0 calc(10px*var(--glow)) var(--ac2);font-weight:700}
.kv{display:flex;flex-direction:column;line-height:1.15}
.kv u{text-decoration:none;font-size:7.5px;letter-spacing:.18em;text-transform:uppercase;color:var(--dim)}
.kv b{font-size:clamp(11px,1.3vw,15px);color:var(--ac);font-weight:500;
  text-shadow:0 0 calc(7px*var(--glow)) var(--ac)}
.kv b.p{color:var(--ac2)} .kv b.w{color:var(--warn)} .kv b.g{color:var(--good)}
.main{display:grid;grid-template-rows:auto auto 1fr auto;gap:1px;min-height:0;overflow:hidden}
.strip{background:var(--surf);padding:6px 10px 8px;min-height:0}
.strip>u{display:block;text-decoration:none;font-size:7.5px;letter-spacing:.2em;
  text-transform:uppercase;color:var(--dim);margin-bottom:3px}
canvas{display:block;width:100%;height:100%;background:var(--bg)}
.cw{position:relative;min-height:0;height:calc(100% - 12px)}

/* panels reflow by aspect ratio — five slivers on a square screen is useless */
.tri{display:grid;gap:1px;min-height:0;grid-auto-rows:1fr;overflow:auto;
  grid-template-columns:repeat(5,1fr)}
@media (min-aspect-ratio:2/1){.tri{grid-template-columns:repeat(5,1fr)}}
@media (max-aspect-ratio:2/1) and (min-aspect-ratio:7/5){.tri{grid-template-columns:repeat(3,1fr)}}
@media (max-aspect-ratio:7/5) and (min-aspect-ratio:3/4){.tri{grid-template-columns:repeat(2,1fr)}}
@media (max-aspect-ratio:3/4){.tri{grid-template-columns:1fr}}
@media (max-width:620px){.tri{grid-template-columns:1fr}}
.tri>.strip{min-height:clamp(120px,20vh,260px);display:flex;flex-direction:column}
.tri>.strip>.cw{flex:1;min-height:0}

.side{background:var(--surf);display:flex;flex-direction:column;min-height:0;
  border-left:1px solid var(--line)}
.side>u{display:block;text-decoration:none;font-size:7.5px;letter-spacing:.2em;
  text-transform:uppercase;color:var(--dim);padding:8px 10px 5px;border-bottom:1px solid var(--line)}
.list{flex:1;overflow-y:auto;min-height:0;scrollbar-width:thin;scrollbar-color:var(--line) transparent}
.tr{display:grid;grid-template-columns:26px 1fr auto;gap:6px;padding:4px 8px;font-size:10px;
  border-bottom:1px solid rgba(34,18,92,.5);align-items:center;cursor:pointer}
.tr:hover{background:rgba(127,127,127,.08)}
.tr i{color:var(--dim);font-style:normal;font-size:8.5px}
.tr s{text-decoration:none;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tr em{font-style:normal;color:var(--dim);font-size:8.5px;white-space:nowrap}
.tr.now{background:rgba(255,45,149,.14);border-left:2px solid var(--ac2)}
.tr.now s,.tr.now i,.tr.now em{color:var(--ac2)}
.tr.next{background:rgba(34,232,255,.08)} .tr.next s{color:var(--ac)}
/* played straight: no beatmatch claimed. Marked on the tempo cell rather
   than the title, because it is a fact about the transition, not the song. */
.tr.free em{color:var(--warn)}
.tr.free{border-left:2px dashed var(--warn)}
.tr.free.now{border-left:2px solid var(--ac2)}
.tr.done s,.tr.done i,.tr.done em{opacity:.4}

.tp{grid-column:1/-1;display:flex;gap:5px;padding:7px 10px;background:var(--surf);
  border-top:1px solid var(--line);flex-wrap:wrap;align-items:center}
button{background:none;border:1px solid var(--line);color:var(--dim);font:inherit;font-size:9px;
  letter-spacing:.14em;text-transform:uppercase;padding:6px 11px;cursor:pointer;border-radius:var(--rad)}
button:hover{border-color:var(--ac);color:var(--ac)}
button.hot{border-color:var(--ac2);color:var(--ac2)}
.sep{width:1px;height:20px;background:var(--line);margin:0 3px}

/* master level. Sized to sit on the same baseline as the buttons rather than
   growing the transport's height — the row already wraps and a taller control
   would change where it breaks. */
.vol{display:inline-flex;align-items:center;gap:6px;padding:0 4px}
.vol u{font-size:8px;letter-spacing:.12em;text-transform:uppercase;color:var(--dim);
  text-decoration:none;white-space:nowrap;min-width:58px}
.vol input[type=range]{-webkit-appearance:none;appearance:none;width:74px;height:3px;
  background:var(--line);border-radius:2px;outline:none;cursor:pointer}
.vol input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
  width:9px;height:14px;border-radius:1px;background:var(--ac);cursor:pointer;
  box-shadow:0 0 6px color-mix(in srgb,var(--ac) 60%,transparent)}
.vol input[type=range]::-moz-range-thumb{width:9px;height:14px;border-radius:1px;
  background:var(--ac);border:none;cursor:pointer}
.vol input[type=range]:focus-visible{outline:1px solid var(--ac);outline-offset:3px}
.split{display:inline-flex;position:relative}
.split .face{border-right:none}
.split .arrow{padding:6px 8px;border-left:1px solid var(--line)}
.split .menu{display:none;position:absolute;bottom:calc(100% + 4px);right:0;min-width:200px;
  background:var(--surf);border:1px solid var(--ac2);box-shadow:0 0 22px rgba(0,0,0,.7);z-index:50}
.split.open .menu{display:block}
.split .menu i{display:block;font-style:normal;padding:8px 11px;font-size:9.5px;letter-spacing:.12em;
  text-transform:uppercase;color:var(--dim);cursor:pointer;border-bottom:1px solid var(--line)}
.split .menu i:last-child{border-bottom:none}
.split .menu i:hover{background:rgba(127,127,127,.12);color:var(--ac)}
.split .menu u{display:block;text-decoration:none;padding:6px 11px;font-size:8px;letter-spacing:.14em;
  text-transform:uppercase;color:var(--dim);opacity:.7;border-bottom:1px solid var(--line)}
.log{margin-left:auto;font-size:9px;color:var(--dim);white-space:nowrap;overflow:hidden;
  text-overflow:ellipsis;max-width:44vw}
.nowline{padding:6px 12px;font-size:10.5px;background:var(--surf);border-bottom:1px solid var(--line);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:none}
.nowline b{color:var(--ac2)}
.app.mini .main>.strip:not(.keep),.app.mini .tri,.app.mini .side{display:none}
.app.mini .nowline{display:block}

/* slots: swap + help controls, revealed on hover */
.strip{position:relative}
.strip>u{display:flex;justify-content:space-between;align-items:center;gap:5px}
.swap,.hbtn{opacity:0;transition:opacity .15s;flex:none;cursor:pointer;border:1px solid var(--line);color:var(--dim)}
.swap{font-size:8px;letter-spacing:.1em;padding:1px 5px;white-space:nowrap}
.hbtn{font-size:9px;width:14px;height:14px;line-height:12px;text-align:center;border-radius:50%;cursor:help}
.strip:hover .swap,.strip:hover .hbtn{opacity:1}
.swap:hover,.hbtn:hover{color:var(--ac);border-color:var(--ac)}
/* FIXED, not absolute, and placed by placeMenu(). As an absolute box inside
   the cell it was clipped by .tri's overflow:hidden — on the bottom row the
   menu ran 189px past the grid and those entries were simply unreachable,
   because its own max-height:60vh was taller than the space left below the
   button so the internal scrollbar had nothing to give. Fixed positioning
   escapes the ancestor clip; there is no transform or filter on any ancestor
   to make one a containing block. The height is clamped to the real gap at
   open time rather than to a guess at the viewport. */
.pmenu{display:none;position:fixed;min-width:190px;z-index:70;background:var(--surf);
  border:1px solid var(--ac2);box-shadow:0 0 24px rgba(0,0,0,.8);overflow-y:auto;
  overscroll-behavior:contain}
.pmenu.open{display:block}
.pmenu i{display:flex;justify-content:space-between;align-items:center;font-style:normal;padding:7px 10px;
  font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);cursor:pointer;
  border-bottom:1px solid var(--line)}
.pmenu i:last-child{border-bottom:none}
.pmenu i:hover{background:rgba(127,127,127,.14);color:var(--ac)}
.pmenu i.on{color:var(--ac2);border-left:2px solid var(--ac2)}
.pmenu i b{font-weight:400;font-size:7.5px;opacity:.55;margin-left:8px}
/* Same clipping applies to the help card on the lower rows. */
.hcard{display:none;position:fixed;z-index:80;padding:10px 12px;max-height:60vh;overflow-y:auto;
  overscroll-behavior:contain;
  background:var(--surf);border:1px solid var(--ac);box-shadow:0 0 26px rgba(0,0,0,.85)}
.hcard.open{display:block}
.hcard h4{font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);margin:0 0 6px;font-weight:500}
.hcard p{font-size:10px;line-height:1.55;color:var(--txt);margin:0 0 8px}
.hcard a{font-size:9px;color:var(--ac2);text-decoration:none;letter-spacing:.08em}
.hcard a:hover{text-decoration:underline}
.hcard em{font-style:normal;font-size:8px;color:var(--dim);display:block;margin-top:4px}
/* manual layout override beats the aspect-ratio media queries */
.app[data-cols="1"] .tri{grid-template-columns:1fr!important}
.app[data-cols="2"] .tri{grid-template-columns:repeat(2,1fr)!important}
.app[data-cols="3"] .tri{grid-template-columns:repeat(3,1fr)!important}
.app[data-cols="5"] .tri{grid-template-columns:repeat(5,1fr)!important}
.app[data-side="hide"] .side{display:none}
.app[data-side="hide"]{grid-template-columns:1fr!important}
.app[data-dense="1"] .tri>.strip{min-height:90px}
.app[data-dense="1"] .strip{padding:3px 6px 4px}
/* dropdown selector used for theme / layout */
.sel{position:relative;display:inline-flex}
.sel>button{min-width:118px;text-align:left}
.sel>button::after{content:'\\25be';float:right;opacity:.7;margin-left:8px}
.sel .menu{display:none;position:absolute;bottom:calc(100% + 4px);left:0;min-width:180px;background:var(--surf);
  border:1px solid var(--ac2);box-shadow:0 0 22px rgba(0,0,0,.75);z-index:60;max-height:52vh;overflow:auto}
.sel.open .menu{display:block}
.sel .menu i{display:flex;justify-content:space-between;align-items:center;font-style:normal;padding:8px 11px;
  font-size:9.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--dim);cursor:pointer;
  border-bottom:1px solid var(--line)}
.sel .menu i:last-child{border-bottom:none}
.sel .menu i:hover{background:rgba(127,127,127,.14);color:var(--ac)}
.sel .menu i.on{color:var(--ac2);border-left:2px solid var(--ac2)}
.sw{display:inline-flex;gap:2px;margin-left:8px}
.sw s{width:9px;height:9px;text-decoration:none;border:1px solid rgba(255,255,255,.25)}

/* header glossary: quiet mouseover, with a bridge so the link stays reachable */
.kv{position:relative;cursor:help}
.kv u{border-bottom:1px dotted transparent;transition:border-color .15s}
.kv:hover u{border-bottom-color:var(--dim)}
.tip{display:none;position:absolute;top:calc(100% + 8px);left:-6px;width:290px;z-index:200;
  padding:10px 12px;background:var(--surf);border:1px solid var(--ac);
  box-shadow:0 0 26px rgba(0,0,0,.85);cursor:default;text-align:left}
.kv:hover .tip,.tip:hover{display:block}
.tip::before{content:'';position:absolute;top:-8px;left:0;right:0;height:8px}
.tip h5{margin:0 0 5px;font-size:9.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);font-weight:500}
.tip p{margin:0 0 7px;font-size:10px;line-height:1.55;color:var(--txt);letter-spacing:0;text-transform:none}
.tip a{font-size:8.5px;color:var(--ac2);text-decoration:none;letter-spacing:.06em}
.tip a:hover{text-decoration:underline}
.tip em{font-style:normal;display:block;margin-top:4px;font-size:7.5px;color:var(--dim)}
@media(max-width:720px){.tip{width:240px;left:auto;right:-6px}}

/* now playing, bottom right */
/* Docked into the track-list column rather than floating over it. As a fixed
   overlay it covered the list and part of the transport, which is the one
   place you need to be able to read and click while a set is running. The
   column is already a flex stack with .list on flex:1, so the card takes its
   natural height at the top and the list scrolls beneath it. */
.np{background:var(--surf);border-bottom:1px solid var(--ac2);
  padding:9px 11px;font-size:10px;line-height:1.5;flex:none}
.np.hidden{display:none}
.np u{display:flex;justify-content:space-between;text-decoration:none;font-size:7.5px;letter-spacing:.2em;
  text-transform:uppercase;color:var(--dim);margin-bottom:5px}
.np u b{cursor:pointer}.np u b:hover{color:var(--ac)}
.np .t{color:var(--ac2);font-size:11.5px;word-break:break-word;margin-bottom:3px}
.np .m{color:var(--dim);font-size:9px;letter-spacing:.08em}
.np .nx{color:var(--dim);font-size:9px;margin-top:6px;padding-top:6px;border-top:1px solid var(--line);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.np .nx s{text-decoration:none;color:var(--ac)}
.np .bar{height:3px;background:var(--line);margin-top:7px}
.np .bar i{display:block;height:100%;width:0;background:var(--ac2);transition:width .3s}
/* help moved onto the panel NAME — a ? on every panel was visual noise */
.lbl{cursor:help;border-bottom:1px dotted transparent;transition:border-color .15s}
.strip:hover .lbl{border-bottom-color:var(--dim)}
.strip .lbl:hover ~ .hcard,.hcard:hover{display:block}
/* collapsible panels */
.strip.collapsed .cw{display:none}
.strip.collapsed{min-height:0!important;height:auto!important}
.fold{font-size:9px;color:var(--dim);cursor:pointer;border:1px solid var(--line);padding:0 5px;
  opacity:0;transition:opacity .15s;flex:none;line-height:13px}
.strip:hover .fold{opacity:1}
.fold:hover{color:var(--ac);border-color:var(--ac)}
/* MEGA — every panel at once. Steps down rather than shattering.
   Strips without .keep are hidden here to buy vertical room for twelve
   panels. The waveform scope and the bass onsets are both .keep: they are
   per-frame instruments you watch while mixing, not per-set summaries. The
   set arc is not, because it says the same thing all night. This mattered the
   moment auto started choosing mega — the onsets strip vanished for anyone
   who had never deliberately picked mega. */
.app[data-cols="6"] .tri{grid-template-columns:repeat(6,1fr)!important}
.app[data-cols="4"] .tri{grid-template-columns:repeat(4,1fr)!important}
.app[data-cols="mega"] .tri{grid-template-columns:repeat(6,1fr)!important;grid-auto-rows:1fr!important;overflow:hidden}
.app[data-cols="mega"] .tri>.strip{min-height:0!important}
/* auto PER KEEP STRIP, then 1fr for the panels. This read "auto 1fr" from
   when exactly one strip survived mega; giving the onsets strip .keep made
   two, so the 1fr row landed on a strip with a forced 40px height and the
   panel grid fell into an implicit content-sized row. 220px of a 714px
   window went nowhere. */
.app[data-cols="mega"] .main{grid-template-rows:auto auto 1fr!important}
.app[data-cols="mega"] .main>.strip.keep{height:clamp(40px,5vh,70px)!important}
.app[data-cols="mega"] .main>.strip:not(.keep):not(.tri){display:none}
.app[data-cols="mega"] .strip{padding:2px 5px 3px}
.app[data-cols="mega"] .strip>u{font-size:6.5px;margin-bottom:1px}
@media(max-width:1400px){.app[data-cols="mega"] .tri{grid-template-columns:repeat(4,1fr)!important}}
@media(max-width:900px){.app[data-cols="mega"] .tri{grid-template-columns:repeat(3,1fr)!important}}

/* ── steering popup ────────────────────────────────────────────────────
   Click any track in the set list to open it. The whole routing engine
   (DWNAV, patches 07/09/10) shipped in the package; this popup did not, so
   the only way to reach it was the console. Row clicks jumped straight to
   the track instead, which is the one option the engine considers least
   interesting. */
#deckwave.dropping .app{outline:2px dashed var(--ac);outline-offset:-6px}
.navpop{display:none;position:fixed;z-index:9998;width:min(420px,86vw);
  background:var(--surf);border:1px solid var(--ac);box-shadow:0 0 34px rgba(0,0,0,.92);
  padding:9px;font-size:10px;line-height:1.5;letter-spacing:0;text-transform:none;
  color:var(--txt);max-height:70vh;overflow-y:auto}
.navpop.on{display:block}
.navpop>h6{margin:0 0 7px;font-size:9px;letter-spacing:.16em;text-transform:uppercase;
  color:var(--ac2);font-weight:400}
.navpop .opt{display:block;padding:7px 9px;margin-bottom:5px;cursor:pointer;
  border:1px solid var(--line);background:rgba(0,0,0,.25)}
.navpop .opt:hover{border-color:var(--ac)}
.navpop .opt b{display:block;color:var(--ac);font-weight:400;margin-bottom:2px}
.navpop .opt i{display:block;font-style:normal;color:var(--dim);font-size:9px}
.navpop .opt.good b{color:var(--good,#3ee68a)}
.navpop .opt.warn b{color:var(--bad)}
.navpop .opt.dead{opacity:.5;cursor:not-allowed}
.navpop .route{display:block;margin-top:4px;color:var(--dim);font-size:8.5px;
  letter-spacing:.05em;word-break:break-word}
.list .tr.queued{outline:1px solid var(--ac2);outline-offset:-1px}

/* Track list width and row density. Recovered from the live build, which had
   both and the packaged one had neither. Values exactly as they were there. */
.app[data-side="hide"] .side{display:none}
.app[data-side="hide"]{grid-template-columns:1fr!important}
.app[data-side="wide"]{grid-template-columns:1fr minmax(360px,30vw)!important}
.app[data-dense="1"] .tri>.strip{min-height:90px}
.app[data-dense="1"] .strip{padding:3px 6px 4px}
.app[data-dense="1"] .tr{padding:2px 8px;font-size:9px}

/* glossary: hover any term. One popup, repositioned, not one per term. */
.gl{border-bottom:1px dotted currentColor;cursor:help;opacity:.95}
.glpop{display:none;position:fixed;z-index:9999;width:min(300px,80vw);padding:10px 12px;
  background:var(--surf);border:1px solid var(--ac);box-shadow:0 0 28px rgba(0,0,0,.9);
  font-size:10px;line-height:1.55;letter-spacing:0;text-transform:none;text-align:left;color:var(--txt)}
.glpop.on{display:block}
.glpop h5{margin:0 0 5px;font-size:9.5px;letter-spacing:.14em;text-transform:uppercase;
  color:var(--ac);font-weight:500}
.glpop a{display:block;margin-top:7px;font-size:8.5px;color:var(--ac2);text-decoration:none}
.glpop a:hover{text-decoration:underline}
.glpop em{font-style:normal;display:block;margin-top:3px;font-size:7.5px;color:var(--dim)}
@media(prefers-reduced-motion:reduce){*{animation:none!important}}

/* ── PHONE ───────────────────────────────────────────────────────────────
   Keeper, on an iPhone 16 Pro Max, 2026-08-19: "the screen is not optimized
   for the real estate I have." It was the desktop grid squeezed to one
   column: three fixed strips eating a third of the height, the track list
   and the now-playing card collapsed to nothing, a five-row transport, and
   the LOG LINE — the only readout of a running scan — pushed under Safari's
   toolbar because the app was sized to 100vh, which on iOS includes it.

   Two screens instead of one cramped one: the PANELS, or the SET (track list
   + now-playing card), toggled by a phone-only button. The log line sits at
   the TOP of the transport, full width, in the accent colour. The files and
   capture groups fold behind ⚙ display along with cfg. Tap targets grow.
   Nothing here changes what any panel draws. */
button.phl{display:none}
@media(max-width:720px){
  .app{height:100dvh;grid-template-rows:auto 1fr auto}
  .main>.strip.keep,.main>.strip:has(#cArc){display:none}
  .tri>.strip{min-height:44vh}
  .side{display:none;border-left:0}
  .app.ph-list .main{display:none}
  .app.ph-list .side{display:flex;min-height:0}
  .tr{padding:9px 10px;font-size:12px}
  .tr i,.tr em{font-size:10px}
  .bar{gap:10px;padding:8px 10px}
  .kv u{font-size:8px} .kv b{font-size:13px}
  .tp{padding:8px 8px calc(8px + env(safe-area-inset-bottom));gap:6px}
  .tp button{font-size:11px;padding:10px 12px;letter-spacing:.1em}
  .tp .sep{display:none}
  .log{order:-1;flex-basis:100%;max-width:none;margin-left:0;white-space:normal;
    font-size:12px;line-height:1.35;color:var(--ac);padding:0 2px 4px}
  .tp [data-grp="files"],.tp [data-grp="capture"]{display:none}
  .tp.cfg-open [data-grp="files"],.tp.cfg-open [data-grp="capture"]{display:inline-block}
  button.phl{display:inline-block}
  .tp [data-ph="cfg"]{display:none}
  .tp.cfg-open [data-ph="cfg"]{display:inline-block}
  .vol input[type=range]{width:120px}
  .vol u{min-width:0}
}
`;

function mount(hostEl) {
  const host = document.createElement('div');
  host.id = 'deckwave';
  host.style.cssText = 'position:fixed;inset:0;z-index:2147483647';
  (hostEl || document.body).appendChild(host);
  const sr = host.attachShadow({ mode: 'open' });
  const st = document.createElement('style'); st.textContent = CSS; sr.appendChild(st);
  const $ = id => sr.getElementById(id);

  const app = document.createElement('div'); app.className = 'app';
  app.innerHTML = `
   <div class="bar" part="header"><h1>DECKWAVE.FM</h1>
     ${[['track','kPos'],['tempo','kBpm'],['key','kKey'],['stretch','kStr'],
        ['bass hits','kHit'],['register','kReg']]
        .map(([l,i]) => `<div class="kv"><u>${l}</u><b id="${i}">-</b></div>`).join('')}
   </div>
   <div class="nowline" id="nowline"></div>
   <div class="main">
     <div class="strip keep" style="height:clamp(70px,11vh,130px)"><u>waveform · scope</u>
       <div class="cw"><canvas id="cScope" part="scope"></canvas></div></div>
     <div class="strip keep" style="height:clamp(54px,8vh,96px)"><u>bass onsets · spectral flux · last 8s</u>
       <div class="cw"><canvas id="cPunch" part="punchcard"></canvas></div></div>
     <div class="tri" id="tri">
       ${[['spectrum','cSpec'],['pitch classes','cChroma'],['camelot · harmonic path','cCam'],
          ['goniometer · stereo field','cGonio'],['vu · 300ms ballistics','cVU']]
          .map(([l,i]) => `<div class="strip"><u>${l}</u><div class="cw"><canvas id="${i}" part="${i}"></canvas></div></div>`).join('')}
     </div>
     <div class="strip" style="height:clamp(60px,9vh,110px)"><u>set arc · energy + tempo across the whole night</u>
       <div class="cw"><canvas id="cArc" part="arc"></canvas></div></div>
   </div>
   <div class="side"><u id="sideHd">set</u><div class="list" id="list"></div></div>
   <div class="tp" id="tp"><span class="log" id="logLine">ready</span></div>`;
  sr.appendChild(app);

  /* ── canvases ─────────────────────────────────────────────────────── */
  const C = {}, X = {};
  ['cScope','cPunch','cSpec','cChroma','cCam','cGonio','cVU','cArc']
    .forEach(k => { C[k] = $(k); X[k] = C[k].getContext('2d'); });

  /* iterate the LIVE map — a captured array leaves later canvases unsized */
  function fit() {
    const d = window.devicePixelRatio || 1;
    Object.keys(C).forEach(k => {
      const c = C[k]; if (!c) return;
      const r = c.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) return;
      const w = Math.round(r.width * d), h = Math.round(r.height * d);
      if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
      X[k].setTransform(d, 0, 0, d, 0, 0);
    });
  }
  fit();
  let fitT;
  const ro = new ResizeObserver(() => { clearTimeout(fitT); fitT = setTimeout(fit, 60); });
  ro.observe(host); ro.observe($('tri'));
  [...$('tri').children].forEach(c => ro.observe(c));
  addEventListener('resize', () => { clearTimeout(fitT); fitT = setTimeout(fit, 60); });

  const css = k => getComputedStyle(host).getPropertyValue(k).trim();
  const g = (c, col, b) => { const s = parseFloat(css('--glow')); c.shadowBlur = b * (isNaN(s) ? 1 : s); c.shadowColor = col; };
  const W = k => C[k].getBoundingClientRect().width;
  const H = k => C[k].getBoundingClientRect().height;
  const RC = window.DWREGISTER;
  const col = (l, a) => (RC && RC.col(l, a)) || null;

  /* ── state ────────────────────────────────────────────────────────── */
  let set = [], deckL = null, deckR = null, raf = null, lastIdx = -1, lastT = performance.now();
  let wave = null, freq = null, prevLow = null;
  const H2 = 43, fhist = new Float32Array(H2);
  let fi = 0, ff = 0, lastHit = 0; const hits = [];

  /* split the deck's own analyser — a pass-through, so this is always available */
  function splitDeck() {
    const an = window.DW && window.DW.Player.analyser; if (!an) return false;
    /* kill → ▶ play closes the context and boots a fresh analyser; a split
       made on the old context stays wired to a closed graph forever and the
       goniometer and VU go dark. Re-split whenever the analyser is not the
       one we split. */
    if (deckL && deckL.context === an.context && deckL._src === an) return false;
    deckL = null; deckR = null;
    const ctx = an.context, sp = ctx.createChannelSplitter(2);
    deckL = ctx.createAnalyser(); deckL.fftSize = 2048;
    deckR = ctx.createAnalyser(); deckR.fftSize = 2048;
    an.connect(sp); sp.connect(deckL, 0); sp.connect(deckR, 1);
    const sink = ctx.createGain(); sink.gain.value = 0;
    deckL.connect(sink); deckR.connect(sink); sink.connect(ctx.destination);
    deckL._src = an;
    return true;
  }
  function stereoSource() {
    const L = window.DWLISTEN;
    if (L && L.active && L.L && L.R) return { L: L.L, R: L.R, src: 'listen' };
    /* Try the split HERE rather than relying on someone else to have done it.
       splitDeck() was only ever called from the inline loop() below, which
       DWLOOP replaced at mount — so it never ran, deckL/deckR were never
       created, and this returned null on every frame. That took the
       goniometer and the VU meters with it, because DWVU.feed() sits inside
       the loop's `if (stereo)` branch: feed never called, needles frozen.
       Which is Act 14's bug arriving by a different road. Cheap to retry:
       it returns false immediately once done, or while there is no deck. */
    if (!deckL) splitDeck();
    if (deckL && deckR) return { L: deckL, R: deckR, src: 'deck' };
    return null;
  }

  function flux(now) {
    if (!freq) return 0;
    if (!prevLow) { prevLow = new Float32Array(10); for (let i = 0; i < 10; i++) prevLow[i] = freq[i]; return 0; }
    let x = 0;
    for (let i = 0; i < 10; i++) { const d = freq[i] - prevLow[i]; if (d > 0) x += d; prevLow[i] = freq[i]; }
    x /= 2550;
    let m = 0; const n = ff || 1;
    for (let i = 0; i < n; i++) m += fhist[i]; m /= n;
    let hit = false;
    if (ff >= 10 && x > m * 2.0 + 0.004 && now - lastHit > 300) {
      lastHit = now; hits.push({ t: now, v: Math.min(1, x / 0.06) }); hit = true;
    }
    fhist[fi] = x; fi = (fi + 1) % H2; if (ff < H2) ff++;
    return { x, hit };
  }

  /* ── panels ───────────────────────────────────────────────────────── */
  const P = {
    /* wv is passed in by drawFixed from the render loop's bundle. The closure
       fallback is only reachable from the dead inline loop() below; relying on
       it is what made this strip a permanent flat line, since nothing has
       filled the dashboard's own `wave` since DWLOOP took the loop over. */
    scope(c, w, h, T, wv) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
      const W8 = wv || wave;
      if (!W8) { c.strokeStyle = T.line; c.beginPath(); c.moveTo(0, h/2); c.lineTo(w, h/2); c.stroke(); return; }
      const k = col(62) || T.ac; c.strokeStyle = k; c.lineWidth = 1.5; g(c, k, 9); c.beginPath();
      const s = W8.length / w;
      for (let x = 0; x < w; x++) { const v = (W8[Math.floor(x*s)]-128)/128;
        const y = h/2 + v*(h/2-3); x ? c.lineTo(x,y) : c.moveTo(x,y); }
      c.stroke(); c.shadowBlur = 0; },

    /* hs likewise comes from the loop's bundle; the dashboard's own `hits`
       array has been empty since DWLOOP started keeping its own. */
    punch(c, w, h, T, fx, now, hs) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
      c.strokeStyle = T.line; c.lineWidth = 1;
      for (let i = 1; i < 8; i++) { const x = w*i/8; c.beginPath(); c.moveTo(x,0); c.lineTo(x,h); c.stroke(); }
      c.fillStyle = col(55,.45) || 'rgba(34,232,255,.45)';
      c.fillRect(0, h-2-Math.min(h-4, fx*500), w, 2);
      (hs || hits).forEach(p => { const x = w - ((now-p.t)/8000)*w, r = 3 + p.v*(h*.14);
        const k = col(60) || T.ac2; c.fillStyle = k; g(c, k, 13);
        c.beginPath(); c.arc(x, h/2, r, 0, 7); c.fill(); });
      c.shadowBlur = 0; },

    spec(c, w, h, T) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h); if (!freq) return;
      const n = Math.max(16, Math.floor(w/9)), bw = w/n;
      for (let i = 0; i < n; i++) {
        const lo = Math.floor(Math.pow(i/n, 2.2)*freq.length);
        const hb = Math.max(lo+1, Math.floor(Math.pow((i+1)/n, 2.2)*freq.length));
        let m = 0; for (let j = lo; j < hb; j++) m = Math.max(m, freq[j]);
        const bh = (m/255)*(h-3);
        const gr = c.createLinearGradient(0, h, 0, h-bh);
        gr.addColorStop(0, col(52)||T.ac2); gr.addColorStop(1, col(72)||T.ac);
        c.fillStyle = gr; g(c, col(52)||T.ac2, 7); c.fillRect(i*bw+1, h-bh, bw-2, bh); }
      c.shadowBlur = 0; },

    /* twelve pitch CLASSES, not notes — see docs. Folded across all octaves. */
    chroma(c, w, h, T) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h); if (!freq) return;
      const b = new Float32Array(12), N = freq.length*2;
      for (let i = 1; i < freq.length; i++) { const f = i*44100/N;
        if (f < 55 || f > 5000) continue;
        b[((Math.round(69+12*Math.log2(f/440))%12)+12)%12] += freq[i]/255; }
      let mx = 0; for (const v of b) mx = Math.max(mx, v);
      const cx = w/2, cy = h/2, r = Math.min(w,h)/2 - 13;
      for (let i = 0; i < 12; i++) { const a = (i/12)*Math.PI*2 - Math.PI/2, v = mx ? b[i]/mx : 0;
        c.strokeStyle = T.line; c.lineWidth = 1; c.beginPath(); c.moveTo(cx,cy);
        c.lineTo(cx+Math.cos(a)*r, cy+Math.sin(a)*r); c.stroke();
        if (v > .12) { const k = v > .6 ? (col(58)||T.ac2) : (col(70)||T.ac);
          c.strokeStyle = k; c.lineWidth = 3; g(c, k, 10); c.beginPath(); c.moveTo(cx,cy);
          c.lineTo(cx+Math.cos(a)*r*v, cy+Math.sin(a)*r*v); c.stroke(); c.shadowBlur = 0; }
        c.fillStyle = v > .5 ? (col(75)||T.ac) : T.dim;
        c.font = '9px ' + css('--fn'); c.textAlign = 'center'; c.textBaseline = 'middle';
        c.fillText(PITCH[i], cx+Math.cos(a)*(r+8), cy+Math.sin(a)*(r+8)); } },

    cam(c, w, h, T, bass, hit) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
      /* the deck's track and the deck's next, by identity; index fallback */
      const s = window.DW.state, cur = window.DW.nowMeta || set[s.idx],
            nxt = window.DW.nextMeta || set[(cur ? set.indexOf(cur) : s.idx) + 1];
      const cx = w/2, cy = h/2, R = Math.min(w,h)/2 - 16, t = performance.now()/1000;
      for (let n = 1; n <= 12; n++) {
        const a = ((n-1)/12)*Math.PI*2 - Math.PI/2 + Math.sin(t*.12)*.02;
        [['A', R*.60], ['B', R]].forEach(([L, rr]) => {
          const code = n + L; let fill = T.line, txt = T.dim, pulse = 0;
          if (cur && cur.camelot === code) { fill = col(58)||T.ac2; txt = T.bg; pulse = 1; }
          else if (nxt && nxt.camelot === code) { fill = col(66,.9)||T.ac; txt = T.bg; pulse = .5; }
          else if (cur) { const sc = window.DW.camScore(cur.camelot, code);
            if (sc >= .85) { fill = col(50,.30)||'rgba(34,232,255,.28)'; txt = col(72)||T.ac; }
            else if (sc >= .45) fill = col(42,.13)||'rgba(34,232,255,.12)'; }
          const x = cx+Math.cos(a)*rr, y = cy+Math.sin(a)*rr;
          const rad = Math.max(6, R*.125)*(1 + pulse*bass*.45 + (pulse&&hit ? .22 : 0));
          c.fillStyle = fill; if (pulse) g(c, fill, 10+pulse*14);
          c.beginPath(); c.arc(x, y, rad, 0, 7); c.fill(); c.shadowBlur = 0;
          c.fillStyle = txt; c.font = Math.max(7, rad*.75)+'px '+css('--fn');
          c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(code, x, y); }); }
      if (cur && nxt) { const pt = cd => { const n = +cd.slice(0,-1), L = cd.slice(-1);
          const a = ((n-1)/12)*Math.PI*2 - Math.PI/2, rr = L === 'A' ? R*.60 : R;
          return [cx+Math.cos(a)*rr, cy+Math.sin(a)*rr]; };
        try { const [x1,y1] = pt(cur.camelot), [x2,y2] = pt(nxt.camelot);
          const k = col(62)||T.ac; c.strokeStyle = k; c.lineWidth = 2; g(c, k, 10);
          c.setLineDash([5,4]); c.lineDashOffset = -t*14;
          c.beginPath(); c.moveTo(x1,y1); c.lineTo(x2,y2); c.stroke();
          c.setLineDash([]); c.shadowBlur = 0; } catch (e) {} } },

    /* L vs R rotated 45deg with phosphor persistence — mono draws vertical */
    gonio(c, w, h, T, L, R, stat) {
      c.fillStyle = 'rgba(0,0,0,0.16)'; c.fillRect(0, 0, w, h);
      const cx = w/2, cy = h/2, r = Math.min(w,h)/2 - 6;
      c.strokeStyle = T.line; c.lineWidth = 1; c.beginPath(); c.arc(cx,cy,r,0,7); c.stroke();
      c.globalAlpha = .5; c.beginPath();
      c.moveTo(cx-r*.72, cy-r*.72); c.lineTo(cx+r*.72, cy+r*.72);
      c.moveTo(cx-r*.72, cy+r*.72); c.lineTo(cx+r*.72, cy-r*.72); c.stroke(); c.globalAlpha = 1;
      if (L && R) { const k = col(66)||T.ac; c.fillStyle = k; g(c, k, 6);
        const n = Math.min(L.length, R.length), step = Math.max(1, Math.floor(n/900));
        for (let i = 0; i < n; i += step) { const a = (L[i]-128)/128, b = (R[i]-128)/128;
          c.fillRect(cx+(a-b)*r*.66, cy-(a+b)*r*.66, 1.4, 1.4); }
        c.shadowBlur = 0; }
      if (stat) { const bw = w*.62, bx = (w-bw)/2, by = h-9, mid = bx+bw/2, x = mid+stat.corr*(bw/2);
        c.fillStyle = T.line; c.fillRect(bx, by, bw, 3);
        const k = stat.corr < 0 ? T.bad : (col(70)||T.ac);
        c.fillStyle = k; g(c, k, 7);
        c.fillRect(Math.min(mid,x), by, Math.abs(x-mid)||1.5, 3); c.shadowBlur = 0;
        c.fillStyle = T.dim; c.font = '7.5px '+css('--fn'); c.textAlign = 'center';
        c.textBaseline = 'bottom'; c.fillText('−1   phase   +1', cx, by-2); } },

    vu(c, w, h, T, s) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
      const cx = w/2, cy = h*.92, r = Math.min(w/2, h)*.86;
      c.strokeStyle = T.line; c.lineWidth = 1;
      c.beginPath(); c.arc(cx, cy, r, Math.PI*1.15, Math.PI*1.85); c.stroke();
      for (let i = 0; i <= 10; i++) { const a = Math.PI*1.15 + (i/10)*Math.PI*.7, over = i > 7;
        c.strokeStyle = over ? T.bad : T.dim; c.lineWidth = over ? 1.6 : 1;
        c.beginPath(); c.moveTo(cx+Math.cos(a)*r, cy+Math.sin(a)*r);
        c.lineTo(cx+Math.cos(a)*r*.88, cy+Math.sin(a)*r*.88); c.stroke(); }
      const needle = (v, pk, off, k) => {
        const a = Math.PI*1.15 + Math.min(1,v)*Math.PI*.7;
        c.strokeStyle = k; c.lineWidth = 2; g(c, k, 9);
        c.beginPath(); c.moveTo(cx+off, cy);
        c.lineTo(cx+off+Math.cos(a)*r*.82, cy+Math.sin(a)*r*.82); c.stroke(); c.shadowBlur = 0;
        const pa = Math.PI*1.15 + Math.min(1,pk)*Math.PI*.7;
        c.fillStyle = k; c.beginPath();
        c.arc(cx+off+Math.cos(pa)*r*.9, cy+Math.sin(pa)*r*.9, 2, 0, 7); c.fill(); };
      needle(s.L, s.pkL, -w*.012, col(68)||T.ac);
      needle(s.R, s.pkR,  w*.012, col(56)||T.ac2);
      c.fillStyle = T.dim; c.font = '7.5px '+css('--fn'); c.textAlign = 'center'; c.fillText('VU', cx, h-2); },

    arc(c, w, h, T) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
      if (!set.length) { c.strokeStyle = T.line; c.beginPath(); c.moveTo(0,h/2); c.lineTo(w,h/2); c.stroke(); return; }
      const n = set.length, pad = 3, eY = v => h - pad - v*(h-pad*2);
      const bs = set.map(t => t.bpm), bmin = Math.min(...bs), bmax = Math.max(...bs);
      c.strokeStyle = 'rgba(125,110,176,.45)'; c.lineWidth = 1; c.beginPath();
      set.forEach((t,i) => { const x = (i/(n-1))*w,
        y = h-pad-((t.bpm-bmin)/(bmax-bmin||1))*(h-pad*2); i ? c.lineTo(x,y) : c.moveTo(x,y); });
      c.stroke();
      const gr = c.createLinearGradient(0,0,w,0);
      gr.addColorStop(0, col(70)||T.ac); gr.addColorStop(1, col(56)||T.ac2);
      c.strokeStyle = gr; c.lineWidth = 2; g(c, col(56)||T.ac2, 8); c.beginPath();
      set.forEach((t,i) => { const x = (i/(n-1))*w, y = eY(t.energy); i ? c.lineTo(x,y) : c.moveTo(x,y); });
      c.stroke(); c.shadowBlur = 0;
      /* Mark the DECK's track, found by identity. The index alone threw
         here when a shorter set was built or loaded while idx sat beyond
         its end — and this strip draws before the slots, with no try/catch
         around it in the loop, so one throw took the header, every panel
         and the now-playing card with it on every frame after. */
      const s = window.DW.state, nm = window.DW.nowMeta;
      const ci = nm ? set.indexOf(nm) : s.idx;
      if (s.of && ci > -1 && ci < n) { const x = (ci/(n-1))*w, k = col(58)||T.ac2;
        c.strokeStyle = k; c.lineWidth = 2; g(c, k, 12);
        c.beginPath(); c.moveTo(x,0); c.lineTo(x,h); c.stroke(); c.shadowBlur = 0;
        c.fillStyle = k; c.beginPath(); c.arc(x, eY(set[ci].energy), 4, 0, 7); c.fill(); }
      c.fillStyle = T.dim; c.font = '8px '+css('--fn');
      c.textAlign = 'left'; c.fillText('energy', 4, 10);
      c.textAlign = 'right'; c.fillText(Math.round(bmin)+'-'+Math.round(bmax)+' bpm', w-4, 10); }
  };

  /* ── loop ─────────────────────────────────────────────────────────── */
  function loop() {
    raf = requestAnimationFrame(loop);
    const now = performance.now(), dt = Math.min(.1, (now-lastT)/1000); lastT = now;
    const T = { bg: css('--bg')||'#04010f', surf: css('--surf'), line: css('--line')||'#22125c',
      dim: css('--dim')||'#7d6eb0', ac: css('--ac')||'#22e8ff', ac2: css('--ac2')||'#ff2d95',
      bad: css('--bad')||'#ff5470' };

    const an = (window.DWLISTEN && window.DWLISTEN.active && window.DWLISTEN.analyser)
             || (window.DW && window.DW.Player.analyser);
    if (an) {
      if (!wave || wave.length !== an.fftSize) { wave = new Uint8Array(an.fftSize); freq = new Uint8Array(an.frequencyBinCount); }
      an.getByteTimeDomainData(wave); an.getByteFrequencyData(freq);
      if (RC && RC.mode.on) {
        const r = RC.update(freq);
        host.style.setProperty('--dw-color-accent', 'hsl('+r.hue+',80%,64%)');
        host.style.setProperty('--dw-color-accent-2', 'hsl('+((r.hue+38)%360)+',80%,56%)');
        $('kReg').textContent = r.centroidHz+'Hz '+r.band;
      }
    }
    splitDeck();
    const F = flux(now); const fx = F.x || 0, hit = F.hit || false;
    while (hits.length && now - hits[0].t > 8000) hits.shift();
    let bass = 0; if (freq) { let s = 0; for (let i = 0; i < 12; i++) s += freq[i]; bass = s/12/255; }

    P.scope(X.cScope, W('cScope'), H('cScope'), T);
    P.punch(X.cPunch, W('cPunch'), H('cPunch'), T, fx, now);
    P.spec(X.cSpec, W('cSpec'), H('cSpec'), T);
    P.chroma(X.cChroma, W('cChroma'), H('cChroma'), T);
    P.cam(X.cCam, W('cCam'), H('cCam'), T, bass, hit);

    const S = stereoSource();
    if (S) {
      if (!window.__dwL || window.__dwL.length !== S.L.fftSize) {
        window.__dwL = new Uint8Array(S.L.fftSize); window.__dwR = new Uint8Array(S.R.fftSize); }
      S.L.getByteTimeDomainData(window.__dwL); S.R.getByteTimeDomainData(window.__dwR);
      const stat = window.DWSTEREO(window.__dwL, window.__dwR);
      P.gonio(X.cGonio, W('cGonio'), H('cGonio'), T, window.__dwL, window.__dwR, stat);
      /* feed RAW rms — DWVU does the dBFS conversion. Passing pre-scaled
         values is what railed the needles in the first version. */
      const vs = window.DWVU.feed(stat.rmsL, stat.rmsR, dt);
      P.vu(X.cVU, W('cVU'), H('cVU'), T, vs);
    }
    P.arc(X.cArc, W('cArc'), H('cArc'), T);

    head(hits.length);
    const s = window.DW.state;
    if (s.idx !== lastIdx) { lastIdx = s.idx; renderList(); }
  }

  function head(nHits) {
    /* The DECK first, the list index second — ledger 33 and 40. And the
       deck's RATE, not the plan's `_stretch`: the two agree only while the
       set plays exactly as planned. After next ▶ or a jump the deck runs at
       ×1.000 whatever the row says; after a forced blend it runs at the
       forced figure; under a settle ramp it moves. `_stretch` is 1 for a
       track played STRAIGHT, and 1 is truthy, so this header printed 0.0%
       against exactly the tracks CLAUDE.md says must never show one. */
    const s = window.DW.state, dk = window.DW.deck;
    const t = (dk && dk.meta) || set[s.idx];
    const pos = t ? set.indexOf(t) : -1;
    $('kPos').textContent = s.of ? (((pos > -1 ? pos : s.idx)+1)+'/'+(set.length || s.of)) : '-';
    $('kBpm').textContent = s.tempo || '-';
    $('kKey').textContent = t ? t.camelot : '-';
    $('kKey').className = 'p';
    let str = '-', warn = false;
    if (t && t._unlocked) str = '∿';
    else if (dk) { str = (dk.stretchPct >= 0 ? '+' : '') + dk.stretchPct.toFixed(1) + '%'; warn = Math.abs(dk.rate - 1) > .08; }
    else if (t && t._stretch) { str = (((t._stretch-1)*100).toFixed(1)+'%'); warn = Math.abs(t._stretch-1) > .08; }
    $('kStr').textContent = str;
    $('kStr').className = warn ? 'w' : '';
    $('kStr').title = t && t._unlocked ? 'played straight — not beatmatched, so there is no stretch to print'
                    : (dk && dk.settling ? 'settling to ×1.000 · ' + Math.round(dk.settleLeft) + 's' : '');
    $('kHit').textContent = nHits; $('kHit').className = 'g';
    const nl = $('nowline');
    if (nl.style.display !== 'none' && t)
      nl.innerHTML = '<b>'+((pos > -1 ? pos : s.idx)+1)+'/'+(set.length || s.of)+'</b> '+esc(clean(t.name).slice(0,44))
        +' · '+Math.round(t.bpm)+' · '+esc(t.camelot);
  }

  const clean = n => n.replace(/^LukHash\s*-\s*/i,'').replace(/^[^-]+-\s*/,'').replace(/^\d+\s*/,'');

  function renderList() {
    /* ── which row is playing: ask the deck, then fall back to the index ──
       Highlighting purely by `state.idx` means the list marks whatever
       happens to sit at that index in ITS array — which is only the playing
       track while the two arrays agree. When they stop agreeing the list
       confidently points at the wrong row, which is what the keeper saw:
       *"we are not on demoscene right now"*. Identity first; the index is
       the fallback for before playback starts. Ledger 33 and 40. */
    const nm = window.DW.nowMeta;
    const byId = nm ? set.indexOf(nm) : -1;
    const cur = byId > -1 ? byId : window.DW.state.idx;
    $('sideHd').textContent = 'set · ' + set.length + ' tracks'
      + (nm && byId < 0 ? ' · ⚠ playing a track that is not in this list' : '');
    $('list').innerHTML = set.map((t,i) => {
      const cls = i === cur ? 'now' : (i === cur+1 ? 'next' : (i < cur ? 'done' : ''));
      /* A track that is NOT being beatmatched should say so in the list.
         Silently mixing it in would put the honesty in the code comments and
         nowhere the listener can see it. */
      const free = t._unlocked
        ? (t._unlockReason === 'reach' ? ' title="played straight — out of stretch reach"'
                                       : ' title="played straight — beat grid disagrees with its tempo"')
        : '';
      return `<div class="tr ${cls}${t._unlocked ? ' free' : ''}" data-i="${i}"${free}>`
           + `<i>${String(i+1).padStart(3,'0')}</i>`
           + `<s>${esc(clean(t.name).slice(0,46))}</s>`
           + `<em>${t._unlocked ? '∿ ' : ''}${Math.round(t.bpm)} ${esc(t.camelot)}</em></div>`;
    }).join('');
    /* A row click opens the steering menu rather than jumping. Jumping is
       still there — it is one of the options — but it is the least
       interesting thing the router can do, and making it the only thing is
       what hid the whole feature. */
    $('list').querySelectorAll('.tr').forEach(el =>
      el.onclick = e => { e.stopPropagation(); openNav(el, +el.dataset.i); });
    markQueued();
    const n = $('list').querySelector('.now');
    if (n) n.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }

  /* ── steering ─────────────────────────────────────────────────────────
     DWNAV, and patches 09 and 10 on top of it, shipped in the package with
     no way to reach them. optionsFull() already returns exactly the menu a
     UI needs — next / force / route / fast / jump / back — so this renders
     that and calls commitAndRepair, which splices the route into the set and
     re-plans the tail from where the detour actually leaves the tempo. */
  /* ── drop ──────────────────────────────────────────────────────────────
     A single drop can carry SEVERAL folders and loose files together, which
     is the only way to choose more than one folder in one gesture —
     showDirectoryPicker returns exactly one. Everything lands in the same
     additive ingest as the buttons. */
  host.addEventListener('dragover', e => { e.preventDefault(); host.classList.add('dropping'); });
  host.addEventListener('dragleave', e => {
    if (e.relatedTarget && host.contains(e.relatedTarget)) return;
    host.classList.remove('dropping');
  });
  host.addEventListener('drop', async e => {
    e.preventDefault(); host.classList.remove('dropping');
    const l = m => { const el = sr.getElementById('logLine'); if (el) el.textContent = m; };
    l('reading drop…');
    try {
      const r = await window.DW.addDropped(e.dataTransfer,
        (i, n, nm) => l(i + '/' + n + ' ' + nm.slice(0, 40)));
      l(r.added + ' added · ' + r.corpus + ' in corpus'
        + (r.duplicates ? ' · ' + r.duplicates + ' already had' : '')
        + (r.failed ? ' · ' + r.failed + ' failed' : ''));
    } catch (err) { l(String((err && err.message) || err)); }
  });

  /* buildTransport has its own log(); mount lost one when the inline
     transport was removed, and the steering menu needs to report. */
  const log = m => { const l = $('logLine'); if (l) l.textContent = m; };

  const navpop = document.createElement('div');
  navpop.className = 'navpop'; navpop.id = 'navpop';
  navpop.onclick = e => e.stopPropagation();
  sr.appendChild(navpop);
  const closeNav = () => navpop.classList.remove('on');

  function markQueued() {
    const N = window.DWNAV; if (!N) return;
    sr.querySelectorAll('.tr').forEach(e => e.classList.remove('queued'));
    const q = N.queue;
    if (q) { const e = sr.querySelector('.tr[data-i="' + q.idx + '"]'); if (e) e.classList.add('queued'); }
  }

  /* ── the line that made routing inert ────────────────────────────────
     `dash.set = r.set` and nothing else. commitAndRepair returns a NEW array;
     Player.play() captured the OLD one as `order` and there was no way to
     hand it a replacement, so the list showed the detour and the deck walked
     the set it was given at ▶. Patch 09's bug, third time: an intention the
     UI recorded and the playback path never read.

     DW.reorder() adopts the array, so the two are one object again — the
     invariant every in-place operation here already depends on — and
     re-chains, because the next deck was committed the moment this track
     started and that choice predates the route.

     `now` is what separates the two menu entries. A fast blend leaves the
     current track at the next downbeat, because "⚡ blend fast" is a request
     to GO; a scenic route lets it finish, because "↝ scenic route" is not. */
  async function applyRoute(entry, label) {
    const N = window.DWNAV;
    N.setQueue(entry);
    const r = N.commitAndRepair(set);
    if (!r.ok) { log('route failed: ' + r.why); return; }
    const v = N.verify(r.set, window.DW.state.idx, window.DW.state.tempo);
    let moved = 'not playing — press ▶';
    if (window.DW.state.of) {
      moved = await window.DW.reorder(r.set, { now: !!entry.dwellSec });
      /* reorder() REFUSES when the playing track is not at idx in the new
         array. Adopting the array here anyway would leave the dashboard on a
         third array the player never saw — the ledger-40 desync, self-
         inflicted. Keep the old set and say so. */
      if (/^refused/.test(moved)) { N.clearRoute(); log('route ' + moved); return; }
    }
    dash.set = r.set;                       /* setter re-renders the list */
    renderList();
    /* `v.overGate` — verify() never had a field called `over`, so this line
       read undefined and printed "gate holds" unconditionally: a check whose
       pass condition could not fail. */
    log(label + ' · +' + r.inserted + ' spliced · tail ' + r.tailKept +
        ' kept, ' + r.tailDropped + ' dropped' +
        (v && v.overGate ? ' · ⚠ ' + v.overGate + ' over gate (max ' + v.maxStretch + '%)' : ' · gate holds') +
        ' · ' + moved);
  }

  function openNav(el, idx) {
    const N = window.DWNAV, t = set[idx];
    if (!N || !t) return;
    const T = window.DW.state.tempo || (set[window.DW.state.idx] || t).bpm;

    /* ── a track that plays STRAIGHT has no stretch to quote ──────────────
       chain() honours `_unlocked` and runs the deck at rate 1, so clicking
       "force it now" on one of these already did the right thing — while the
       menu printed "+28%" beside it. The behaviour was right and the label
       was a lie, which is the worse half of that pair: it invites the keeper
       to test a stretch that is never applied.

       Route and fast are suppressed for the same reason. A stepping-stone
       ladder exists to walk the TEMPO across, and nothing is being stretched
       to this track, so there is nothing for a ladder to do. */
    if (t._unlocked) {
      const why = t._unlockReason === 'reach'
        ? 'Its grid is fine — the set simply cannot stretch to it from ' + Math.round(T)
          + ' bpm. It plays at its own speed, then the set continues from '
          + Math.round(t.bpm) + ' bpm.'
        : 'Its beat grid disagrees with its own tempo label'
          + (t._gridErr != null ? ' by ' + t._gridErr + '%' : '')
          + ', so we do not beatmatch it. It plays at its own speed and the tempo '
          + 'target stays where it is.';
      navpop.innerHTML = '<h6>' + esc(clean(t.name).slice(0, 44)) + ' · ' +
        Math.round(t.bpm) + ' · ' + esc(t.camelot) + ' · plays straight</h6>';
      [{ cls: 'good', b: '∿ bring it in now · no stretch',
         i: 'Crossfades at the next opportunity without claiming a beatmatch. ' + why,
         act: () => blend(idx) },
       { cls: '', b: '⏭ queue as next',
         i: 'This track finishes as planned, then crossfades into that one, straight.',
         act: () => later(idx) },
       { cls: '', b: '⇥ jump straight there',
         i: 'Cuts. Does not blend.', act: () => jump(idx) }].forEach(r => {
        const sp = document.createElement('span');
        sp.className = 'opt ' + r.cls;
        sp.innerHTML = '<b>' + esc(r.b) + '</b><i>' + esc(r.i) + '</i>';
        sp.onclick = ev => { ev.stopPropagation(); closeNav(); r.act(); };
        navpop.appendChild(sp);
      });
      const bb = el.getBoundingClientRect();
      navpop.classList.add('on');
      const hh = navpop.getBoundingClientRect().height;
      navpop.style.top = Math.max(8, Math.min(innerHeight - hh - 8, bb.top)) + 'px';
      navpop.style.left = Math.max(8, bb.left - navpop.getBoundingClientRect().width - 10) + 'px';
      return;
    }

    const opts = (N.optionsFull || N.options).call(N, T, t, window.DW.corpus).slice();
    /* The engine describes reachability; it has no opinion about WHEN. Both
       timings are useful, so the "finish this one first" variant is added
       alongside whatever it returned. */
    const insertAt = opts.findIndex(o => o.kind === 'jump');
    opts.splice(insertAt < 0 ? opts.length : insertAt, 0, { kind: 'later', ok: true });

    const pct = n => (n > 0 ? '+' : '') + n + '%';
    /* optionsFull() reports |stretch|; the deck will run at T/bpm, which is
       slower than native when the target is below the track's tempo. Print
       the sign the header prints, not a + against a slow-down. */
    const signed = +(((T / t.bpm) - 1) * 100).toFixed(1);
    const rows = opts.map(o => {
      switch (o.kind) {
        case 'next':  return { cls: 'good', b: '▶ blend in now · ' + pct(signed),
          i: 'Leaves this track at the next downbeat and crossfades. Does not wait '
             + 'for the exit planned at the top of the track, and does not cut.',
          act: () => blend(idx) };
        case 'force': return { cls: 'warn', b: '⚠ force it now · ' + pct(signed),
          i: o.warn + '. Blends at the next downbeat, but the gate exists because '
             + 'this is what that much stretch sounds like.',
          act: () => blend(idx) };
        case 'later': return { cls: '', b: '⏭ queue as next',
          i: 'This track finishes as planned, then blends into that one.',
          act: () => later(idx) };
        case 'route': return { cls: 'good', b: '↝ scenic route · ' + o.hops.length + ' stepping stones',
          i: 'This track finishes first, then walks the tempo across instead of '
             + 'yanking it. About ' + o.minutes + ' min of stepping stones, ending at '
             + pct(o.finalStretch) + '.',
          ladder: o.ladder, dest: t, act: () => applyRoute({ idx, mode: 'route', hops: o.hops }, 'scenic route') };
        /* dwellSec is what the router ASKED for; chain() clamps it up to
           DW.dwellFloor. Printing the request rather than the clamp is how
           this menu advertised 40s stones that always played 45. */
        case 'fast':  {
          const floor = (window.DW && window.DW.dwellFloor) || 0;
          const real = Math.max(floor, o.dwellSec);
          const mins = +((real * o.hops.length) / 60).toFixed(1);
          return { cls: 'good', b: '⚡ blend fast · ' + o.hops.length + ' quick passes',
          i: 'Leaves this track at the next downbeat. Each stone then plays ' + real +
             's — long enough to blend in and out' +
             (real > o.dwellSec ? ' (asked for ' + o.dwellSec + 's; the engine floor is ' + floor + 's)' : '') +
             '. About ' + mins + ' min.',
          ladder: o.ladder, dest: t,
          act: () => applyRoute({ idx, mode: 'route', hops: o.hops, dwellSec: o.dwellSec }, 'fast blend') }; }
        case 'unreachable': return { cls: 'dead', b: '✕ unreachable',
          i: o.reason + (o.wouldNeed ? ' · would need ' + pct(o.wouldNeed) : ''), act: null };
        case 'jump':  return { cls: '', b: '⇥ jump straight there',
          i: 'Ignores the tempo plan. Cuts, does not blend.', act: () => jump(idx) };
        case 'back':  return { cls: '', b: '↩ back',
          i: 'Return to where you steered away from.', act: () => { const b = N.back(); if (b != null) jump(b); } };
        default: return null;
      }
    }).filter(Boolean);

    navpop.innerHTML = '<h6>' + esc(clean(t.name).slice(0, 44)) + ' · ' +
      Math.round(t.bpm) + ' · ' + esc(t.camelot) + ' · target ' + Math.round(T) + '</h6>';
    rows.forEach(r => {
      const s = document.createElement('span');
      s.className = 'opt ' + r.cls;
      s.innerHTML = '<b>' + esc(r.b) + '</b><i>' + esc(r.i) +
        (r.ladder ? '<span class="route">' + r.ladder.map(n => esc(n)).join(' → ') +
                    ' → <b style="display:inline">' + Math.round(r.dest.bpm) + '</b></span>' : '') + '</i>';
      if (r.act) s.onclick = ev => { ev.stopPropagation(); closeNav(); r.act(); };
      navpop.appendChild(s);
    });

    const b = el.getBoundingClientRect();
    navpop.classList.add('on');
    const h = navpop.getBoundingClientRect().height;
    navpop.style.top = Math.max(8, Math.min(innerHeight - h - 8, b.top)) + 'px';
    navpop.style.left = Math.max(8, b.left - navpop.getBoundingClientRect().width - 10) + 'px';
  }

  /* play() rejects when the target is missing or will not decode — and it
     has already stopped the deck by then. Unhandled, that was silence with
     the log line unchanged: exactly the "no evidence afterwards" symptom the
     audit button exists for. Say it on the line. */
  const safePlay = async (i) => {
    try { return await window.DW.play(set, i); }
    catch (e) { return 'cannot play ' + String(set[i] && set[i].name || '').slice(-30) + ': ' +
                       String((e && e.message) || e) + ' — deck stopped'; }
  };
  async function jump(i) {
    const N = window.DWNAV;
    if (N && window.DW.state.of) N.push(window.DW.state.idx);
    log(await safePlay(i));
  }

  /* Leave the current track at the next downbeat and crossfade into i.
     Both of these mutate the play order IN PLACE inside the Player, and the
     dashboard's `set` is that same array — so the list follows without being
     reassigned. Reassigning would desync the two silently. */
  async function blend(i) {
    const N = window.DWNAV;
    if (!window.DW.state.of) { log('nothing playing — use jump'); return; }
    if (N) N.push(window.DW.state.idx);
    log(await window.DW.blendNow(set[i]));
    renderList();
  }

  async function later(i) {
    if (!window.DW.state.of) { log('nothing playing — use jump'); return; }
    log(await window.DW.queueNext(set[i]));
    renderList();
  }

  /* The transport is NOT built here. mount() used to build one inline and
     then call buildTransport(dash) as well, so #tp received two complete
     sets of controls: two scan, two build set, two play/pause/next/stop,
     two theme buttons writing the same localStorage key. Both were live.
     One transport, built once, after the mixins exist. */

  /* ── wire everything mount() owns ──────────────────────────────────
     This block is the difference between "the code is saved" and "it runs".
     An earlier package had all the mixins present and never called them:
     a fresh page load gave panels and no view selector. */
  const dash = {
    host, shadow: sr, fit, C, X,
    get set() { return set; }, set set(v) { set = v; renderList(); },
    renderList, header: head, slots: null, views: null, applyFolds: null,
    stereoSource, drawFixed: null, elapsed: 0, theme: 'cyberpunk'
  };

  /* Reachable from outside for live patching — same seam as DW._dev, same
     rules. The UI half matters as much as the engine half: the steering menu
     lives in this closure, so without these it cannot be changed without a
     reload either. */
  dash.openNav = openNav; dash.blend = blend; dash.later = later;
  dash.jump = jump; dash.log = log; dash.markQueued = markQueued;
  lastDash = dash;

  dash.slots      = DWDASH.slots(dash);       /* swappable panel cells */
  dash.applyFolds = DWDASH.folds(dash);       /* collapse / expand, persisted */
  dash.views      = DWDASH.views(dash);       /* named saveable arrangements */
  DWDASH.glossary(dash);                      /* header term tooltips */
  dash.glossary = DWDASH.glossaryBind(dash);  /* hover any term, anywhere */
  dash.applyFolds();

  if (window.DWNOWPLAYING) window.DWNOWPLAYING.mount(dash);

  /* fixed strips the slots do not own */
  dash.drawFixed = (T, D) => {
    const at = (cid, fn) => { const c = C[cid]; if (!c) return;
      const r = c.getBoundingClientRect();
      if (r.width > 2 && r.height > 2) fn(X[cid], r.width, r.height); };
    /* Feed these from the bundle. They used to read mount-scope closures that
       only the dead inline loop() ever filled, so the waveform strip drew a
       flat line and the punchcard showed no onsets — for every run since the
       package was cut. */
    at('cScope', (c, w, h) => P.scope(c, w, h, T, D.wave));
    at('cPunch', (c, w, h) => P.punch(c, w, h, T, D.flux || 0, performance.now(), D.hits));
    at('cArc',   (c, w, h) => P.arc(c, w, h, T));
  };

  /* One loop, started once. Never wrap it to add a feature — add the feature
     to the bundle it already builds. Wrapping is what killed the last one. */
  if (window.DWLOOP) window.DWLOOP.start(dash); else loop();

  buildTransport(dash);
  return dash;
}

/* ── transport ──────────────────────────────────────────────────────────
   Built after the mixins exist, because half these controls drive them. */
function buildTransport(dash) {
  const sr = dash.shadow, $ = id => sr.getElementById(id), tp = $('tp');
  const log = m => { $('logLine').textContent = m; };
  /* ── grouping ──────────────────────────────────────────────────────────
     The transport accreted one control at a time until it was 21 items in a
     flat row spanning library, playback, output, capture and appearance, with
     nothing marking where one concern ended and the next began.

     Every control now carries a group. 'cfg' is everything you set once and
     leave — appearance, layout, overlays — and it collapses behind one toggle,
     which takes the always-visible count from 21 to 13. Nothing is removed and
     nothing moves more than one click away.

     Grouping by dataset rather than by wrapper elements on purpose: .tp is a
     wrapping flexbox, so hiding a group just shortens the row. No change to
     the app grid, which is the part that would be easy to break and hard to
     notice. */
  const GRP = { deck: 'deck', play: 'play', files: 'files', cap: 'capture', cfg: 'cfg' };

  const btn = (txt, fn, hot, grp) => {
    const b = document.createElement('button');
    b.textContent = txt; if (hot) b.className = 'hot'; b.onclick = fn;
    b.dataset.grp = grp || GRP.deck;
    tp.insertBefore(b, $('logLine')); return b;
  };
  const sep = (grp) => { const s = document.createElement('span');
    s.className = 'sep'; s.dataset.grp = grp || GRP.deck;
    tp.insertBefore(s, $('logLine')); return s; };

  /* a small dropdown, used for layout / theme / views */
  function select(label, items, onPick, current, grp) {
    const wrap = document.createElement('span'); wrap.className = 'sel';
    const b = document.createElement('button');
    const menu = document.createElement('span'); menu.className = 'menu';
    const nameOf = k => (items.find(x => x.k === k) || items[0]).n;
    const paint = () => {
      b.textContent = label + ': ' + nameOf(current);
      /* View names reach here from prompt(), and from an imported views file. */
      menu.innerHTML = '<u>' + esc(label) + '</u>' + items.map(x =>
        `<i data-k="${esc(x.k)}" class="${x.k === current ? 'on' : ''}">${esc(x.n)}`
        + (x.hint ? `<b>${esc(x.hint)}</b>` : '') + '</i>').join('');
      menu.querySelectorAll('i').forEach(el => el.onclick = ev => {
        ev.stopPropagation(); current = el.dataset.k;
        wrap.classList.remove('open'); paint(); onPick(current);
      });
    };
    paint();
    b.onclick = e => { e.stopPropagation();
      sr.querySelectorAll('.sel').forEach(o => { if (o !== wrap) o.classList.remove('open'); });
      wrap.classList.toggle('open'); };
    wrap.onclick = e => e.stopPropagation();
    wrap.appendChild(b); wrap.appendChild(menu);
    wrap.dataset.grp = grp || GRP.cfg;
    tp.insertBefore(wrap, $('logLine'));
    return { el: wrap, refresh: paint, set(k) { current = k; paint(); } };
  }
  document.addEventListener('click', () =>
    { sr.querySelectorAll('.sel,.pmenu,.hcard').forEach(o => o.classList.remove('open'));
      const np = sr.getElementById('navpop'); if (np) np.classList.remove('on'); });

  /* keep the screen awake for the length of a scan — the page is paused
     when it is off, and a locked phone lost the keeper a 189-track pass */
  const PH = () => window.DWPHONE;
  btn('scan', async () => {
    log('pick your music folder…');
    if (PH()) PH().hold('scan');
    try {
      const r = await window.DW.scan((i, n, nm) => log(i + '/' + n + ' ' + nm.slice(0, 40)));
      log(r.added + ' added · ' + r.analysed + ' in corpus · ' + r.cached + ' cached'
        + (r.duplicates ? ' · ' + r.duplicates + ' already had' : '')
        + (r.failed ? ' · ' + r.failed + ' failed' : '')
        + (r.via === 'files-input' ? ' · picked as files — this browser cannot pick a folder' : ''));
    } catch (e) {
      /* Cancelling the picker rejects with AbortError. Uncaught, that left an
         unhandled rejection in the console and the log line stuck on
         "pick your music folder…" forever — the UI claiming to be waiting for
         a dialog the user had already dismissed. */
      log(e && e.name === 'AbortError' ? 'scan cancelled' : String((e && e.message) || e));
    } finally { if (PH()) PH().release('scan'); }
  }, true);

  /* Individual tracks, multi-select. Folders come in one at a time because
     showDirectoryPicker only ever returns one — that is the browser, not us.
     Scanning is additive now, so several folders means pressing scan again. */
  btn('+ tracks', async () => {
    log('pick tracks…');
    if (PH()) PH().hold('scan');
    try {
      const r = await window.DW.addFiles((i, n, nm) => log(i + '/' + n + ' ' + nm.slice(0, 40)));
      log(r.added + ' added · ' + r.corpus + ' in corpus'
        + (r.duplicates ? ' · ' + r.duplicates + ' already had' : '')
        + (r.failed ? ' · ' + r.failed + ' failed' : ''));
    } catch (e) {
      log(e && e.name === 'AbortError' ? 'cancelled' : String((e && e.message) || e));
    } finally { if (PH()) PH().release('scan'); }
  });

  /* `keepDupes` is a toggle rather than a law because removing a track the
     owner put in their own folder is their call. It drops 17 here — the same
     recording on an album and on a single. */
  let keepDupes = false;

  /* Two builds, the keeper's call: ALL TRACKS places everything and plays
     the unreachable straight; BEST MATCHES keeps only what can be beatmatched
     from where the set is and ends when the gate is exhausted — and says how
     many it left out, so a short set is never mistaken for a small library. */
  const build = mode => {
    if (!window.DW.corpus.length) { log('scan first'); return; }
    dash.set = window.DW.build({ length: 500, dedupe: !keepDupes, mode });
    const i = window.DW.inspect(dash.set);
    if (typeof i === 'string') { log(i); return; }
    log((mode === 'best' ? 'best matches · ' : 'all tracks · ')
      + i.tracks + ' tracks · ' + Math.floor(i.runtimeMin / 60) + 'h' + (i.runtimeMin % 60)
      + ' · max stretch ' + i.maxStretchPct + '%'
      + (i.maxStretchPct > 15 ? ' ⚠ OVER BUDGET' : '')
      + (mode === 'best'
          ? (i.leftOut ? ' · left out ' + i.leftOut + ' of ' + i.poolSize + ' ('
              + i.leftOutGrid + ' untrusted grid, ' + i.leftOutReach + ' out of reach)'
            : ' · nothing left out')
          : (i.straight ? ' · ' + i.straight + ' played straight ('
              + i.straightGrid + ' untrusted grid, ' + i.straightReach + ' out of reach)'
            : ' · all beatmatched')));
  };
  btn('build set · all tracks', () => build('all'), true);
  btn('build · best matches', () => build('best'));

  const libBtn = btn('library', async () => { const n = await window.DW.openLibrary();
    const miss = dash.set.filter(t => !window.DW.LIB.find(t)).length;
    log(n + ' files · ' + (dash.set.length - miss) + '/' + dash.set.length + ' resolvable'
      + (miss ? ' · ' + miss + ' missing' : '')); });
  libBtn.dataset.ph = 'cfg';          /* phone: behind ⚙ display */

  /* ── "songs with brackets in the title won't load" ────────────────────
     A track that will not decode is spliced out of the order by chain() with
     one line in the log, which nobody is watching at the moment it scrolls
     past. So the symptom is "that one never plays" and there is no evidence
     anywhere afterwards.

     This decodes every track in the set FOR REAL — the same decodeAudioData
     call playback makes — and prints the ones that fail with the decoder's
     own message. A name-resolution failure and a decode failure look
     identical from the outside and have completely different fixes, so the
     stage is reported separately. The full list goes to the console because
     the log line is one line. */
  const auditBtn = btn('◎ audit set', async () => {
    if (!dash.set.length) { log('build a set first'); return; }
    if (!window.DW.LIB.files) { log('open the library first'); return; }
    log('auditing…');
    const r = await window.DW.audit(dash.set,
      (i, n, nm) => log('audit ' + i + '/' + n + ' · ' + String(nm).slice(-34)));
    if (typeof r === 'string') { log(r); return; }
    log(r.playable + '/' + r.checked + ' playable'
      + (r.failed ? ' · ' + r.failed + ' FAILED — see console' : ' · none failed')
      + (r.viaLibflac && r.viaLibflac.length ? ' · ' + r.viaLibflac.length + ' decoded via libflac (browser refused them)' : '')
      + (r.durationMismatch.length ? ' · ' + r.durationMismatch.length + ' length mismatch' : ''));
    console.log('%cdeckwave audit', 'font-weight:bold',
      r.playable + '/' + r.checked + ' playable');
    if (r.failures.length) console.table(r.failures);
    if (r.durationMismatch.length) {
      console.warn('decoded length disagrees with the analysed length — ' +
                   'the beat grid was measured against a different duration');
      console.table(r.durationMismatch);
    }
  });
  auditBtn.dataset.ph = 'cfg';        /* phone: behind ⚙ display */

  sep(GRP.play);
  /* phone only (CSS hides it elsewhere): panels or the set, one screen at a
     time — the set screen is the track list AND the now-playing card */
  const phl = btn('☰ set', () => {
    const on = app.classList.toggle('ph-list');
    phl.textContent = on ? '▦ panels' : '☰ set';
    phl.className = 'phl' + (on ? ' hot' : '');
    setTimeout(dash.fit, 60);
  }, false, GRP.play);
  phl.className = 'phl';
  btn('▶ play', async () => {
    if (!dash.set.length) { log('build a set first'); return; }
    if (!window.DW.LIB.files) { log('open the library first'); return; }
    try { log(await window.DW.play(dash.set, 0)); }
    catch (e) { log('cannot play: ' + String((e && e.message) || e) + ' — deck stopped'); } }, true, GRP.play);
  btn('pause', () => log(window.DW.pause()), false, GRP.play);
  btn('next ▶', async () => {
    try { log(await window.DW.skip()); }
    catch (e) { log('cannot play next: ' + String((e && e.message) || e) + ' — deck stopped'); } }, false, GRP.play);
  btn('■ stop', () => log(window.DW.stop()), false, GRP.play);
  btn('kill', () => log(window.DW.kill()), false, GRP.play).dataset.ph = 'cfg';

  sep(GRP.cfg);
  const rc = btn('register colour: off', () => {
    const M = window.DWREGISTER.mode; M.on = !M.on;
    rc.textContent = 'register colour: ' + (M.on ? 'on' : 'off');
    rc.className = M.on ? 'hot' : '';
    if (!M.on) ['--dw-color-accent', '--dw-color-accent-2']
      .forEach(k => dash.host.style.removeProperty(k));
  });
  rc.dataset.grp = GRP.cfg;

  /* ── settle: ride a stretched deck back to its own speed ──────────────
     OFF by default and it must stay that way until it has been heard. See
     the settle block in deckwave.js for what switching it on changes — it is
     not only the sound of one track, it moves the rolling tempo target and
     therefore every gate test after it.

     minStretch is set from DWNAV.GATE rather than from a number typed here.
     There is one gate in this project and it lives in DWNAV; a second copy
     would be free to drift away from the first, which is exactly the 45/40
     dwell clash one layer down. */
  const sb = btn('settle after a bad blend: off', () => {
    const S = window.DW.settle;
    S.on = !S.on;
    S.minStretch = window.DWNAV ? window.DWNAV.GATE : null;
    sb.textContent = 'settle after a bad blend: ' + (S.on ? 'on · ' + S.seconds + 's' : 'off');
    sb.className = S.on ? 'hot' : '';
    log(S.on
      ? 'settle ON — a deck stretched past the gate rides back to its own speed over '
        + S.seconds + 's. UNTESTED BY EAR. It also hands over at the track’s own BPM '
        + 'instead of the 35% drift target, so the whole tempo plan downstream changes.'
      : 'settle off — decks hold the rate they started at, as before');
  });
  sb.dataset.grp = GRP.cfg;

  /* ── phone playback: what keeps a set alive when the screen goes dark ──
     OFF by default. `wake` holds a screen wake lock while a set plays —
     real, boring, costs battery. `media` routes the mix through an <audio>
     element with lock-screen metadata and buttons — the EXPERIMENT for iOS,
     where a Web Audio graph is suspended at lock and a media element is not;
     whether the element keeps the graph feeding it alive is exactly what
     nobody has established. See deckwave-phone.js. Both say so on the log. */
  if (window.DWPHONE) {
    const PH = window.DWPHONE;
    const phoneSel = select('phone', [
      { k: 'off',   n: 'off' },
      { k: 'wake',  n: 'keep screen on', hint: PH.cap.wakeLock ? 'wake lock' : 'no wake lock here' },
      { k: 'media', n: 'lock-screen audio', hint: 'experimental' }
    ], async k => {
      try {
        await PH.set(k);
        const s = PH.status;
        log(k === 'off' ? 'phone playback off — speakers, no wake lock'
          : k === 'wake' ? ('screen stays on while a set plays' + (s.wakeLockAvailable ? '' : ' — this browser has no wake lock, so nothing changes'))
          : 'mix routed through an <audio> element · output via ' + s.output + ' · element ' + s.audioElement
            + ' · UNTESTED on a locked phone: if the music stops a few seconds after locking, use "keep screen on"');
      } catch (e) { log('phone mode: ' + String((e && e.message) || e)); }
    }, PH.mode, GRP.cfg);
    /* a saved mode is re-applied on load so a phone set up once stays set up */
    if (PH.mode !== 'off') setTimeout(() => PH.set(PH.mode).catch(() => {}), 0);
  }

  /* Two copies of one recording is still two songs the owner chose to keep.
     Off by default because an album track and its single really are the same
     master here, but it is a preference, not a fact about the music. */
  const db = btn('keep duplicate versions: off', () => {
    keepDupes = !keepDupes;
    db.textContent = 'keep duplicate versions: ' + (keepDupes ? 'on' : 'off');
    db.className = keepDupes ? 'hot' : '';
    log(keepDupes
      ? 'duplicates kept — album and single versions both enter the set. Rebuild to apply.'
      : 'duplicates merged — one copy of each recording, highest confidence wins. Rebuild to apply.');
  });
  db.dataset.grp = GRP.cfg;

  sep(GRP.files);
  btn('▾ save set', () => {
    if (!dash.set.length) { log('build a set first'); return; }
    const sc = window.DWSCORE.score(dash.set, { xfade: 16 });
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    const dl = (txt, name, mime) => { const b = new Blob([txt], { type: mime });
      const u = URL.createObjectURL(b), a = document.createElement('a');
      a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(u), 15000); };
    dl(JSON.stringify(sc, null, 2), 'deckwave-set-' + stamp + '.json', 'application/json');
    setTimeout(() => dl(window.DWSCORE.cue(sc, 'Deckwave'),
      'deckwave-set-' + stamp + '.cue', 'text/plain'), 350);
    log('downloaded · ' + sc.summary.tracks + ' tracks');
  }, true, GRP.files);

  const lsb = btn('▴ load set', () => {
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.json';
    inp.onchange = async () => { if (!inp.files[0]) return;
      try { const r = window.DWSCORE.load(await inp.files[0].text(), window.DW.corpus);
        dash.set = r.set;
        log('loaded ' + r.loaded + (r.missing.length ? ' · ' + r.missing.length + ' missing' : ' · complete'));
      } catch (e) { log('load failed: ' + e.message); } };
    inp.click();
  });
  lsb.dataset.grp = GRP.files;

  /* ── ROADMAP D1: the corpus cache finally has a button ────────────────
     The analysis cache is the most expensive thing in the browser — 12
     minutes of analysis for this library, and a different Essentia build
     may not reproduce it bit-for-bit — and clearing site data destroys it
     in one click. DWCACHE has existed to protect it since patch 06 and was
     reachable from the console only. Two buttons, beside the set's own.
     Restore MERGES by default (existing records are kept); the result is
     verified against the summary the file carries, not assumed. */
  const csb = btn('▾ save cache', async () => {
    if (!window.DWCACHE) { log('cache module not loaded'); return; }
    try {
      const r = await window.DWCACHE.export();
      log('cache saved · ' + r.summary.tracks + ' tracks · ' + r.summary.totalBeats + ' beats · ' + r.file);
    } catch (e) { log('cache export failed: ' + String((e && e.message) || e)); }
  });
  csb.dataset.grp = GRP.files;
  const clb = btn('▴ load cache', () => {
    if (!window.DWCACHE) { log('cache module not loaded'); return; }
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.json';
    inp.onchange = async () => { if (!inp.files[0]) return;
      try {
        const r = await window.DWCACHE.restore(await inp.files[0].text(), 'merge');
        log('cache restored · ' + r.imported + ' records merged · store now ' + r.after.tracks +
            ' tracks · scan the folder again to use them');
      } catch (e) { log('cache restore failed: ' + String((e && e.message) || e)); } };
    inp.click();
  });
  clb.dataset.grp = GRP.files;

  sep();
  const app = sr.querySelector('.app');
  const layoutSel = select('layout', [
    { k: 'auto', n: 'auto', hint: 'by aspect' },
    { k: 'mega', n: '▪ MEGA · all 12', hint: 'widescreen' },
    { k: '6', n: '6 across' }, { k: '5', n: '5 across' }, { k: '4', n: '4 across' },
    { k: '3', n: '3 across' }, { k: '2', n: '2 × n', hint: 'square' },
    { k: '1', n: 'single column', hint: 'tall' }
  ], k => {
    dash.layoutMode = k;
    if (k === 'mega') { log(DWDASH.mega(dash)); return; }
    if (k === 'auto') { log('layout: auto · ' + autoLayout(true)); return; }
    if (app.getAttribute('data-cols') === 'mega') {
      dash.slots.reset(window.DWPANELS.defaults);
      /* reset() rebuilds the cells without their fold controls; only
         apply() puts them back. __reset and mega() both call it — this path
         and autoLayout() did not, so leaving mega lost every ▾ */
      setTimeout(() => dash.applyFolds && dash.applyFolds(), 90);
    }
    app.setAttribute('data-cols', k);
    log('layout: ' + k); setTimeout(dash.fit, 80);
  }, 'auto');

  /* ── auto, actually automatic ──────────────────────────────────────────
     "auto" used to mean "remove the override and let a static grid decide",
     which was five columns from an aspect-ratio media query regardless of how
     much room there was. On a 1966px-wide window that left six panels in five
     columns, so one wrapped alone onto a second row.

     It now picks from the width actually available to the panel area, so the
     side column being wide, narrow or hidden all count.

     MIN_COL is a minimum readable panel width, not a signal threshold. 250px
     was chosen against the measured case: at 1966px viewport the panel area
     is ~1625px, which is 271px across six columns — so six fits with a little
     margin, and the number is one constant to move if that reads too tight.

     PANELS ARE ONLY SWAPPED WHEN YOU PICK auto, never on resize. Going mega
     calls slots.reset(ALL), which discards any arrangement you have made;
     doing that every time a window crossed a width would be hostile. Resize
     re-flows the columns and leaves the panel set alone. */
  const MIN_COL = 250;
  function autoLayout(mayChangePanels, atStartup) {
    const tri = $('tri');
    const w = tri ? tri.getBoundingClientRect().width : 0;
    const avail = w > 40 ? w : (innerWidth - 260);
    const cols = Math.max(1, Math.min(6, Math.floor(avail / MIN_COL)));
    if (cols >= 6) {
      if (mayChangePanels) { const r = DWDASH.mega(dash, atStartup);
        return 'MEGA · ' + r + ' · ' + cols + ' across'; }
      app.setAttribute('data-cols', 'mega');
      setTimeout(dash.fit, 80);
      return 'mega columns';
    }
    if (app.getAttribute('data-cols') === 'mega' && mayChangePanels && !atStartup) {
      dash.slots.reset(window.DWPANELS.defaults);
      setTimeout(() => dash.applyFolds && dash.applyFolds(), 90);   /* see the layout menu */
    }
    app.setAttribute('data-cols', String(cols));
    setTimeout(dash.fit, 80);
    return cols + ' across · ' + Math.round(avail) + 'px available';
  }

  /* Re-flow on resize, but only while the user is actually in auto. */
  let autoT;
  addEventListener('resize', () => {
    if (dash.layoutMode !== 'auto') return;
    clearTimeout(autoT); autoT = setTimeout(() => autoLayout(false), 140);
  });

  dash.layoutMode = 'auto';
  autoLayout(true, true);          /* startup: widen, but keep what was saved */

  const THEMES = ['cyberpunk','amber','classic','paper','mono','ice','stargaze','darkwing','sewage','expanse'];
  const SWATCH = { cyberpunk:['#04010f','#22e8ff','#ff2d95'], amber:['#0a0600','#ffb02e','#ff7020'],
    classic:['#000000','#00ff41','#ffff00'], paper:['#faf7f0','#2f6f8f','#a8452f'],
    mono:['#0c0c0c','#ffffff','#bbbbbb'], ice:['#020a14','#7fdcff','#c9a6ff'],
    stargaze:['#03040e','#8fd4ff','#ffd98a'], darkwing:['#0a0416','#b06bff','#ffd23f'],
    sewage:['#0d1108','#8fbf3f','#a87b2e'], expanse:['#04060c','#4fd8d0','#ff7a3c'] };
  let theme = 'cyberpunk';
  try { const sv = localStorage.getItem('dw-theme');
    if (sv && THEMES.includes(sv)) theme = sv; } catch (e) {}
  const applyTheme = t => { THEMES.forEach(x => dash.host.classList.remove('dw-theme-' + x));
    dash.host.classList.add('dw-theme-' + t); dash.theme = t;
    try { localStorage.setItem('dw-theme', t); } catch (e) {}
    setTimeout(dash.fit, 60); };
  applyTheme(theme);
  const themeSel = select('theme', THEMES.map(t => ({ k: t, n: t,
    sw: SWATCH[t] })), applyTheme, theme);
  /* A saved view carries its theme and its column count. views.load() puts
     the attributes on the grid but could not reach these controls, so the
     theme never changed, the layout label kept its old text, and
     dash.layoutMode stayed 'auto' — the next resize then overwrote the
     loaded columns. Handed over here, where the controls live. */
  dash.onViewLoaded = v => {
    if (v.theme && THEMES.includes(v.theme) && v.theme !== dash.theme) { applyTheme(v.theme); themeSel.set(v.theme); }
    const k = v.cols || 'auto';
    dash.layoutMode = k; layoutSel.set(k);
  };


  let viewSel;
  const viewItems = () => dash.views.list().map(n => ({ k: n, n }))
    .concat([{ k: '__save', n: '⭳ save current as…' },
             { k: '__reset', n: '↺ reset to default' },
             { k: '__export', n: '⤓ export views' },
             { k: '__import', n: '⤒ import views' }]);
  const onView = k => {
    if (k === '__save') { const n = prompt('Name this view:');
      if (n) { dash.views.save(n); log('saved view “' + n + '”'); rebuildViews(); } return; }
    if (k === '__reset') { dash.slots.reset(window.DWPANELS.defaults);
      setTimeout(() => { dash.applyFolds(); dash.fit(); }, 80); log('views reset'); return; }
    if (k === '__export') { const b = new Blob([dash.views.export()], { type: 'application/json' });
      const u = URL.createObjectURL(b), a = document.createElement('a');
      a.href = u; a.download = 'deckwave-views.json';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(u), 9000); log('views exported'); return; }
    if (k === '__import') { const i = document.createElement('input');
      i.type = 'file'; i.accept = '.json';
      i.onchange = async () => { try { const n = dash.views.import(await i.files[0].text());
        log('imported ' + n + ' views'); rebuildViews(); }
        catch (e) { log('import failed: ' + e.message); } };
      i.click(); return; }
    dash.views.load(k); log('view: ' + k);
  };
  function rebuildViews() { if (viewSel) viewSel.el.remove();
    viewSel = select('view', viewItems(), onView, dash.views.list()[0] || 'default'); }
  if (!dash.views.list().length) dash.views.save('default');
  rebuildViews();

  /* ── recovered from the live build ────────────────────────────────────
     The packaged transport was missing these three. The engine could already
     do all of it — DWLISTEN.mic() has been there the whole time, and the two
     layout modes are attribute flips the CSS above now carries again. */

  select('list', [
    { k: 'show', n: 'track list on' },
    { k: 'wide', n: 'track list wide', hint: 'wider column' },
    { k: 'hide', n: 'track list off', hint: 'panels full width' }
  ], k => {
    k === 'show' ? app.removeAttribute('data-side') : app.setAttribute('data-side', k);
    /* The now-playing card lives in this column, so hiding it takes the card
       too. Say so on the button rather than leaving it lit for something the
       user cannot see. */
    const nb = [...tp.querySelectorAll('button')].find(b => /^now playing/.test(b.textContent));
    if (nb) {
      const gone = k === 'hide';
      nb.disabled = gone;
      nb.title = gone ? 'hidden with the track list' : '';
      if (gone) nb.className = '';
    }
    log('track list: ' + k + (k === 'hide' ? ' · now playing hidden with it' : ''));
    setTimeout(dash.fit, 80);
  }, 'show');

  /* Centre sprite for the camelot wheel. Recovered from the live build; the
     alternatives are original shapes. */
  /* Built from the LIVE registry, not a hardcoded list — a module that
     registers a sprite after this file loads (deckwave-sprites.js does)
     used to be invisible here, which is exactly how the duck went missing.
     The originals keep their hints and their order; anything registered
     later is appended with the theme it belongs to as its hint. */
  {
    const HINT = { jam: 'the original', robot: 'wee dude', orbit: 'quieter',
                   pulse: 'level bars', auto: 'follows theme' };
    const OG = ['jam', 'robot', 'orbit', 'pulse', 'none'];
    const live = (window.DWPANELS && window.DWPANELS.sprites) || OG;
    const byTheme = (window.DWSPRITES && window.DWSPRITES.byTheme) || {};
    const themeOf = id => Object.keys(byTheme).find(t => byTheme[t] === id) || '';
    const order = OG.filter(k => live.includes(k))
      .concat(live.filter(k => !OG.includes(k)));
    select('sprite', order.map(k => ({ k, n: k, hint: HINT[k] || themeOf(k) })),
      k => { window.DWPANELS.sprite = k; log('sprite: ' + k); },
      (window.DWPANELS && window.DWPANELS.sprite) || 'jam');
  }

  select('density', [
    { k: '0', n: 'comfortable' },
    { k: '1', n: 'dense', hint: 'tighter rows' }
  ], k => {
    k === '1' ? app.setAttribute('data-dense', '1') : app.removeAttribute('data-dense');
    log('density: ' + (k === '1' ? 'dense' : 'comfortable')); setTimeout(dash.fit, 80);
  }, '0');

  /* Carried over from the transport mount() used to build inline. It is the
     one control the newer bar did not already have, and dropping it while
     de-duplicating would have lost a working feature to a cleanup. */
  const mb = btn('– compact', () => {
    const on = app.classList.toggle('mini');
    dash.host.classList.toggle('mini-host', on);
    const nl = $('nowline'); if (nl) nl.style.display = on ? 'block' : 'none';
    mb.textContent = on ? '+ expand' : '– compact';
    mb.className = on ? 'hot' : '';
    setTimeout(dash.fit, 60); }, false, GRP.cfg);

  sep(GRP.cap);
  /* Both capture buttons paint from ONE fact — DWLISTEN.kind — rather than
     each remembering what it last did. Starting one while the other was
     live stopped the capture but left the other button lit; Chrome's own
     "Stop sharing" bar ends the stream without telling either. Painted
     after every action and on a slow tick so the external stop is seen. */
  const paintCapture = () => {
    const L = window.DWLISTEN, k = L && L.kind;
    lb.textContent = k === 'tab' ? '◉ listening' : '◉ listen to a tab'; lb.className = k === 'tab' ? 'hot' : '';
    ib.textContent = k === 'mic' ? '◉ input live' : '◉ input';        ib.className = k === 'mic' ? 'hot' : '';
  };
  const lb = btn('◉ listen to a tab', async () => {
    if (window.DWLISTEN.kind === 'tab') { window.DWLISTEN.stop(); paintCapture(); log('stopped listening'); return; }
    try { log('pick a tab · tick "Share tab audio"');
      const r = await window.DWLISTEN.tab();
      log('listening to ' + r.source.slice(0, 40) + ' · visuals only, no analysis');
    } catch (e) { log(String(e.message || e)); }
    paintCapture(); });
  lb.dataset.grp = GRP.cap;

  /* Offline bounce to FLAC. Deliberately NOT labelled "export mix" — what it
     writes is not what you hear, because the render does not time-stretch.
     See the header of deckwave-render.js. */
  const rb = btn('⤓ render flac', async () => {
    if (!window.DWRENDER) { log('render module not loaded'); return; }
    const set = dash.set || [];
    if (!set.length) { log('build a set first'); return; }
    const est = window.DWRENDER.estimate(set, {});
    if (est.overCeiling) {
      log(est.totalSeconds.toFixed(0) + 's set = ' + est.gb + 'GB · too big — rendering the first 20 min');
    }
    const to = est.overCeiling ? 1200 : undefined;
    rb.className = 'hot';
    try {
      const r = await window.DWRENDER.exportMix(set, { to, onStatus: log });
      log('saved ' + r.file + ' · ' + r.mb + 'MB · ' + r.tracks + ' tracks · NOT tempo-matched');
    } catch (e) {
      log('render failed: ' + String((e && e.message) || e));
    } finally { rb.className = ''; }
  });
  rb.dataset.grp = GRP.files;

  /* Recovered from the live build. DWLISTEN.mic() was already in the package;
     nothing in the packaged UI ever called it. Same catch as scan — cancelling
     a permission prompt rejects, and an uncaught rejection leaves the log
     line lying about what it is waiting for. */
  const ib = btn('◉ input', async () => {
    if (window.DWLISTEN.kind === 'mic') { window.DWLISTEN.stop(); paintCapture(); log('stopped listening'); return; }
    try { log('pick an input device…');
      const r = await window.DWLISTEN.mic();
      log('input: ' + r.source.slice(0, 40) + ' · visuals only, no analysis');
    } catch (e) {
      log(e && e.name === 'NotAllowedError' ? 'input permission refused'
        : String((e && e.message) || e));
    }
    paintCapture(); });
  ib.dataset.grp = GRP.cap;
  setInterval(paintCapture, 1000);

  /* now playing — restored to the always-visible row. It answers "what is
     happening", which is a performance question, not an appearance one. */
  const nb = btn('now playing', () => {
    const on = window.DWNOWPLAYING && window.DWNOWPLAYING.toggle();
    nb.className = on ? 'hot' : ''; }, false, GRP.play);
  nb.className = 'hot';

  /* ── master level ──────────────────────────────────────────────────────
     Web Audio output belongs to this page's AudioContext, so this cannot
     touch any other tab or application — it is Deckwave's level, not the
     system's. Reads and writes DW.volume, which survives boot() and kill()
     because the value is held outside the graph. */
  const vol = document.createElement('span');
  vol.className = 'vol'; vol.dataset.grp = GRP.play;
  const vlabel = document.createElement('u');
  const vslider = document.createElement('input');
  vslider.type = 'range'; vslider.min = '0'; vslider.max = '100'; vslider.step = '1';
  vslider.setAttribute('aria-label', 'master level');
  const paintVol = () => {
    const pct = Math.round(window.DW.volume * 100);
    vslider.value = String(pct);
    vlabel.textContent = 'level ' + pct + '%';
    vslider.title = 'master level ' + pct + '%';
  };
  vslider.oninput = () => { window.DW.volume = (+vslider.value) / 100; paintVol(); };
  paintVol();
  vol.appendChild(vlabel); vol.appendChild(vslider);
  tp.insertBefore(vol, $('logLine'));

  /* ── the collapse ──────────────────────────────────────────────────────
     One toggle for everything in the cfg group. Persisted, because a
     performer who collapsed it does not want it back on every reload. */
  let cfgOpen = false;
  try { cfgOpen = localStorage.getItem('dw-cfg-open') === '1'; } catch (e) {}
  const cfgBtn = btn('⚙ display', () => {
    cfgOpen = !cfgOpen; applyCfg();
    try { localStorage.setItem('dw-cfg-open', cfgOpen ? '1' : '0'); } catch (e) {}
    setTimeout(dash.fit, 80);
  }, false, GRP.deck);

  function applyCfg() {
    tp.querySelectorAll('[data-grp="' + GRP.cfg + '"]')
      .forEach(el => { el.style.display = cfgOpen ? '' : 'none'; });
    /* on a phone the files and capture groups fold behind this toggle too;
       the class is what the phone CSS keys on, harmless on a desktop */
    tp.classList.toggle('cfg-open', cfgOpen);
    cfgBtn.textContent = cfgOpen ? '⚙ display ▴' : '⚙ display';
    cfgBtn.className = cfgOpen ? 'hot' : '';
  }

  /* ── order the row by group ────────────────────────────────────────────
     Controls were added over many sessions in the order they were written,
     so DOM order and grouping had drifted apart — render flac sat between the
     two capture buttons. Reordering here rather than at each call site keeps
     the handlers untouched and makes the grouping a single readable list.
     Separators are rebuilt from scratch so they always land between groups
     and never orphan at an end. */
  function regroup() {
    const order = [GRP.deck, GRP.play, GRP.files, GRP.cap, GRP.cfg];
    tp.querySelectorAll('.sep').forEach(s => s.remove());
    const logLine = $('logLine');
    order.forEach((g, gi) => {
      const items = [...tp.children].filter(el => el.dataset && el.dataset.grp === g);
      if (!items.length) return;
      if (gi > 0) {
        const s = document.createElement('span');
        s.className = 'sep'; s.dataset.grp = g === GRP.cfg ? GRP.cfg : g;
        tp.insertBefore(s, logLine);
      }
      items.forEach(el => tp.insertBefore(el, logLine));
    });
  }
  regroup();
  applyCfg();
}

return { mount, CSS, get _dev() { return lastDash; } };
})()


/* ─────────────────────────────────────────────────────────────────────────
   SLOTS — every cell is a swap point.

   Each .tri child is a slot backed by the panel registry. Hovering a panel
   reveals a "?" (explanation + Wikipedia) and a "swap" control. The chosen
   layout persists to localStorage; "reset views" restores DWPANELS.defaults.

   Note the ordering constraint learned the hard way: the grid reflows when a
   slot changes WITHOUT the window ever resizing, so every mutation schedules
   a fit(). A canvas whose buffer was never resized draws perfectly into a
   300x150 nobody sized, which looks exactly like a broken renderer.
   ───────────────────────────────────────────────────────────────────────── */
DWDASH.slots = function (dash) {
  const sr = dash.shadow, tri = sr.querySelector('.tri');
  const KEY = 'dw-slots-v1';
  const slots = [];

  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(slots.map(s => s.panel))); } catch (e) {} };
  const restore = () => { try { const v = JSON.parse(localStorage.getItem(KEY)); return Array.isArray(v) ? v : null; } catch (e) { return null; } };

  function paint(slot) {
    const p = window.DWPANELS.get(slot.panel);
    slot.lbl.textContent = p ? p.label : slot.panel;
    /* Re-tag the glossary here, not just after build/reset. A swap never
       touches either of those — the menu handler calls paint() directly — so
       the label kept the PREVIOUS panel's `data-gl` and hovering it showed the
       old topic. Third time this class of bug has landed (ledger 20); the
       first two fixes each covered the rebuild path and missed the swap. */
    if (dash.glossary && dash.glossary.tag) setTimeout(dash.glossary.tag, 0);
    slot.menu.innerHTML = window.DWPANELS.list().map(x =>
      `<i data-k="${x.k}" class="${x.k === slot.panel ? 'on' : ''}">${x.n}${x.hint ? '<b>' + x.hint + '</b>' : ''}</i>`).join('');
    slot.menu.querySelectorAll('i').forEach(el => el.onclick = ev => {
      ev.stopPropagation(); slot.panel = el.dataset.k;
      slot.menu.classList.remove('open'); paint(slot); save();
      setTimeout(dash.fit, 40);
    });
  }

  function help(slot) {
    const w = window.DWPANELS.wiki(slot.panel);
    if (!w) { slot.help.innerHTML = '<p>No reference for this panel.</p>'; return; }
    slot.help.innerHTML =
      `<h4>${w.t}</h4><p>${w.d}</p>` +
      `<a href="${w.u}" target="_blank" rel="noopener">Wikipedia &rarr; ${w.t}</a>` +
      `<em>${w.verified ? 'link verified' : 'article title unverified — opens Wikipedia search'}</em>`;
  }

  /* Place a fixed-position popup against its trigger, inside the viewport.
     Opens downward when there is room and flips up when there is not, and
     clamps its height to the gap it actually got — so the internal scrollbar
     covers whatever is left over instead of the list running off the screen.
     MEASURED, not assumed: the box is shown before measuring, because a
     display:none element reports a zero rect and every clamp computed from
     it would be wrong in the same silent way. */
  const GAP = 6;
  function placeMenu(el, btn, minW) {
    const b = btn.getBoundingClientRect();
    el.style.maxHeight = 'none';
    el.style.left = '0px'; el.style.top = '0px';
    el.style.minWidth = minW + 'px';
    const wNat = el.getBoundingClientRect().width || minW;
    const below = innerHeight - b.bottom - GAP * 2, above = b.top - GAP * 2;
    const down = below >= Math.min(220, above) || below >= above;
    const room = Math.max(120, down ? below : above);
    el.style.maxHeight = room + 'px';
    const hNow = Math.min(el.getBoundingClientRect().height, room);
    let left = Math.min(b.right - wNat, innerWidth - wNat - GAP);
    el.style.left = Math.max(GAP, left) + 'px';
    el.style.top = (down ? b.bottom + GAP : Math.max(GAP, b.top - GAP - hNow)) + 'px';
  }

  /* A fixed popup does not travel with its cell, so anything that moves the
     grid under it has to close it rather than leave it stranded. */
  addEventListener('resize', () => {
    sr.querySelectorAll('.pmenu,.hcard').forEach(m => m.classList.remove('open')); });
  tri.addEventListener('scroll', () => {
    sr.querySelectorAll('.pmenu,.hcard').forEach(m => m.classList.remove('open')); }, { passive: true });

  function build(defaults) {
    tri.innerHTML = ''; slots.length = 0;
    const want = restore() || defaults;
    want.forEach((pid, i) => {
      if (!window.DWPANELS.has(pid)) pid = defaults[i] || 'spectrum';
      const cid = 'slot' + i;
      const d = document.createElement('div'); d.className = 'strip';
      d.innerHTML = `<u><span class="lbl"></span><span class="hbtn">?</span><span class="swap">swap &#9662;</span></u>`
                  + `<div class="cw"><canvas id="${cid}"></canvas></div>`
                  + `<span class="pmenu"></span><div class="hcard"></div>`;
      tri.appendChild(d);
      const slot = { i, el: d, cid, panel: pid, canvas: d.querySelector('canvas'),
        lbl: d.querySelector('.lbl'), menu: d.querySelector('.pmenu'), help: d.querySelector('.hcard') };
      slot.ctx = slot.canvas.getContext('2d');
      dash.C[cid] = slot.canvas; dash.X[cid] = slot.ctx;
      slots.push(slot); paint(slot);

      const swapBtn = d.querySelector('.swap'), helpBtn = d.querySelector('.hbtn');
      swapBtn.onclick = e => { e.stopPropagation();
        sr.querySelectorAll('.pmenu,.hcard').forEach(m => { if (m !== slot.menu) m.classList.remove('open'); });
        const opening = !slot.menu.classList.contains('open');
        slot.menu.classList.toggle('open');
        if (opening) placeMenu(slot.menu, swapBtn, 190); };
      helpBtn.onclick = e => { e.stopPropagation();
        sr.querySelectorAll('.pmenu,.hcard').forEach(c => { if (c !== slot.help) c.classList.remove('open'); });
        help(slot);
        const opening = !slot.help.classList.contains('open');
        slot.help.classList.toggle('open');
        if (opening) placeMenu(slot.help, helpBtn, Math.max(240, d.getBoundingClientRect().width - 12)); };
      d.onclick = e => e.stopPropagation();
      if (dash.ro) dash.ro.observe(d);
    });
    setTimeout(dash.fit, 60);
  }

  document.addEventListener('click', () => {
    sr.querySelectorAll('.pmenu,.hcard').forEach(m => m.classList.remove('open')); });

  build(window.DWPANELS.defaults);

  return {
    build, save, get slots() { return slots; },
    /* Does the keeper have an arrangement of their own saved? mega() needs to
       know, so that a page load can honour it instead of overwriting it. */
    hasStored: () => restore() !== null,
    set(i, pid) { if (slots[i] && window.DWPANELS.has(pid)) { slots[i].panel = pid; paint(slots[i]); save(); } },
    reset(d) { try { localStorage.removeItem(KEY); } catch (e) {} build(d || window.DWPANELS.defaults); },
    layout: () => slots.map(s => s.panel)
  };
};


/* ─────────────────────────────────────────────────────────────────────────
   HEADER GLOSSARY — quiet mouseover on each top-bar term.

   Each entry explains what the number means IN THIS SYSTEM, not just the
   general concept, and links to Wikipedia. verified:true was confirmed to
   resolve; the rest use the search URL, same discipline as the panels.
   ───────────────────────────────────────────────────────────────────────── */
DWDASH.TERMS = {
  kPos: { t:'DJ mix', u:'https://en.wikipedia.org/wiki/Special:Search?search=DJ+mix', verified:false,
    d:'Position in the set — which track of how many, counted from the track on the DECK. Click any row in the list for the steering menu: blend in now, queue as next, a scenic or fast route, or a plain jump.' },
  kBpm: { t:'Tempo', u:'https://en.wikipedia.org/wiki/Tempo', verified:false,
    d:'The rolling target in beats per minute. It drifts 35% toward each incoming track rather than holding one fixed BPM, which is how a set can climb 100 → 150 without over-stretching anything.' },
  kKey: { t:'Key (music)', u:'https://en.wikipedia.org/wiki/Key_(music)', verified:false,
    d:'The current key in Camelot notation — 12 numbers, A for minor and B for major. Adjacent numbers are a perfect fifth apart; the same number with the other letter is the relative major or minor.' },
  kStr: { t:'Audio time stretching and pitch scaling', u:'https://en.wikipedia.org/wiki/Audio_time_stretching_and_pitch_scaling', verified:true,
    d:'How far the DECK is bending this track from its native tempo, with pitch preserved — the live rate, not the plan. Amber past 8%. Beyond roughly 15% the stretch becomes an audible wobble — a perceptual limit, not a preference, which is why beatmatched transitions stay inside 8% and anything further away is played straight instead. ∿ means straight: unstretched because it is not being beatmatched, so there is no figure to print.' },
  kHit: { t:'Onset detection', u:'https://en.wikipedia.org/wiki/Special:Search?search=onset+detection+audio', verified:false,
    d:'Bass onsets in the last 8 seconds, found with spectral flux — frame-to-frame positive change in the low bins. It measures CHANGE rather than level, because sidechained music holds bass energy near constant and a loudness threshold never fires.' },
  kReg: { t:'Spectral centroid', u:'https://en.wikipedia.org/wiki/Special:Search?search=spectral+centroid', verified:false,
    d:'The magnitude-weighted mean frequency — the standard measure of perceived brightness. Drives the palette when register colour is on. Heavily damped so it drifts rather than flickers.' }
};

DWDASH.glossary = function (dash) {
  const sr = dash.shadow;
  Object.keys(DWDASH.TERMS).forEach(id => {
    const b = sr.getElementById(id); if (!b) return;
    const kv = b.closest('.kv'); if (!kv || kv.querySelector('.tip')) return;
    const w = DWDASH.TERMS[id];
    const tip = document.createElement('span'); tip.className = 'tip';
    tip.innerHTML = `<h5>${w.t}</h5><p>${w.d}</p>`
      + `<a href="${w.u}" target="_blank" rel="noopener">Wikipedia &rarr; ${w.t}</a>`
      + `<em>${w.verified ? 'link verified' : 'article title unverified — opens Wikipedia search'}</em>`;
    kv.appendChild(tip);
  });
};


/* ─────────────────────────────────────────────────────────────────────────
   VIEWS — a saved view is the whole arrangement, not just the panel list:
   which panels, column count, sidebar state, density, theme, and which
   panels are folded. Exportable so a layout can travel between machines.
   ───────────────────────────────────────────────────────────────────────── */
DWDASH.views = function (dash) {
  const sr = dash.shadow, KEY = 'dw-views-v1', FOLD = 'dw-folded-v1';
  const app = () => sr.querySelector('.app');
  const read = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } };
  const write = o => { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} };
  const folds = () => { try { return JSON.parse(localStorage.getItem(FOLD)) || {}; } catch (e) { return {}; } };

  return {
    list: () => Object.keys(read()),
    snapshot() {
      const a = app();
      return { panels: dash.slots.layout(), cols: a.getAttribute('data-cols') || 'auto',
        side: a.getAttribute('data-side') || 'show', dense: a.getAttribute('data-dense') || '0',
        theme: dash.theme || 'cyberpunk', folded: folds() };
    },
    save(name) { if (!name) return null; const all = read(); all[name] = this.snapshot(); write(all); return name; },
    load(name) {
      const v = read()[name]; if (!v) return null;
      try { localStorage.setItem('dw-slots-v1', JSON.stringify(v.panels)); } catch (e) {}
      try { localStorage.setItem(FOLD, JSON.stringify(v.folded || {})); } catch (e) {}
      dash.slots.build(v.panels);
      const a = app();
      v.cols  === 'auto' ? a.removeAttribute('data-cols')  : a.setAttribute('data-cols', v.cols);
      v.side  === 'show' ? a.removeAttribute('data-side')  : a.setAttribute('data-side', v.side);
      v.dense === '0'    ? a.removeAttribute('data-dense') : a.setAttribute('data-dense', v.dense);
      if (dash.onViewLoaded) dash.onViewLoaded(v);      /* theme + layout controls */
      setTimeout(() => { dash.applyFolds(); dash.fit(); }, 80);
      return name;
    },
    remove(n) { const all = read(); delete all[n]; write(all); return n; },
    export() { return JSON.stringify({ format: 'deckwave-views', version: 1, views: read() }, null, 2); },
    import(j) {
      const d = typeof j === 'string' ? JSON.parse(j) : j;
      if (d.format !== 'deckwave-views') throw new Error('not a deckwave views file');
      const all = read(); Object.assign(all, d.views); write(all);
      return Object.keys(d.views).length;
    }
  };
};

/* MEGA — every registered panel at once, for a widescreen monitor. */
/* keep=true means "widen to six columns but do not touch the panel choice".
   Startup passes it. Without it every page load ran slots.reset(ALL), and
   reset() clears the saved layout before rebuilding — so any panel swapped in
   by hand was gone on the next load, and the arrangement had to be rebuilt
   every single time. The comment above autoLayout already said doing this
   unbidden would be hostile; it was being done on every load regardless.

   Choosing "mega" from the layout menu still means all twelve. That is what
   picking it is for. The difference is that a page load is not a choice. */
DWDASH.mega = function (dash, keep) {
  if (keep && dash.slots.hasStored()) {
    dash.shadow.querySelector('.app').setAttribute('data-cols', 'mega');
    setTimeout(() => { dash.applyFolds(); dash.fit(); }, 120);
    return dash.slots.slots.length + ' panels · kept your arrangement';
  }
  try { localStorage.removeItem('dw-folded-v1'); } catch (e) {}
  dash.slots.reset(window.DWPANELS.ALL);
  dash.shadow.querySelector('.app').setAttribute('data-cols', 'mega');
  setTimeout(() => { dash.applyFolds(); dash.fit(); }, 120);
  return window.DWPANELS.ALL.length + ' panels';
};

/* Collapse/expand per panel, persisted by panel id. */
DWDASH.folds = function (dash) {
  const KEY = 'dw-folded-v1';
  const read = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } };
  const write = o => { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} };
  return function apply() {
    const f = read();
    dash.slots.slots.forEach(s => {
      const u = s.el.querySelector('u');
      let btn = u.querySelector('.fold');
      if (!btn) {
        btn = document.createElement('span'); btn.className = 'fold';
        u.insertBefore(btn, u.querySelector('.swap'));
        btn.onclick = e => { e.stopPropagation();
          const st = read(); st[s.panel] = !st[s.panel]; write(st);
          apply(); setTimeout(dash.fit, 60); };
      }
      const on = !!f[s.panel];
      s.el.classList.toggle('collapsed', on);
      btn.textContent = on ? '\u25b8' : '\u25be';
      btn.title = on ? 'expand' : 'collapse';
    });
  };
};


/* ─────────────────────────────────────────────────────────────────────────
   GLOSSARY BINDING — hover any term, get what it means here.

   The tooltips vanished twice before this. Both times the cause was the
   same: help was added by patching slot construction, so any rebuild
   (reset, mega, a layout change) recreated the cells without it.

   The fix is not a better patch. It is that terms live in DWMSG as DATA and
   elements are tagged with data-gl="key", so rebuilding re-tags rather than
   re-creating. Nothing can be dropped because nothing was ever stored in
   the DOM.

   One popup element is reused and repositioned rather than one per term —
   with twelve panels and a dozen header fields that is the difference
   between 1 node and 40.
   ───────────────────────────────────────────────────────────────────────── */
DWDASH.glossaryBind = function (dash) {
  const sr = dash.shadow;
  let pop = sr.getElementById('glpop');
  if (!pop) { pop = document.createElement('div'); pop.className = 'glpop';
    pop.id = 'glpop'; sr.appendChild(pop);
    pop.onmouseenter = () => pop.classList.add('on');
    pop.onmouseleave = () => pop.classList.remove('on'); }

  function show(el, key) {
    const m = window.DWMSG.term(key); if (!m) return;
    pop.innerHTML = '<h5>' + m.t + '</h5>' + m.d
      + (m.w ? '<a href="' + m.w + '" target="_blank" rel="noopener">Wikipedia &rarr; '
        + m.t + '</a><em>' + (m.verified ? window.DWMSG.ui('ui.verified')
        : window.DWMSG.ui('ui.unverified')) + '</em>' : '');
    pop.classList.add('on');
    const r = el.getBoundingClientRect(), pr = pop.getBoundingClientRect();
    let left = r.left, top = r.bottom + 6;
    if (left + pr.width > innerWidth - 8) left = innerWidth - pr.width - 8;
    if (top + pr.height > innerHeight - 8) top = r.top - pr.height - 6;
    pop.style.left = Math.max(8, left) + 'px';
    pop.style.top = Math.max(8, top) + 'px';
  }

  function bind(root) {
    (root || sr).querySelectorAll('[data-gl]').forEach(el => {
      if (el.__glBound) return; el.__glBound = true; el.classList.add('gl');
      el.onmouseenter = () => show(el, el.dataset.gl);
      el.onmouseleave = () => setTimeout(() => {
        if (!pop.matches(':hover')) pop.classList.remove('on'); }, 120);
    });
    return sr.querySelectorAll('[data-gl]').length;
  }

  /* which glossary key each panel and header field maps to */
  const PANEL = { waterfall:'spectrogram', chroma:'chromagram', camelot:'camelot',
    gonio:'goniometer', vu:'vu', transition:'beatmatch', position:'position',
    polygraph:'polygraph', spectrum:'spectrum', journey:'journey',
    loudness:'lufs', scope:'oscilloscope', centre:'centre',
    timeline:'timeline', drops:'drops', loudtime:'loudtime',
    route:'route', wayposts:'wayposts', sprite:'sprite',
    energy15:'energy-window', energy30:'energy-window', energy45:'energy-window',
    energy60:'energy-window', energy90:'energy-window' };
  const HEAD = { kBpm:'bpm', kKey:'key', kStr:'stretch', kHit:'spectral-flux', kReg:'register' };

  /* ── ROADMAP D6: the map is checked, not trusted ──────────────────────
     Every registered panel must have an entry here, every entry must name a
     registered panel, and every value must resolve to a term in DWMSG.
     Until 2026-08-19 three entries (position, journey, centre) pointed at
     terms that did not exist and one (spectrum) at the wrong concept, the
     header's kHit at 'flux' which is not a key, and six registered panels
     had no entry at all — the label looked hoverable and the hover did
     nothing. Logged rather than thrown: a stale map is a display defect,
     not a reason to stop the deck. DWDASH.glossaryAudit() returns the same
     report for the console. */
  function audit() {
    const reg = (window.DWPANELS && window.DWPANELS.list) ? window.DWPANELS.list().map(x => x.k) : [];
    const term = k => window.DWMSG && window.DWMSG.term(k);
    const out = {
      panelsWithoutTerm: reg.filter(id => !PANEL[id]),
      entriesWithoutPanel: Object.keys(PANEL).filter(id => reg.length && !reg.includes(id)),
      unresolvedTerms: Object.keys(PANEL).filter(id => !term(PANEL[id])).map(id => id + '→' + PANEL[id])
        .concat(Object.keys(HEAD).filter(id => !term(HEAD[id])).map(id => id + '→' + HEAD[id]))
    };
    out.clean = !out.panelsWithoutTerm.length && !out.entriesWithoutPanel.length && !out.unresolvedTerms.length;
    return out;
  }
  DWDASH.glossaryAudit = audit;
  setTimeout(() => { const a = audit(); if (!a.clean) console.warn('deckwave glossary: map out of step', a); }, 0);

  function tag() {
    Object.keys(HEAD).forEach(id => {
      const b = sr.getElementById(id); if (!b) return;
      const u = b.closest('.kv') && b.closest('.kv').querySelector('u');
      if (u) u.dataset.gl = HEAD[id];
    });
    dash.slots.slots.forEach(s => {
      const l = s.el.querySelector('.lbl');
      if (!l) return;
      /* Clearing matters as much as setting. A panel with no glossary entry
         used to leave whatever the last panel put there, so swapping to an
         untermed panel showed the previous panel's topic. */
      if (PANEL[s.panel]) l.dataset.gl = PANEL[s.panel];
      else delete l.dataset.gl;
    });
    const np = sr.getElementById('npBox');
    if (np) { const order = ['bpm','key','stretch','energy'];
      np.querySelectorAll('.grid u').forEach((u, i) => {
        if (order[i]) u.dataset.gl = order[i]; }); }
    return bind();
  }

  /* re-tag after every rebuild — this is the part that was missing twice */
  const origBuild = dash.slots.build, origReset = dash.slots.reset;
  dash.slots.build = function (d) { const r = origBuild.call(dash.slots, d);
    setTimeout(tag, 60); return r; };
  dash.slots.reset = function (d) { const r = origReset.call(dash.slots, d);
    setTimeout(tag, 80); return r; };

  tag();
  return { tag, bind, show };
};
