/* ─────────────────────────────────────────────────────────────────────────
   DECKWAVE · PHONE PLAYBACK — keeping a set alive when the screen goes dark

   Keeper, 2026-08-19: "What unlocks background play? Spotify gets it."

   Spotify gets it because it is a native app with the `audio` background
   mode: the OS keeps its audio session alive with the screen locked. A web
   page gets a smaller version of the same grant, and only for ONE thing:
   an HTMLMediaElement that is playing. WebKit (every browser on iOS) keeps
   <audio> going on the lock screen and SUSPENDS a Web Audio graph; Chrome
   for Android keeps Web Audio running with the screen off on its own,
   subject to the OS battery setting for Chrome.

   Deckwave's mix IS a Web Audio graph, so on iOS it stops at lock. Two ways
   to keep it going, both here, both OFF by default, neither heard:

     wake    keep the screen on while a set plays (Screen Wake Lock API —
             Safari 16.4+, Chrome 84+). The mechanism is real and boring:
             nothing suspends because nothing locks. Costs battery. The
             honest fallback.

     media   route the whole mix through createMediaStreamDestination into
             an <audio> element and let THAT be the thing playing, with
             Media Session metadata and lock-screen buttons. Whether WebKit
             then keeps the graph feeding the element alive with the screen
             locked is NOT established — it is the question, and this is
             the experiment. Nothing in the signal path changes; only which
             sink hears it (DW.outputStream). On Chromium it is harmless.

   Both give Media Session metadata (track, artist) and next/previous/pause
   handlers on the lock screen where the browser has one.

   STATE THE FALSIFIER: lock the phone with `media` on and a set playing.
   If the music continues for the length of a handover (a new title on the
   lock screen), the graph survived. If it stops within a few seconds, it
   did not, and `wake` is the answer on iOS.
   ───────────────────────────────────────────────────────────────────────── */

window.DWPHONE = (function () {
'use strict';

const MODES = ['off', 'wake', 'media'];
let mode = 'off', wakeLock = null, audioEl = null, lastTitle = null, tick = null;
try { const s = localStorage.getItem('dw-phone'); if (MODES.includes(s)) mode = s; } catch (e) {}

const cap = {
  get wakeLock() { return !!(navigator.wakeLock && navigator.wakeLock.request); },
  get mediaSession() { return 'mediaSession' in navigator && typeof window.MediaMetadata === 'function'; }
};

/* ── wake ────────────────────────────────────────────────────────────── */
async function holdWake() {
  if (!cap.wakeLock || wakeLock) return;
  try {
    wakeLock = await navigator.wakeLock.request('screen');
    wakeLock.addEventListener('release', () => { wakeLock = null; });
  } catch (e) { wakeLock = null; }     /* refused (low battery mode, not visible) — nothing to do */
}
function dropWake() { if (wakeLock) { try { wakeLock.release(); } catch (e) {} wakeLock = null; } }
/* ── holds that are not about playback ─────────────────────────────────
   A SCAN cannot progress with the screen off (the page is paused), and the
   keeper lost a 189-track analysis to force-of-habit locking. So any caller
   with long work can hold the screen awake for its duration, whatever the
   phone mode is set to — this is the one case where the lock is taken
   without asking, because the user pressed the button that needs it. */
const holds = new Set();
function hold(tag) { holds.add(tag); holdWake(); }
function release(tag) { holds.delete(tag); if (!holds.size && !(mode === 'wake' && playing())) dropWake(); }

/* a wake lock is released by the browser when the page is hidden; take it
   again when the page comes back, if a set is still playing or work is held */
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && (holds.size || (mode === 'wake' && playing()))) holdWake();
});

/* ── media ───────────────────────────────────────────────────────────── */
function ensureAudio() {
  if (audioEl) return audioEl;
  audioEl = document.createElement('audio');
  audioEl.setAttribute('playsinline', ''); audioEl.playsInline = true;
  audioEl.autoplay = true; audioEl.controls = false; audioEl.style.display = 'none';
  document.body.appendChild(audioEl);
  return audioEl;
}
async function routeToMedia(on) {
  if (!window.DW) return;
  if (on) {
    const stream = await window.DW.outputStream(true);
    const a = ensureAudio();
    if (a.srcObject !== stream) a.srcObject = stream;
    try { await a.play(); } catch (e) { /* needs a gesture — the tap handler below retries */ }
  } else {
    await window.DW.outputStream(false);
    if (audioEl) { try { audioEl.pause(); } catch (e) {} audioEl.srcObject = null; }
  }
}
/* a media element may only start inside a user gesture; any tap on the page
   while `media` is on starts it if it is not running — the same unlock idiom
   Web Audio itself needs on phones */
const kick = () => { if (mode === 'media' && audioEl && audioEl.paused && audioEl.srcObject) audioEl.play().catch(() => {}); };
document.addEventListener('touchend', kick, true);
document.addEventListener('click', kick, true);

/* ── media session: title on the lock screen, buttons that do things ──── */
function playing() { return !!(window.DW && window.DW.state && window.DW.state.now); }
function clean(n) { return String(n || '').replace(/^[^-]+-\s*/, '').replace(/^[^-]+-\s*/, '').replace(/^\d+\s*/, '') || String(n || ''); }
function updateSession() {
  if (!cap.mediaSession) return;
  const m = window.DW && window.DW.nowMeta;
  const title = m ? m.name : null;
  if (title === lastTitle) return;
  lastTitle = title;
  try {
    navigator.mediaSession.metadata = m ? new MediaMetadata({
      title: clean(m.name).slice(0, 80),
      artist: String(m.name).split(' - ')[0].slice(0, 60),
      album: 'Deckwave · ' + Math.round(m.bpm) + ' bpm · ' + (m.camelot || '')
    }) : null;
    navigator.mediaSession.playbackState = m ? 'playing' : 'none';
  } catch (e) {}
}
function bindSession() {
  if (!cap.mediaSession) return;
  const set = (k, fn) => { try { navigator.mediaSession.setActionHandler(k, fn); } catch (e) {} };
  set('play',  () => { if (window.DW && window.DW.state.ctx === 'suspended') window.DW.pause(); });
  set('pause', () => { if (window.DW && window.DW.state.ctx === 'running') window.DW.pause(); });
  set('nexttrack', () => { if (window.DW) window.DW.skip(); });
  set('previoustrack', () => { if (window.DW) window.DW.back(); });
}

/* ── the mode ────────────────────────────────────────────────────────── */
async function apply() {
  if (mode === 'wake') { await routeToMedia(false); if (playing()) holdWake(); }
  else if (mode === 'media') { if (!holds.size) dropWake(); await routeToMedia(true); }
  else { if (!holds.size) dropWake(); await routeToMedia(false); }
  if (mode !== 'off') { bindSession(); updateSession(); }
  if (tick) clearInterval(tick);
  tick = mode === 'off' ? null : setInterval(() => {
    updateSession();
    if (mode === 'wake') { if (playing()) holdWake(); else if (!holds.size) dropWake(); }
  }, 1000);
}

return {
  MODES, cap, hold, release,
  get mode() { return mode; },
  async set(m) {
    if (!MODES.includes(m)) throw new Error('phone mode: ' + MODES.join(' | '));
    mode = m;
    try { localStorage.setItem('dw-phone', m); } catch (e) {}
    await apply();
    return mode;
  },
  /* what is actually in effect right now — for the log line and a bug report */
  get status() {
    return { mode, wakeLockHeld: !!wakeLock, wakeLockAvailable: cap.wakeLock, holds: [...holds],
             mediaSession: cap.mediaSession,
             output: window.DW ? window.DW.outputVia : null,
             audioElement: audioEl ? (audioEl.paused ? 'paused' : 'playing') : 'none' };
  }
};
})();
