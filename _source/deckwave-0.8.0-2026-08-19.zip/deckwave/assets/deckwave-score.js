/* ─────────────────────────────────────────────────────────────────────────
   DECKWAVE · SCORE
   A mix expressed as executable data rather than rendered audio.

   The premise: nothing about the mix is improvised. The sequence comes from
   measured features, the entry points from beat grids, the tempo multipliers
   from arithmetic. "Live" is only when it runs. So the mix is not a recording
   to capture — it is a score, and a score can be written down.

   Roughly 26KB describes a 197-minute set. The FLAC would be 3GB and would
   preserve only the sound. This preserves the HOW.

   DETERMINISM — read this before quoting the claim.
   Reproducibility depends on identical Essentia/WASM builds, identical decode
   paths, and stable analysis across browser versions. This is the same problem
   tracker modules have always had: no normative spec means the same file can
   sound different in different players. The engine block MITIGATES that by
   declaring what produced the mix. It does not eliminate it, and cross-browser
   determinism has NOT been tested. State the claim with that attached.
   ───────────────────────────────────────────────────────────────────────── */

window.DWSCORE = (function () {
'use strict';

/* every 4th beat, assumed — there is no downbeat detection here (see WISDOM) */
function downbeatNear(beats, t) {
  let best = t, d = Infinity;
  for (let i = 0; i < beats.length; i += 4) {
    const dd = Math.abs(beats[i] - t);
    if (dd < d) { d = dd; best = beats[i]; }
  }
  return best;
}

/* Walk the set exactly as the player will, recording every decision.

   THIS HAS TO MODEL THE PLAYER AS IT IS, NOT AS IT WAS. Until 2026-08-19 it
   stretched every track by tempo/bpm — the pre-0.7.0 player. The player now
   plays an UNLOCKED track straight (rate 1, entry at 0, exit on the clock),
   and the two straight modes move the rolling target differently: a 'reach'
   track repositions it to its own BPM, a 'grid' track moves it nowhere. A
   stepping stone carries `_dwell` and plays for that instead of its length.
   None of that was here, so the score and the cue sheet printed a stretch
   — 28% against WHEN AN ANGEL DIES — for tracks the deck never stretches.
   That is the exact claim CLAUDE.md forbids: a stretch figure against an
   unmatched track describes an event that does not happen.

   The dwell floor is read from the engine so the number lives in one place;
   45 is the fallback for a score built without the engine loaded. */
function plan(set, opts) {
  opts = opts || {};
  const XF = opts.xfade || 16, drift = opts.drift || 0.35;
  const floor = (window.DW && window.DW.dwellFloor) || 45;
  const out = [];
  let tempo = set[0].bpm, clock = 0;

  set.forEach((m, i) => {
    const straight = !!m._unlocked;
    const rate = (i === 0 || straight) ? 1 : tempo / m.bpm;
    const entry = straight ? 0 : ((m.beats || [0])[0] || 0);
    const k = 1 / rate;
    const beats = (m.beats || []).map(b => (b - entry) * k);
    const natural = ((m.dur - entry) * k) - XF;
    const playFor = m._dwell ? Math.max(floor, Math.min(m._dwell, natural)) : Math.max(floor, natural);
    const exit = (beats.length && !straight) ? downbeatNear(beats, playFor) : playFor;

    out.push({
      i, name: m.name,
      bpm: +m.bpm.toFixed(2), camelot: m.camelot, key: m.key + ' ' + m.scale,
      energy: m.energy, conf: m.conf,
      /* `straight` is the reason a track is not beatmatched — 'grid' (its
         beats disagree with its tempo label) or 'reach' (the set could not
         stretch to it) — or null for a locked, beatmatched track. stretchPct
         is NULL rather than 0 for a straight track: 0 reads as "the best
         transition in the set" and it is not a transition of that kind. */
      straight: straight ? (m._unlockReason || 'grid') : null,
      rate: +rate.toFixed(4),
      stretchPct: straight ? null : +((rate - 1) * 100).toFixed(2),
      entrySec: +entry.toFixed(3), exitSec: +exit.toFixed(3),
      dwellSec: m._dwell ? +Math.max(floor, m._dwell) : null,
      atSec: +clock.toFixed(2),
      xfadeSec: XF, bassSwapSec: +(XF * 0.45).toFixed(2),
      durSec: m.dur
    });
    clock += exit;
    /* the same three-way move chain() makes after it schedules a deck */
    if (!straight) tempo += (m.bpm - tempo) * drift;
    else if (m._unlockReason === 'reach') tempo = m.bpm;
  });
  return out;
}

function score(set, opts) {
  opts = opts || {};
  const steps = plan(set, opts);
  const last = steps[steps.length - 1];
  const total = last.atSec + last.exitSec + (opts.xfade || 16);
  return {
    format: 'deckwave-set', version: 1,
    generated: new Date().toISOString(),
    engine: {
      sequencer: 'rolling-tempo target, camelot + energy arc, hard stretch gate; ' +
                 'a track the gate cannot reach, or whose grid disagrees with its tempo, plays STRAIGHT',
      drift: opts.drift || 0.35,
      xfadeSec: opts.xfade || 16,
      maxStretch: opts.maxStretch || 0.08,
      maxGridErrPct: (window.DW && window.DW.lock) ? window.DW.lock.maxGridErrPct : null,
      detector: 'essentia.js RhythmExtractor2013 multifeature, whole track (key/rms: centred 120s excerpt)',
      keyDetector: 'essentia.js KeyExtractor',
      stretch: 'SoundTouchJS AudioWorklet 2.1.1 — source playbackRate = rate, worklet restores pitch',
      transition: 'downbeat-aligned crossfade with 3-band bass swap; straight tracks crossfade on the clock, unaligned',
      downbeat: 'assumed every 4th beat from first — no downbeat detection',
      determinism: 'depends on identical engine builds; NOT cross-browser tested'
    },
    summary: {
      tracks: steps.length, runtimeSec: Math.round(total),
      tempoStart: steps[0].bpm, tempoEnd: last.bpm,
      /* LOCKED tracks only. A straight track is not stretched because it is
         not being beatmatched — folding its 0 in would pull the figure toward
         "everything is fine", which is a different fact. */
      straight: steps.filter(s => s.straight).length,
      maxStretchPct: +Math.max(0, ...steps.filter(s => s.stretchPct != null)
                                          .map(s => Math.abs(s.stretchPct))).toFixed(2)
    },
    steps
  };
}

/* Standard .cue — opens in VLC, foobar2000, most players. */
function cue(sc, title) {
  const t = s => {
    const m = Math.floor(s / 60), ss = Math.floor(s % 60), f = Math.round((s % 1) * 75);
    return [m, ss, f].map(x => String(x).padStart(2, '0')).join(':');
  };
  let o = 'REM DECKWAVE SET — ' + sc.summary.tracks + ' tracks, ' +
          Math.round(sc.summary.runtimeSec / 60) + ' min\n';
  o += 'REM ENGINE ' + sc.engine.detector + ' / ' + sc.engine.stretch + '\n';
  o += 'REM GENERATED ' + sc.generated + '\n';
  o += 'TITLE "' + (title || 'Deckwave Set') + '"\nFILE "mix.flac" WAVE\n';
  sc.steps.forEach((s, i) => {
    o += '  TRACK ' + String(i + 1).padStart(2, '0') + ' AUDIO\n';
    o += '    TITLE "' + s.name.replace(/"/g, "'") + '"\n';
    /* never a percentage against a straight track — see plan() */
    o += '    REM BPM ' + s.bpm + ' KEY ' + s.camelot +
         (s.straight ? ' STRAIGHT ' + s.straight + ' (no beatmatch)'
                     : ' RATE ' + s.rate + ' STRETCH ' + s.stretchPct + '%') + '\n';
    o += '    INDEX 01 ' + t(s.atSec) + '\n';
  });
  return o;
}

/* Rebuild a set from a score. Reports what it could not find rather than
   silently dropping it — a short set that looks complete is worse than a
   short set that says why. */
function load(json, corpus) {
  const sc = typeof json === 'string' ? JSON.parse(json) : json;
  if (sc.format !== 'deckwave-set') throw new Error('not a deckwave set file');
  const nm = s => s.toLowerCase().replace(/[^a-z0-9]/g, '');
  const set = [], missing = [];
  sc.steps.forEach(s => {
    const m = corpus.find(t => nm(t.name) === nm(s.name));
    if (!m) { missing.push(s.name); return; }
    m._stretch = s.rate;
    /* Put the classification back, or a straight track loads as a locked
       one and chain() stretches it by tempo/bpm — for a track whose label
       and grid disagree by 28% that is a 28% stretch nobody chose. Scores
       written before `straight` existed carry no field; those sets were
       built when everything was beatmatched and are left as they were, which
       is the same `_locked === undefined` policy resequenceTail() uses. */
    if ('straight' in s) {
      if (s.straight) { m._unlocked = true; m._unlockReason = s.straight; m._locked = s.straight === 'reach'; }
      else { delete m._unlocked; delete m._unlockReason; m._locked = true; }
    }
    if (s.dwellSec) m._dwell = s.dwellSec; else delete m._dwell;
    set.push(m);
  });
  return { loaded: set.length, missing, set, score: sc };
}

return { plan, score, cue, load, downbeatNear };
})();
