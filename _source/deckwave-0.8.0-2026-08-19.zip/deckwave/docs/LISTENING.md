# Deckwave — the listening plan

Seven things are built, measured and **unheard**. Each one below names the
exact tracks, what to do, and — the part that matters — **what answer changes
what**. Test 0 is the one to run first: it covers two of the others at once.

Written down rather than left in a conversation, because a finding that lives
only in chat is lost at the next compaction, and that has already cost this
project a session (ledger 30).

**Derived from** `evidence/rescan-2026-08-18-measurements.json` — the v2 grids,
2026-08-18. Track tempos below are what the live corpus holds. If the library
is re-scanned these numbers move and this file needs regenerating.

**Nothing here is a threshold I will move on my own.** Every one of these is a
number chosen or derived and then left alone, waiting for an ear.

---

## 0 · The walk: WALKMAN → LIKE A DEAD PIXELS

**The keeper's own route, and the best single test here** — it exercises the
stepping stones and a straight transition back to back, and it is also the
build-video set piece.

Start on **WALKMAN** (128 bpm, 7A). Click **TAKE CONTROL** and choose
**⚡ blend fast**. Five stones, 3.8 minutes:

> Eighty-five 120 → NIGHTWALKING 116 → Keygen 115 → Raster Bar 111 →
> Copyparty Memories 109 → **TAKE CONTROL 107**

Then click **LIKE A DEAD PIXELS** and choose **∿ bring it in now · no stretch**.

**Why this pair and not another.** LIKE A DEAD PIXELS is labelled **92 bpm**
and its beats are actually spaced at **106.6**. The route lands the set at
**107**. Played straight it therefore arrives **0.0% away in real pulse** —
against 16.1% out if anything had trusted the 92. It should land on the beat
by arithmetic, with nothing claiming to beatmatch it.

Direct from 128 to 107 needs 20.1% against an 8% gate, so the stones are doing
real work rather than decorating.

**Answers two questions at once:** do the 45-second stones get a fair hearing
(test 3), and does a straight transition sound like a DJ choice (test 1). If
this one lands, both are probably fine. If the stones feel rushed but the
landing is clean, that separates them.

---

## 1 · A track played straight — the biggest unknown

Five tracks are no longer beatmatched at all. Their beat grid disagrees with
their own tempo label by more than 9%, so the engine plays them at their own
speed with a plain crossfade and no beat alignment.

**Nobody has heard one.** This is the single largest unheard change.

| track | grid is off by | declared | the beats actually say |
|---|---|---|---|
| **WHEN AN ANGEL DIES** (DEAD PIXELS 05) | 28.3% | 151 | **~108** |
| **LIKE A DEAD PIXELS** (DEAD PIXELS 08) | 16.0% | 92 | ~107 |
| **HEAVEN** (GHOSTS 11) | 13.9% | 172 | ~148 |
| **TETRA TENNIS** (BETTER THAN REALITY 10) | 13.3% | 80 | ~90 |
| **Timeless** (single) | 11.0% | 85 | ~94 |

**How.** Click any of them in the set list. The menu now says *plays straight*
and offers **∿ bring it in now · no stretch** — it no longer quotes a stretch
percentage, because none is applied. Pick that.

**Best approach tracks** (already near where the grid really sits, so the
transition is the fairest test):

- **WHEN AN ANGEL DIES** ← from *Cyberpunx* or *Magic Gateway* (both 108)
- **LIKE A DEAD PIXELS** ← from *TAKE CONTROL* or *Neon Thrills* (107)
- **HEAVEN** ← from *COMPUTER DATE* or *The Other Side* (150)
- **TETRA TENNIS** ← from *WE ARE FOREVER* or *PERPETUAL MOTION* (90)
- **Timeless** ← from *Cyberiad Theory* or *Code Veronica* (94)

**What to listen for.** Does it read as a DJ choice — a record dropped in
clean — or as a mistake? The bass swap still happens; only the beat alignment
is absent.

**What the answer changes.**

- *"Sounds fine"* → the design holds, and the 3% cut in test 2 becomes worth
  trying, since more tracks going straight costs less than feared.
- *"Sounds like a mistake"* → straight transitions need their own treatment —
  a longer fade, or a fade to silence and in again, rather than a crossfade
  that half-implies a mix.

**A separate observation worth your ear:** *WHEN AN ANGEL DIES* is labelled 151
but its beats are spaced at 108. That is not a small error; one of the two
numbers is simply wrong. Tapping along will say which.

---

## 2 · The 9% cut, against the other defensible answer

`DW.lock.maxGridErrPct` is **9**, and it is the first threshold in this project
derived rather than chosen: the distribution over 179 tracks has an empty band
between 7.50% and 11.04%, and every cut inside it selects the identical five
tracks above.

The other defensible answer is about **3%**, on the argument that grid error
adds to the stretch budget and we already refuse 8% of stretch because it
wobbles. That plays **22 tracks straight instead of 5**.

**How.** In the console: `DW.lock.maxGridErrPct = 3`, then **build set** again.
No reload. Set it back to 9 the same way.

**The seventeen that move**, worst first:

`R3B0RN` 7.5% · `8BIT FAIRY TALE` 7.1% · `BEGINNING OF ANXIETY` 7.0% ·
`CLONED` 6.4% · `WE ARE FOREVER` 6.4% · `PROXIMA` 6.4% · `MIDNIGHT LIGHTS` 5.9% ·
`POISON` 5.7% · `ANOTHER WORLD` 5.2% · `Falling Down` 5.0% · `WINTER ERROR` 4.6% ·
`GONE TOO SOON` 4.5% · `FINAL CHAPTER` 3.9% · `65536` 3.7% · `PRELUDE` 3.5% ·
`GHOSTS` 3.2% · `HI-LAND COO` 3.1%

**What to listen for.** At 9%, those seventeen are being beatmatched with up to
7.5% of grid error on top of up to 8% of stretch. Do their transitions drift?
A drifting beatmatch is a specific sound — the kick doubles and separates
rather than staying one kick.

**What the answer changes.** If they drift, the cut comes down and the library
gets more honest and less mixed. If they hold, 9 stands and possibly higher.

---

## 3 · Stepping stone length — D7, 45s against 40s

Every stone on a fast route plays **45 seconds**. Patch 10 asked for 40;
`chain()` clamps to `MIN_PLAY`. Both numbers were typed, neither measured.

**Three real routes**, computed against the live tempos. Start the set, let it
settle near the starting tempo, then click the destination and choose
**⚡ blend fast**.

**From ~130 bpm → TAKE CONTROL (107).** Direct would need 21.9%; the gate is 8%.
Six stones, 4.5 minutes:

> BETTER THAN REALITY 125 → Eighty-five 120 → WE COME TOGETHER 116 →
> Keygen 115 → Raster Bar 111 → Copyparty Memories 109 → **TAKE CONTROL 107**

**From ~110 bpm → PERPETUAL MOTION (90).** Direct 22.2%. Six stones:

> Pixel Crush 102 → STARGAZE 100 → Fading 98 → Alive 96 → Code Veronica 94 →
> DIGITAL HEART 92 → **PERPETUAL MOTION 90**

**From ~150 bpm → TONIGHT (124).** Direct 21.1%. Six stones:

> HI-LAND COO 140 → PIXEL MY HEART 137 → CHINA 138 → UNDER YOUR SKIN 132 →
> ACIDJAZZED EVENING 128 → ALIEN 128 → **TONIGHT 124**

**What to listen for.** Did each stone get a fair hearing, or did one get cut
while it was still building?

**What the answer changes.** *Rushed* → the floor goes **up**, 40 is dead
without testing, and patch 10's saving claim shrinks again. *Fine or slow* →
40 is worth hearing and I wire a live setter so you can A/B it.

Note the second route passes through **STARGAZE**, one of the ten the old
confidence gate had excluded — it is only reachable at all because of that
change.

---

## 4 · `settle` — riding a bad blend back to normal speed

Off by default. **settle after a bad blend** in the transport.

**How.** Two forced blends, same pair, toggle between them. Real pairs at
+11%, comfortably outside the 8% gate and short of the 15% wobble limit:

- play **HI-LAND COO** (140) → force **ANOTHER WORLD** (126)
- play **Overdrive** (141) → force **DIGITAL MEMORIES** (127)
- play **DOOMSDAY** (140) → force **ANOTHER WORLD** (126)
- play **HALF SAVAGE** (89) → force **DROWNING** (100)

With settle **off**, the incoming track stays 11% wrong for its whole length.
With it **on**, it rides back to its own speed over 45 seconds.

**Two questions, and they must be answered separately.**

1. *Does the ride sound musical, or does it sound like tape slowing down?*
   45 seconds is a chosen number.
2. *Does the SET get better or worse afterwards?* A settled deck hands over at
   its own BPM instead of the 35%-drift target, so every gate test downstream
   is measured from somewhere else. Ladders get tighter and shorter.

**What the answer changes.** Yes to 1 and no to 2 is a real outcome and has a
fix: settle within the track and restore the drift target at handover. More
machinery, but the option exists.

---

## 5 · The reach jumps — abrupt by design

Four tracks in a full build are reached by playing them straight because the
stretch gate could not get there. Observed on the test build:

| from | to | track |
|---|---|---|
| 140 | **172** | CLONED |
| 167 | **100** | DROWNING |
| 109 | **85** | PAPER DOLL |
| 91 | **81** | Galaxy |

The set repositions to the new tempo and carries on mixing from there.

**How.** Build a set and look for the rows with a dashed left edge and a `∿`
before the BPM. Listen to the transition **into** each.

**What to listen for.** 167 → 100 is a hard reset. Honest — nothing claims to
be beatmatched — but is it a floor-clearer?

**Read before listening, added 2026-08-19.** Until that day this test could
not have been heard as designed: the planner re-based the set to the reach
track's tempo and the DECK did not (ledger 49), so the track AFTER the jump
would have been chained at the old target over its bpm — ×1.67 after
167 → 100 — and the sound you would have blamed on the reach jump was a
different defect one track later. Fixed and measured on a synthetic corpus;
if the transition INTO the reach track lands but the one OUT of it sounds
wrong, that is the thing to report.

**What the answer changes.** If they land badly, the fix is routing to them
with stepping stones instead of jumping, which smooths the tempo across
several tracks. That option was offered and declined; it is still available.

---

## 6 · The three tracks that came back at double tempo

The whole-track rescan flipped three grids to double, and all three still pass
every gate — so they enter a set at double tempo, chosen as neighbours for a
tempo they do not have.

| track | was | now |
|---|---|---|
| **Perpetual Motion** (CyberChip 01) | 93.99 | **184.57** |
| **PROXIMA** (BETTER THAN REALITY 06) | 90.01 | **178.21** |
| **Galaxy** (single) | 80.87 | **162.09** |

**How.** Jump to each and count. The transition monitor draws both grids, so
this can be watched as well as heard.

**What to listen for.** Is the pulse the engine is locked to the pulse you
would tap?

**What the answer changes.** This is a per-track correction, not a threshold —
if they are wrong, those three get pinned back to half and nothing else in the
corpus moves.

---

## Heard — the keeper's reports, as they arrive

**2026-08-19 · best matches · Moments → Alive → FINAL CHAPTER → ROCK 64.**
Keeper: *"'Final Chapter' to 'Rock 64' was an interesting transition visually
… the whole moments→alive→final chapter→rock 64 is hot. Nice mix."* Screenshot
taken for the build video. On the v1 figures that is a 96 → 95 → 95.6 → 96.5
bpm run (every stretch well inside the gate) and 10A → 5A → 7A → 7A in key;
Moments and Alive are both collaborations (Caspro, Waveshaper), FINAL CHAPTER
→ ROCK 64 are album neighbours on DEAD PIXELS in the same key. **[CONFIRMED]**
by ear, on the `build · best matches` build — the first listening report on
that mode, and on FINAL CHAPTER, which LISTENING §2 lists among the
seventeen tracks a 3% cut would play straight (grid error 3.9%); at 9% it is
beatmatched, and it was heard beatmatched and liked. One report, one run.

**2026-08-19 · the phone.** iPhone 16 Pro Max, iOS 26.6: the whole library
scanned on the device and a set PLAYED — keeper: *"OMG THE PHONE PLAYS."* The
first time the deck has run on WebKit. Which of §0–§6 it was is not yet
reported; the phone tests proper (the straight transitions, the 9%-vs-3% cut,
the lock-screen experiment) are still to come, now that they can.

## Standing

**If popping through a mix returns on other material, say so and D5 reopens.**
It is currently closed as a misattribution on one report and one pair of
tracks, which is thin evidence for a conclusion that large.
