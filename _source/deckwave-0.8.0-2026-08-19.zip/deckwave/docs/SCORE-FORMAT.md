# The Deckwave Score Format

A DJ set described as executable data rather than rendered audio.

## Why this exists

Existing DJ interchange formats — rekordbox XML, Traktor NML, Serato crates, the `.cue` tradition — capture **track order and cue points**. None of them capture the *transition*: the crossfade curve, the EQ automation, the time-stretch ratio, the parameters of the engine that produced them.

The nearest prior art is DJ.Studio's proprietary `.DJS` project format, which does capture transitions and exports deterministically to Ableton. This format differs in being open, compact, and carrying an **engine block** so a conforming player can reproduce the mix rather than merely describe it.

## The determinism claim, stated honestly

A score plus the same source files should reproduce the same mix. That depends on identical Essentia/WASM builds, identical decode paths, and stable analysis across browser versions.

This is exactly the problem tracker modules have always had: without a normative playback spec, the same file sounds different in different players. The engine block **mitigates** that by declaring what produced the mix. It does not eliminate it.

**Cross-browser determinism has not been tested.** Treat reproducibility as an intent with a declared dependency, not a guarantee, until someone measures it.

## Shape

```json
{
  "format": "deckwave-set",
  "version": 1,
  "generated": "2026-08-17T02:49:56.242Z",
  "engine": {
    "sequencer": "rolling-tempo target, camelot + energy arc, hard stretch gate",
    "drift": 0.35,
    "xfadeSec": 16,
    "maxStretch": 0.08,
    "detector": "essentia.js RhythmExtractor2013 multifeature",
    "keyDetector": "essentia.js KeyExtractor",
    "stretch": "SoundTouchJS AudioWorklet 2.1.1 — source playbackRate = rate, worklet restores pitch",
    "transition": "downbeat-aligned crossfade with 3-band bass swap",
    "downbeat": "assumed every 4th beat from first — no downbeat detection",
    "determinism": "depends on identical engine builds; NOT cross-browser tested"
  },
  "summary": {
    "tracks": 99, "runtimeSec": 11815,
    "tempoStart": 100.14, "tempoEnd": 150.48,
    "straight": 5, "maxStretchPct": 7.77
  },
  "steps": [ ... ]
}
```

### A step

| Field | Meaning |
|---|---|
| `i` | position in the set |
| `name` | filename stem, used to re-resolve against a library |
| `bpm` | measured native tempo |
| `camelot` | key in Camelot notation (e.g. `8A`) |
| `key` | key and scale as detected (e.g. `C minor`) |
| `energy` | composite index — **constructed, not measured** (see below) |
| `conf` | detector confidence, Essentia scale 0–5.32 |
| `straight` | **added 2026-08-19.** `null` for a beatmatched track; `"grid"` when its beat grid disagrees with its tempo label by more than `engine.maxGridErrPct`, `"reach"` when the set could not stretch to it. A straight track plays at its own speed from `0`, crossfades on the clock with no beat alignment, and — if `"reach"` — repositions the rolling tempo to its own BPM |
| `rate` | tempo multiplier applied at playback. `1` for a straight track |
| `stretchPct` | the same as a percentage, for humans. **`null` for a straight track** — not `0`, because `0` reads as the best transition in the set and a straight track is not a transition of that kind |
| `entrySec` | seek offset — the track's first detected beat, or `0` for a straight track |
| `exitSec` | when to begin the outgoing fade, snapped to a downbeat (straight: on the clock) |
| `dwellSec` | **added 2026-08-19.** Only on a stepping stone of a committed fast route: how long it plays before the next blend, after the engine floor is applied. `null` otherwise |
| `atSec` | position in the finished mix |
| `xfadeSec` | crossfade length |
| `bassSwapSec` | when the outgoing low shelf drops |
| `durSec` | full track duration |

## Reading it honestly

**`conf` is on Essentia's scale (0–5.32), where 1.5–3.5 is moderately confident.** It is not comparable to any other detector's confidence number. Presenting it against a different algorithm's figure as a before-and-after would be misleading.

**`energy` is a constructed index**, not a measurement: 45% loudness, 25% brightness, 30% tempo, normalised across the corpus. It correlates with what a listener would call energy. It is not the same thing, and the weights were chosen rather than fitted.

**`stretchPct` past ±15% will audibly wobble.** That is a perceptual limit, not a style preference. The sequencer gates at 8% for that reason.

**`summary.maxStretchPct` is over beatmatched tracks only.** A straight track is unstretched because it is not being beatmatched; folding its zero in would pull the figure toward "everything is fine", which is a different fact. `summary.straight` counts them.

## Loading

`DWSCORE.load()` resolves steps against the corpus by normalised name and restores `straight` (as the engine's `_unlocked` / `_unlockReason`) and `dwellSec` onto the matched records, so a loaded straight track is still played straight. A score written before these fields existed loads unchanged: those sets were built when everything was beatmatched, and the loader leaves their classification alone rather than inventing one.

## Companion cue sheet

A standard `.cue` is emitted alongside, with BPM, key and stretch as REM lines — `STRAIGHT grid|reach (no beatmatch)` in place of a stretch for a straight track. It opens in VLC and foobar2000 and gives track navigation over a rendered mix.

## Version

Still `"version": 1`. The 2026-08-19 fields are additive: a reader of the old shape sees extra keys and nothing missing. The first change that removes or re-types a field bumps the version — ROADMAP "the score format has to grow" still stands.
