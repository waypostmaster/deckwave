# Launch — 2026-08-24, GitHub, no later

Keeper, 2026-08-19: *"The launch date for the software will be 8/24, goes on
Github no later than that."* Eight bars of four: the date lands on the phrase
boundary the engine still cannot detect (ROADMAP, "What none of this fixes"),
which is either a joke or a promise. Recorded here so it is neither lost nor
argued with.

**The push is the launch act and it is the keeper's to make.** Nothing below
creates a remote or pushes; it gets the tree to where that one command is
safe. The rule in CLAUDE.md stands until that day: *do not create one or push
without being asked.*

## What publishing means here, in this order

1. **Copyright and date.** The first public commit is the defensive
   publication the four IP reviews recommend (`docs/research/README.md`). Tag
   it (`v0.8.0` or whatever VERSION says that morning), and — since the
   Waypost tooling already exists — an OpenTimestamps proof of the tag hash
   makes the date independent of GitHub. Cheap, and it is what the
   symmetric-trust research said to do.
2. **Licence.** AGPL-3.0 because of Essentia (`NOTICE`, `LICENSE` — the full
   text is already there). Every vendored library is pinned with its licence
   in `vendor/`. Nothing to add; something to not break.
3. **Name.** Deckwave, as is. The keeper's read on the Innisfil registration
   is in the research index; DekWave (Seattle) remains as the report wrote it.

## Decide before the push — things that are tracked today

| What | Where | Decision needed |
|---|---|---|
| **Private research** — patent strategy, provisional draft, finances, corporation, grants | `docs/research/*` marked *private* in its README (8 files) | Keep out of the public tree. Move to a private location or a private branch; leave the index with a one-line note that they exist. **Not done — the keeper's call.** |
| **Adjacent research** — persona/Waypost project | `docs/research/adjacent/` (8 files) | Not Deckwave's to publish. Same treatment, or keep if the keeper wants the whole record public. |
| **`_source/`** — three old packages, a corpus cache, live snapshots (3.4 MB) | tracked | Restore points, not source. Either keep as history or drop from the public tree with `git rm --cached` (the zips are rebuildable by `package.py`). The corpus cache lists the keeper's library by filename — harmless, personal. |
| **`evidence/`** — the v1 cache and the rescan measurements | tracked, **cannot be regenerated** (CLAUDE.md) | Keep. It is what the BUILD-LOG's numbers rest on. Same filename note as above. |
| `.claude/settings.local.json` | **untracked** (good) — carries local permission grants | Keep untracked. `.claude/launch.json` is tracked and fine. |
| `tools/check-*.js` | tracked | Fine, but `check-flac.js` and `check-route.js` read `C:/Claude/Music/LukHash` by default and skip/fall back without it — say so in README so a stranger's first run is not a confusing FAIL. |
| Git identity | commits are authored as `Deckwave` | Fine. |
| TLS keys | outside the repo by design; `.gitignore` catches strays | Fine. |

## The tree itself

- `README.md` — version line, what it is, how to run (`python tools/serve.py`),
  browser support as it now stands (Chromium full; Firefox/Safari/iOS via file
  inputs), the limits list, and the AGPL line. **Add the screenshot** the
  keeper took of FINAL CHAPTER → ROCK 64 if it reads well small.
- `CHANGELOG.md` — a `0.8.0 — 2026-08-24 · public` entry at the top that says
  what this release is, in two paragraphs, and points at LISTENING.md for what
  is and is not heard.
- `SKILL.md` — the description line is what an agent sees first; it is current.
- `CLAUDE.md` — stays. It is the working agreement and it is honest; a
  stranger reading it learns more about how this was built than from anything
  else in the tree. The "Publishing" bullet gets flipped to past tense.
- `docs/BUILD-LOG.md`, `docs/ROADMAP.md`, `docs/LISTENING.md` — as they are.
  The ledger is the content.
- `vendor/` — as is. `vendor/README.md` already records the sha256s.
- `index.html` — the boot line says *your music is read locally and never
  uploaded*, which must stay true; the page fetches nothing off-origin.

## What does not have to be true by 8/24

- The phone tests (LISTENING §0–§6, the iOS memory question, the lock-screen
  experiment). Unheard things ship tagged as unheard; that is the house style.
- Phrase detection. Still the largest gap, still not a launch blocker.
- ES modules. The rule was restated to allow them; nothing requires them.
- A PWA manifest. Twenty lines if wanted; not a blocker.

## Day-of, as a list the keeper can run

1. `node tools/check-pool.js && node tools/check-route.js && node tools/check-player.js && node tools/check-panels.js` — all green.
2. `python tools/package.py` — cuts `_source/deckwave-<VERSION>.zip`; refuses if index.html references a missing file.
3. Decide the private/adjacent research and `_source/` per the table; commit.
4. `git tag -a v<VERSION> -m "public"`; OpenTimestamps the tag if wanted.
5. Create the GitHub repo (AGPL-3.0 template licence is already in the tree — pick "none" so it does not overwrite `LICENSE`), add the remote, push `master` and the tag.
6. Flip the Publishing bullet in CLAUDE.md; commit; push.

Everything above the line "Day-of" can be done before the day and most of it
by me, on request. Steps 4–6 are the keeper's.
