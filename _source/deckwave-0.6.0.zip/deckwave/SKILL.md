---
name: deckwave
description: Analyse a local music library and play or render a beat-locked, harmonically-mixed DJ set in the browser. Use when the user wants their own music analysed for tempo, key and energy; wants an automatic mix, set or playlist built from a folder of audio; asks for beatmatching, crossfades, harmonic or Camelot mixing, an energy arc, or a mix rendered to a file; or wants music that reacts to what an agent is doing. Runs entirely on the user's machine via the File System Access API — no audio is uploaded, bundled or fetched, and the third-party libraries are vendored in the tree rather than fetched at runtime. Chromium only. Not for generating music, not for streaming services, and not for anything that would distribute the user's audio. [v1.0]
---

# Deckwave

Corpus analysis and an automatic DJ, running in the page.

**Load `assets/deckwave.js`** into the browser console or via `javascript_exec`. It exposes `window.DW`.

## The short version

```js
await DW.scan(console.log)        // pick a folder → walks the tree, analyses, caches
DW.confidence()                   // how much to trust the tempo figures
const set = DW.build({ length: 60 })
DW.inspect(set)                   // stretch budget, key quality, runtime — READ THIS
await DW.openLibrary()            // re-pick the folder to resolve files for playback
await DW.play(set)
DW.stop()                         // stops everything, including scheduled sources
DW.kill()                         // last resort: closes the AudioContext
```

## What it does

**Analyses** each track with Essentia's `RhythmExtractor2013` in multifeature mode — five onset-detection functions fused by agreement. Also extracts key, maps it to Camelot, and computes loudness and brightness. **Decodes the whole track, measures it, then discards the buffer**; only a few hundred bytes of features per track are kept. That is what makes a several-hundred-track library possible at all.

**Caches** to IndexedDB keyed by name, size and modified time. The first scan costs seconds per track; every scan after is instant, and re-running after adding music only pays for the new files.

**Sequences** with a rolling tempo target that drifts with the set rather than a fixed BPM, scored on Camelot compatibility, tempo proximity and distance from an energy arc. A hard gate refuses any track needing more stretch than the budget.

**Plays** beat-locked: each deck runs through a SoundTouch AudioWorklet that stretches tempo without changing pitch, so both decks share a tempo and do not drift. Crossfades land on downbeats, with a three-band bass swap so only one kick sounds at a time. Tracks decode one ahead and release behind.

## Rules that matter

**Report `inspect()` before playing, and lead with the bad numbers.** `maxStretchPct` above 15 will audibly wobble — that is the perceptual limit, not a style preference. `keyWeak` counts clashing transitions. If the numbers are poor, say so rather than pressing play.

**Never quote a confidence figure as if it were comparable to another detector's.** Essentia's runs 0–5.32 on its own scale. A different algorithm's 0.9 and Essentia's 0.9 mean nothing to each other, and treating them as a before-and-after is the easiest lie to tell with this tool.

**Energy is a constructed index, not a measurement** — 45% loudness, 25% brightness, 30% tempo, normalised across the corpus. It correlates with what a listener would call energy. It is not the same thing, and a loud sparse track can land beside a quiet busy one.

**When the sequencer returns fewer tracks than asked for, that is correct.** The stretch gate ran out of reachable candidates and stopped rather than degrading. Report the shortfall as a constraint satisfied, not a failure.

**`stop()` must reach scheduled sources.** Every source goes into a registry; stop iterates the registry, not the current deck pointers. A source scheduled for a future time is unreachable any other way — this is the bug that made an early version unstoppable, and it is why `kill()` exists as a guaranteed backstop.

## Playing the user's own music

Files are read locally through a folder the user picks. **Nothing is uploaded, bundled or fetched.** Playing music someone owns, on their machine, is not a licensed act and needs no permission.

**Rendering a mix to a file is the same act; sharing that file is not.** A rendered mix contains the full recordings. If the user asks about distributing it, say plainly that it is a different question, and leave the decision with them — do not lecture, and do not refuse to build the export.

## Limits, all real

- **Chromium only.** `showDirectoryPicker` is unavailable in Firefox and Safari; there is no fallback here.
- **The worklet is served same-origin from `vendor/`.** It needs a fetchable URL with CORS and cannot be inlined, so it is vendored rather than fetched from a CDN; `DW.assets.allowCDN = true` re-enables runtime fetching and is off by default.
- **Beat detection on chiptune is unstudied.** No published accuracy figures exist for square-wave or noise percussion. Treat low-confidence results on that material as expected, not as a bug.
- **Stretch beyond ±15% degrades audibly.** The gate defaults to 8% for that reason.
- **No downbeat detection** — bar position is assumed as every fourth beat from the first. Works for 4/4 electronic music, fails elsewhere.
- **No phrase detection.** Transitions land on downbeats, not on 8- or 16-bar boundaries. That is the single largest quality gap.
- **Long offline renders may exhaust memory.** `OfflineAudioContext` allocates the whole output up front; past about 15 minutes, render in segments.

See `references/design.md` for the evidence behind these choices and what remains untested.
