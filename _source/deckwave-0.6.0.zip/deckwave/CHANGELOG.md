# Changelog

Versions are recorded here and in the package filename. Earlier packages from
the 2026-08-17 session were overwritten in place and no longer exist — this
file begins the lineage that will be preserved.

## 0.6.0 — 2026-08-18 · routing that reaches the deck

**Every route was inert in audio, and had been since 0.4.0.**
`DWNAV.commitAndRepair()` returns a NEW array; the dashboard assigned it to
itself and nothing else. `Player.play(seq)` had captured the array it was
handed as `order`, and there was no API to give it another. So a committed
route existed in two versions — one on screen with the stepping stones spliced
in, one in the speakers without them — and both were internally consistent.
The fourth occurrence of *the UI records an intention and playback never reads
it*; patch 09 was written to fix exactly that, for the queue instead of the
order.

`DW.reorder(seq, opts)` **adopts** the caller's array, so the list and the
player are one object again — the invariant every in-place steering operation
already relied on. It refuses when the playing track is no longer at `idx`
rather than repairing it, and re-chains, because the next deck is committed the
moment a track starts and that choice predates the route.

**Blend fast now leaves the current track at the next downbeat.** Scenic route
still lets it finish. Previously both waited out the current track in full and
then walked a route the deck could not see.

**New `route` panel.** The committed detour: stepping stones with the dwell
that will actually be honoured, the destination, the tempo ladder, progress to
the scheduled exit, and live stretch. It draws `set[state.idx] === DW.nowMeta`
as **LIST ≠ DECK** in red — the one identity check that would have caught this
defect, ledger 33 and ledger 38.

The wayposts panel draws `DWNAV.queue`, which `commitAndRepair()` clears on its
last line, so a route vanished from the display at the instant it became real.
`DWNAV.active` now records the committed route by object identity.

**Now-playing and the track list read the deck, not the list index.** Both
derived the playing track from `set[state.idx]`, which is only right while the
two arrays agree. `DW.nowMeta` is the meta object on the playing deck and
cannot be wrong about what is audible.

**Stepping stones are 45 seconds, not the 40 the menu advertised.** `chain()`
clamps every dwell to a floor that was an inline literal; the router asked for
40 and the menu printed the request. The floor is now `MIN_PLAY`, exposed as
`DW.dwellFloor`, and quoted by both places that used to quote the other number.
Neither number moved — that clash is ROADMAP D7 and it is an ear question.
Measured on the live corpus: 130 → 151 bpm is 4 stones, **3.0 min**, not 2.7.

**`settle` — riding a stretched deck back to its own speed after a bad blend.
Built, and OFF.** The obstacle was structural: every beat-to-wall-clock
conversion divided by a constant `rate`. Decks now carry `pos()`/`when()`,
which integrate the rate and reduce to exactly the old arithmetic when no ramp
is scheduled — asserted with `===`, not a tolerance. Turning it on makes a deck
hand over at its own BPM instead of the 35%-drift target, so it changes the
whole tempo plan downstream. 45 seconds is chosen, not measured. ROADMAP D8.

**`DW.audit(set)` and an `audit set` button.** Decodes every track with the
same `decodeAudioData` call playback makes and reports the failures with the
decoder's own message and the stage — `find`, `read` or `decode`, which have
completely different fixes. A track that will not decode is spliced out of the
order with one log line nobody is watching, so the symptom is "that one never
plays" with no evidence afterwards. Also flags any track whose decoded length
disagrees with the analysed length, which means the beat grid is mapped onto a
different length of audio than it was measured on.

**`tools/check-route.js`** — 15 offline checks against the real corpus and the
real cache, each printing what would falsify it. It does not touch audio, and
says so: the whole failure was a correct data structure that was not being
played.

**`expanse` theme and the `roci` sprite.** Vacuum blue-black, hull-display
teal against MCRN orange — the two accents a long way apart in hue, for the
reason every theme since stargaze has had to obey: loudtime draws its average
in one and its peak in the other, and on a limited track those traces meet.
The Rocinante is drawn on the theme slots rather than fixed RGB, so she
recolours under every theme.

**`tools/package.py`.** The CHANGELOG's own first line records that earlier
packages were built by hand and overwritten, and two shipped missing files the
page loads. The file list is now DERIVED from `index.html` — every `src` and
`href` is resolved and must exist or the build refuses — and it will not
overwrite an existing version without `--force`.

**Superseded:** `deckwave-0.5.0.zip`, preserved.

## 0.5.0 — 2026-08-17 · fast blends, queue as a list

**Fast blends.** The rolling target advances 35% per *track played*, not per
second — so a stepping stone shifts the tempo the same whether it plays 40
seconds or four minutes. Intermediates in a route now play only long enough to
blend in, hold, and blend out.

Measured from 125 BPM: 151 BPM in **4.0 min** instead of 21.0; 90 BPM in
**7.3 min** instead of 38.5. Same hops, same tempo movement, same 8% gate on
every transition.

**The queue is a list.** Several destinations can be queued, reordered and
removed, each with its own mode. `DWNAV.queue` still returns the head, so the
wayposts panel and route commit needed no changes.

**Queue panel**, bottom left: per-entry tempo ladder, wall-clock estimate,
reorder and remove, and a commit action. Badges distinguish fast, scenic,
direct and forced.

**Superseded:** `deckwave-0.4.0.zip`, preserved.

## 0.4.0 — 2026-08-17 · steering

**Steering a running set.** Clicking a track no longer jumps; it opens a menu
with options that each state their cost.

- **`DWNAV` router.** The rolling target moves 35% toward each track played,
  so a track unreachable now may be reachable after a hop. Getting to a
  destination becomes a shortest-path search with the stretch gate as the edge
  condition. One hop gains at most **3.04%** tempo — derived, not guessed.
- **Wayposts panel.** The corpus as a navigable space: angle is Camelot
  position, radius is log tempo, and the lit annulus is everything the gate
  permits from here. A long harmonic tempo climb draws itself as a spiral.
- **Route commit.** A chosen route is spliced into the set rather than
  intercepted at playback, so the player walks it by construction.
- **Tail repair.** A detour changes the tempo state and breaks the rest of the
  set; `resequenceTail` re-plans it. Verified: zero tracks over the gate.
- **Corpus cache export/restore**, with integrity comparison on restore.

**Bug fixed in this release:** the router, steering menu and panel all shipped
in a state where the queue was populated and **nothing in the playback path
read it.** The feature recorded intentions and discarded them. Caught by the
keeper noticing the set was not walking anywhere.

**Measured:** at 109 BPM on 189 tracks — 123 BPM in 2 hops; 139 BPM in 7 hops
and ~25 min; 79 BPM in 13 hops and ~46 min; 172 BPM genuinely unreachable, the
corpus lacks the rungs.

**Superseded:** `deckwave-0.3.0.zip`, which is preserved.

## 0.3.0 — 2026-08-17 · RECONSTRUCTED

Marked RECONSTRUCTED because it is the surviving state of a package that was
rebuilt in place roughly eight times during a single session. The intermediate
states are gone. Nothing here is uncertain — the contents are known and
verified — but the *history* of the artifact was destroyed and cannot be
recovered.

**Contents:** engine, panel registry with twelve panels, portable score format,
FLAC tag reading, listen mode, now-playing card, single render loop, glossary
with 32 terms and translation export, six themes, saveable named views,
collapsible panels, MEGA layout. `mount()` wires every mixin; the loop starts
once. 21 files, all modules syntax-checked.

**Known unverified:** a cold load of `index.html` has never been tested. All
development ran through live injection into an already-running page.

**Superseded in this release:** nothing preserved. See note above.
