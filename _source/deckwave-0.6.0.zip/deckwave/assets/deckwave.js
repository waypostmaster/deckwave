/* DECKWAVE — corpus analysis + beat-locked automatic DJ, in the browser.
   No build step. Load by pasting into the console, or via javascript_exec.

   Pipeline:  scan a folder -> analyse each track (Essentia) -> cache to IndexedDB
              -> sequence by key/tempo/energy -> play beat-locked with lazy decode.

   Everything runs locally. No audio is uploaded, bundled, or fetched.        */

window.DW = (function () {
'use strict';

/* ── where the dependencies come from ───────────────────────────────────
   SELF-HOSTED BY DEFAULT, and the default matters.

   These libraries do not run in a sandbox. They execute in a page that is
   holding live FileSystemDirectoryHandle objects for the user's music folder
   and has ordinary network access. A compromised or MITM'd CDN response
   inherits both. Dynamically-injected scripts cannot carry an integrity
   attribute, so there is no SRI to fall back on — the only real control is
   not fetching third-party code at runtime.

   vendor/ holds all four, pinned to exact versions with recorded sha256s.
   See vendor/README.md.

   allowCDN exists for one case: pasting this engine into a page that has no
   vendor/ next to it, which is how the whole thing was originally built. It
   is opt-in and deliberately noisy, because turning it on reintroduces
   exactly the exposure above:

       DW.assets.allowCDN = true;                     // then scan()

   Setting `base` is the better answer when the files live elsewhere. */
const ASSETS = {
  base: 'vendor/',
  allowCDN: false,
  files: {
    essentiaWasm: 'essentia-wasm.web.js',
    essentiaCore: 'essentia.js-core.js',
    soundtouch:   'soundtouch-processor.js',
    flac:         'libflac.min.js'
  }
};
const CDN = {
  essentiaWasm: 'https://cdn.jsdelivr.net/npm/essentia.js@0.1.3/dist/essentia-wasm.web.js',
  essentiaCore: 'https://cdn.jsdelivr.net/npm/essentia.js@0.1.3/dist/essentia.js-core.js',
  /* PINNED to 2.1.1 (MPL-2.0). Note the directory is ".dist", with a leading
     dot — that is genuinely the published layout, and it is why the old
     unpinned /dist/ path could never resolve to a 2.x release and silently
     served 0.3.0 (LGPL-2.1) instead. See vendor/README.md.
     0.3.0 dropped samples on every stretched deck; see makeDeck. */
  soundtouch:   'https://cdn.jsdelivr.net/npm/@soundtouchjs/audio-worklet@2.1.1/.dist/soundtouch-processor.js',
  flac:         'https://cdn.jsdelivr.net/npm/libflacjs@5.4.0/dist/libflac.min.js'
};
const assetURL = k => ASSETS.base + ASSETS.files[k];
const AC = window.AudioContext || window.webkitAudioContext;
const script = s => new Promise((ok, no) => {
  const e = document.createElement('script'); e.src = s;
  e.onload = () => ok(s); e.onerror = () => no(new Error('load failed: ' + s));
  document.head.appendChild(e);
});

/* Try the vendored copy first. Fall back to the CDN only if explicitly
   allowed, and say so in the console when it happens — a silent fallback to
   remote code is the failure this is meant to prevent. */
async function loadAsset(k) {
  try { return await script(assetURL(k)); }
  catch (e) {
    if (!ASSETS.allowCDN)
      throw new Error('missing ' + assetURL(k) +
        ' — vendor/ is not present. Fetch it (see vendor/README.md), or set ' +
        'DW.assets.allowCDN = true to load third-party code from a CDN instead.');
    console.warn('deckwave: falling back to CDN for ' + k + ' — remote code, no integrity check');
    return script(CDN[k]);
  }
}
/* Strip only a KNOWN audio extension, never "whatever follows the last dot".
   This key is built from a File name (which has an extension) and looked up
   from a meta name (which does not), so it has to be idempotent — and
   /\.[^.]+$/ is not. On a stem containing a dot it ate a real part of the
   title the second time round:

     'DRUID II … (1987) David M. Hanlon.flac' -> '…david m. hanlon'   (File)
     'DRUID II … (1987) David M. Hanlon'      -> '…david m'           (meta)

   Two different keys for one track, so find() returned undefined and the
   player reported a missing file for something sitting on disk. Keep this
   list in step with AUDIO_EXT below. */
const norm = s => s.toLowerCase().replace(/\.(flac|mp3|wav|aiff|m4a|ogg)$/, '')
  .replace(/[^a-z0-9]/g, '');

/* ── cache ─────────────────────────────────────────────────────────────── */
const DB = (() => {
  let db = null;
  const open = () => new Promise((ok, no) => {
    const r = indexedDB.open('deckwave', 1);
    r.onupgradeneeded = e => { const d = e.target.result;
      if (!d.objectStoreNames.contains('f')) d.createObjectStore('f', { keyPath: 'id' }); };
    r.onsuccess = e => { db = e.target.result; ok(db); };
    r.onerror = () => no(r.error);
  });
  return {
    async get(id) { if (!db) await open(); return new Promise(ok => {
      const t = db.transaction('f', 'readonly').objectStore('f').get(id);
      t.onsuccess = () => ok(t.result || null); t.onerror = () => ok(null); }); },
    async put(rec) { if (!db) await open(); return new Promise(ok => {
      const t = db.transaction('f', 'readwrite').objectStore('f').put(rec);
      t.onsuccess = () => ok(true); t.onerror = () => ok(false); }); },
    async all() { if (!db) await open(); return new Promise(ok => {
      const t = db.transaction('f', 'readonly').objectStore('f').getAll();
      t.onsuccess = () => ok(t.result || []); t.onerror = () => ok([]); }); }
  };
})();

/* ── harmonic mixing ───────────────────────────────────────────────────── */
const CAMELOT_MAJOR = { C:8, G:9, D:10, A:11, E:12, B:1, 'F#':2, Gb:2, Db:3, 'C#':3,
                        Ab:4, 'G#':4, Eb:5, 'D#':5, Bb:6, 'A#':6, F:7 };
const CAMELOT_MINOR = { A:11, E:12, B:1, 'F#':2, Gb:2, Db:3, 'C#':3, Ab:4, 'G#':4,
                        Eb:5, 'D#':5, Bb:6, 'A#':6, F:7, C:8, G:9, D:10 };
function camelot(key, scale) {
  const n = /min/i.test(scale) ? CAMELOT_MINOR[key] : CAMELOT_MAJOR[key];
  return n ? n + (/min/i.test(scale) ? 'A' : 'B') : '?';
}
/* 1.0 identical · .92 adjacent (perfect fifth) · .85 relative · .45 two steps */
function camScore(a, b) {
  if (!a || !b || a === '?' || b === '?') return 0.25;
  if (a === b) return 1;
  const na = +a.slice(0, -1), la = a.slice(-1), nb = +b.slice(0, -1), lb = b.slice(-1);
  if (isNaN(na) || isNaN(nb)) return 0.25;
  if (na === nb) return 0.85;
  const d = Math.min(Math.abs(na - nb), 12 - Math.abs(na - nb));
  if (la === lb && d === 1) return 0.92;
  if (la === lb && d === 2) return 0.45;
  return 0.08;
}

/* ── analysis ──────────────────────────────────────────────────────────── */
let essentia = null;
async function bootEssentia() {
  if (essentia) return essentia;
  /* index.html already loads both from vendor/ with plain <script> tags, so
     in the normal case there is nothing to fetch here at all. This used to
     inject the CDN copies unconditionally and load Essentia twice. */
  if (typeof window.EssentiaWASM === 'undefined' || typeof window.Essentia === 'undefined') {
    await loadAsset('essentiaWasm');
    await loadAsset('essentiaCore');
  }
  essentia = new Essentia(await EssentiaWASM());
  return essentia;
}

/* Bumped when the meaning of a stored record changes, so stale ones are
   re-analysed instead of silently reused. The cache key is name|size|mtime,
   which does not change when OUR analysis does — v1 records hold a beat grid
   that is excerpt-relative and stops at 120s, and nothing about the file
   would ever have told us to discard them. */
const ANALYSIS_V = 2;

/* Decode, analyse, DISCARD the buffer. Only features are kept.

   THE GRID IS NOW TAKEN FROM THE WHOLE TRACK, and this is the fix for the
   worst defect this project has had.

   What was here: rhythm and key were both run on a CENTRED 120-SECOND
   EXCERPT, and Essentia returns tick times relative to the signal it was
   handed. Those excerpt-relative times were stored and then used as absolute
   positions in the file. Two consequences, both silent:

     · No grid reached past 120s. Measured across 219 cached records, the
       latest beat anywhere was 119.9s. downbeatNear() cannot say "I have
       nothing near the exit", so it returned the last downbeat it had and
       tracks blended there. Median coverage 60.6%; 236.7 minutes of music
       never played; worst case 371.8s skipped from a 507s track.
     · entry = beats[0], and chain() starts the incoming deck at that offset
       ON the outgoing deck's downbeat. That IS the beat alignment. With an
       excerpt-relative grid the offset is a beat from the middle of the track
       applied near the start, so the incoming track enters at an arbitrary
       phase and its kicks land beside the outgoing track's. Inaudible when a
       track is played alone, audible as popping through a mix — which is
       exactly the difference the keeper found between jumping to a track and
       arriving at it.

   KEY, RMS AND ZCR STILL USE THE CENTRED EXCERPT, deliberately. They are not
   broken, their values are calibrated, and the energy index is built from rms.
   Changing what they see would change every one of those numbers for no
   reason connected to this defect.

   BPM AND CONFIDENCE WILL CHANGE, because the rhythm extractor now sees the
   whole track instead of 120 seconds of it. That is unavoidable — it is the
   same detector reading more signal — and it is why ANALYSIS_V exists. */
async function analyse(file, excerptSec) {
  const id = file.name + '|' + file.size + '|' + (file.lastModified || 0);
  const hit = await DB.get(id);
  if (hit && hit.v === ANALYSIS_V) return Object.assign({ cached: true }, hit);

  const ctx = new AC({ sampleRate: 44100 });
  let buf; try { buf = await ctx.decodeAudioData(await file.arrayBuffer()); }
  catch (e) { ctx.close(); throw new Error('decode: ' + e.message); }

  const sr = buf.sampleRate, dur = buf.duration;
  const want = Math.min(dur, excerptSec || 120);
  const start = Math.max(0, Math.floor((dur - want) / 2 * sr));
  const n = Math.floor(want * sr);
  const mono = new Float32Array(n), chs = buf.numberOfChannels;
  for (let c = 0; c < chs; c++) { const d = buf.getChannelData(c);
    for (let i = 0; i < n; i++) mono[i] += d[start + i] / chs; }

  let sum = 0, zc = 0;
  for (let i = 1; i < n; i++) { sum += mono[i] * mono[i];
    if ((mono[i] >= 0) !== (mono[i - 1] >= 0)) zc++; }

  const E = await bootEssentia(), vec = E.arrayToVector(mono);
  let bpm = 0, conf = 0, beats = [], key = '?', scale = '?', kstr = 0;

  /* Rhythm over the WHOLE track, in its own vector. Built separately from the
     excerpt so the ticks come back relative to the start of the file, which
     is what every consumer of this grid already assumes. */
  const full = new Float32Array(buf.length);
  for (let c = 0; c < chs; c++) { const d = buf.getChannelData(c);
    for (let i = 0; i < full.length; i++) full[i] += d[i] / chs; }
  const fvec = E.arrayToVector(full);
  try {
    const r = E.RhythmExtractor2013(fvec, 208, 'multifeature', 40);
    bpm = r.bpm; conf = r.confidence; beats = E.vectorToArray(r.ticks);
    ['ticks','estimates','bpmIntervals'].forEach(k => { if (r[k] && r[k].delete) r[k].delete(); });
  } catch (e) { console.warn('rhythm', file.name, e); }
  if (fvec.delete) fvec.delete();

  try {
    const k = E.KeyExtractor(vec, true, 4096, 4096, 12, 3500, 60, 25, .2, 'bgate', sr, .0001, 440, 'cosine', 'hann');
    key = k.key; scale = k.scale; kstr = k.strength;
  } catch (e) { console.warn('key', file.name, e); }
  if (vec.delete) vec.delete();
  ctx.close(); buf = null;                                   /* ← the whole point */

  const rec = { id, name: file.name.replace(/\.[^.]+$/, ''),
    bpm: +bpm.toFixed(2), conf: +conf.toFixed(3),
    /* Array.from, NOT .slice().map() — vectorToArray returns a Float32Array and
       both slice() and map() preserve that type. A Float32Array survives the
       structured clone into IndexedDB, so .length and .map() keep working and
       nothing looks wrong. It does NOT survive JSON: stringify emits an object
       ({"0":0.38,...}), and the parsed result has no .length and no .map. That
       silently breaks every cache export ever written. Store a plain Array. */
    /* Cap raised from 900. It existed to bound the cache, and against a 120s
       excerpt nothing ever came close — 0 of 219 records reached it. A grid
       for a whole track does: 507s at 100bpm is ~845 beats, and faster or
       longer material passes 900 easily, so the old cap would have quietly
       reintroduced the same truncation this change exists to remove. 4000
       covers 24 minutes at 170bpm. Storage, not a detector threshold. */
    beats: Array.from(beats.slice(0, 4000), x => +x.toFixed(4)),
    v: ANALYSIS_V,
    key, scale, camelot: camelot(key, scale), kstr: +kstr.toFixed(3),
    rms: Math.sqrt(sum / n), zcr: zc / n, dur: +dur.toFixed(1), size: file.size };
  await DB.put(rec); return rec;
}

/* One list of accepted types, used by the folder walk and by the file picker
   so they can never disagree about what counts as audio. */
const AUDIO_EXT = ['.flac', '.mp3', '.wav', '.aiff', '.m4a', '.ogg'];
const AUDIO_RE = new RegExp('\.(' + AUDIO_EXT.map(e => e.slice(1)).join('|') + ')$', 'i');

async function walk(dir, out, depth) {
  out = out || []; depth = depth || 0; if (depth > 6) return out;
  for await (const e of dir.values()) {
    if (e.kind === 'file') { if (AUDIO_RE.test(e.name)) out.push(await e.getFile()); }
    else if (e.kind === 'directory') await walk(e, out, depth + 1);
  } return out;
}

/* Energy is a CONSTRUCTED INDEX, normalised across the corpus — not a measurement. */
function normalise(corpus) {
  if (!corpus.length) return corpus;
  const R = corpus.map(t => t.rms), Z = corpus.map(t => t.zcr);
  const lo = Math.min(...R), hi = Math.max(...R), zl = Math.min(...Z), zh = Math.max(...Z);
  corpus.forEach(t => {
    const r = hi > lo ? (t.rms - lo) / (hi - lo) : .5;
    const z = zh > zl ? (t.zcr - zl) / (zh - zl) : .5;
    const b = Math.min(1, Math.max(0, (t.bpm - 90) / 70));
    t.energy = +(r * .45 + z * .25 + b * .30).toFixed(3);
  });
  return corpus;
}

/* ── sequencing ────────────────────────────────────────────────────────── */
/* Rise to ~72% of the set, peak, gentle release. */
const arc = (i, n) => { const p = i / (n - 1 || 1);
  return p < .72 ? (.22 + p / .72 * .62) : (.84 - (p - .72) / .28 * .30); };

/* Same track on an album AND a single is one track. Strip artist and album prefixes. */
function dedupe(corpus) {
  const key = t => t.name.toLowerCase()
    .replace(/^[^-]+-\s*/, '').replace(/^[^-]+-\s*/, '')
    .replace(/^\d+\s*/, '').replace(/[^a-z0-9]/g, '');
  const seen = new Map();
  for (const t of corpus) { const k = key(t); if (!k) continue;
    if (!seen.has(k) || seen.get(k).conf < t.conf) seen.set(k, t); }
  return [...seen.values()];
}

/* Rolling tempo: the target DRIFTS with the set rather than being fixed.
   A hard gate refuses any track needing more stretch than maxStretch.
   The sequence stops short rather than degrading — that is intended. */
function sequence(corpus, opts) {
  opts = opts || {};
  const maxStretch = opts.maxStretch != null ? opts.maxStretch : 0.08;
  const minConf = opts.minConf != null ? opts.minConf : 0.8;
  const pool = dedupe(corpus).filter(t => t.bpm > 60 && t.dur > 75 && t.conf > minConf);
  if (!pool.length) return [];
  const n = Math.min(opts.length || pool.length, pool.length);
  const w = Object.assign({ key: .30, tempo: .30, energy: .40 }, opts.weights);

  const used = new Set();
  let cur = pool.slice().sort((a, b) =>
    Math.abs(a.energy - arc(0, n)) - Math.abs(b.energy - arc(0, n)))[0];
  used.add(cur.id); const out = [cur]; let tempo = cur.bpm;

  for (let i = 1; i < n; i++) {
    const want = arc(i, n); let best = null, bs = -1;
    for (const t of pool) {
      if (used.has(t.id)) continue;
      const stretch = Math.abs(tempo / t.bpm - 1);
      if (stretch > maxStretch) continue;                    /* ← the gate */
      const s = camScore(cur.camelot, t.camelot) * w.key
              + (1 - stretch / maxStretch) * w.tempo
              + (1 - Math.min(1, Math.abs(t.energy - want) / .30)) * w.energy;
      if (s > bs) { bs = s; best = t; }
    }
    if (!best) break;
    used.add(best.id); best._score = +bs.toFixed(3);
    best._stretch = +(tempo / best.bpm).toFixed(3); best._tempoAt = Math.round(tempo);
    out.push(best); tempo += (best.bpm - tempo) * (opts.drift || 0.35); cur = best;
  }
  return out;
}

/* ── library: directory handle retained, files resolved lazily ─────────── */
const LIB = { dir: null, files: null,
  async pick() {
    if (!window.showDirectoryPicker) throw new Error('showDirectoryPicker unavailable (Chromium only)');
    this.dir = await window.showDirectoryPicker({ mode: 'read' });
    const f = await walk(this.dir); this.files = new Map();
    for (const x of f) this.files.set(norm(x.name), x);
    return this.files.size;
  },
  find(meta) { return this.files ? this.files.get(norm(meta.name)) : null; },
  async decode(meta, ctx) {
    const f = this.find(meta);
    if (!f) throw new Error('missing file: ' + meta.name.slice(-32));
    return ctx.decodeAudioData(await f.arrayBuffer());
  }
};

/* ── player ────────────────────────────────────────────────────────────── */
const Player = (() => {
  let ctx = null, master = null, analyser = null, booted = false;
  let A = null, B = null, order = [], idx = 0, tempo = 0, xfade = 16;
  /* The shortest a track is allowed to hold the deck. It was written inline
     in chain() as a bare 45, and patch 10's DWELL.min is 40 — so the fast
     route printed "each stone plays only 40s" while chain() clamped every
     stone to 45. Neither number was measured, so neither is moved here; the
     one that actually governs is named and exposed instead, and the menu
     prints THAT. A chosen number is allowed to be wrong. A chosen number
     copied into two places and disagreeing with itself is not. */
  const MIN_PLAY = 45;
  /* ── settling a stretched deck back to its own speed ────────────────
     OFF, and it must stay off until it has been heard.

     A forced blend leaves the incoming track stretched for its whole length:
     force +14% and that track is 14% fast until it ends. `settle` rides the
     rate back to 1.0 over `seconds`, which is what a DJ does with the pitch
     fader after a rescue.

     WHAT IT COSTS, stated before it is switched on: `rate` stops being a
     constant, so every `* (1/rate)` mapping in here becomes wrong. They are
     replaced by deck.pos()/deck.when(), which integrate the rate — and which
     reduce to exactly the old arithmetic while no ramp is scheduled. That
     equivalence is the thing to test first; the sound is the thing to test
     second.

     It also changes the SET, not just the track: a deck that settles hands
     over at its own BPM instead of at the 35%-drift target, so the rolling
     tempo becomes the current track's BPM and every subsequent gate test is
     measured from there. That is a musical change, not a fix. `seconds` is
     chosen, not measured.

     `minStretch` is null — settle every stretched deck. Set it to a fraction
     to settle only the bad ones. It is deliberately NOT defaulted to 0.08:
     that number is DWNAV.GATE, it lives there, and copying it in here would
     make two thresholds that can drift apart — the same mistake as the 45/40
     dwell clash directly above. The caller that wants gate semantics passes
     DWNAV.GATE, so there stays exactly one of it. */
  const settle = { on: false, seconds: 45, minStretch: null };
  /* Master level, held OUTSIDE the graph so it survives boot() and kill().
     The gain node does not exist until the first play, and kill() throws the
     whole context away — a level stored only on the node would silently reset
     to the default every time. 0.85 is the existing default, unchanged. */
  let volume = .85;
  let chainTimer = null;
  const log = [];
  /* EVERY scheduled source lands here. stop() iterates this, not the deck
     pointers — a source scheduled for the future is not reachable any other way,
     which is exactly how the first stop button failed. */
  const live = new Set();

  async function boot() {
    if (booted) return;
    ctx = new AC({ sampleRate: 44100 });
    /* Same-origin worklet. index.html's comment always claimed this was
       self-hosted; until now it was not, and the unpinned URL was silently
       resolving to 0.3.0 (LGPL-2.1) rather than the MPL-2.0 release the
       licence notes assumed. */
    try { await ctx.audioWorklet.addModule(assetURL('soundtouch')); }
    catch (e) {
      if (!ASSETS.allowCDN)
        throw new Error('missing ' + assetURL('soundtouch') +
          ' — see vendor/README.md, or set DW.assets.allowCDN = true');
      console.warn('deckwave: falling back to CDN for the worklet — remote code, no integrity check');
      await ctx.audioWorklet.addModule(CDN.soundtouch);
    }
    master = ctx.createGain(); master.gain.value = volume;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -12; comp.ratio.value = 4;
    master.connect(comp); comp.connect(ctx.destination);
    analyser = ctx.createAnalyser(); analyser.fftSize = 2048; analyser.smoothingTimeConstant = .7;
    /* an analyser in a dead-end branch is not reliably pulled — give it a silent sink */
    const sink = ctx.createGain(); sink.gain.value = 0;
    master.connect(analyser); analyser.connect(sink); sink.connect(ctx.destination);
    booted = true;
  }

  /* SoundTouchJS 2.1.1 inverted the model, so this is not the same wiring as
     0.3.0 and the difference matters.

     0.3.0: the source ran at 1.0 and the WORKLET stretched time, via a `tempo`
     AudioParam. That param does not exist in 2.x. Worse, its process() pushed
     128 frames in and assumed 128 came back — writing a fresh zero-filled
     array's untouched remainder straight to the output whenever the stretcher
     had fewer ready. Measured offline: 0 gaps/sec at tempo 1.00, but 10
     gaps/sec and 7.3% silent frames at 1.08. Every chained deck is stretched;
     the first deck and any jumped-to deck are not. That is exactly the "clean
     alone, pops through a mix" pattern the keeper reported, and it confounded
     the phase reading in Act 21 for a day.

     2.1.1: the SOURCE changes speed and the worklet compensates pitch. Set
     playbackRate identically on both and leave `pitch` at 1 — the processor
     computes `pitch * 2^(semitones/12) / playbackRate` internally, so
     playbackRate alone restores the original pitch. Setting `pitch` here too
     would compensate twice.

     `k = 1 / rate` in chain() is unchanged and still correct: which node
     performs the time change does not alter the wall-clock mapping. */
  function makeDeck(track, rate) {
    const src = ctx.createBufferSource(); src.buffer = track.buf;
    src.playbackRate.value = rate;                    /* the source does the time change */
    const st = new AudioWorkletNode(ctx, 'soundtouch-processor');
    st.parameters.get('playbackRate').value = rate;   /* and the worklet undoes the pitch */
    const lo = ctx.createBiquadFilter(); lo.type = 'lowshelf';  lo.frequency.value = 200;
    const mid = ctx.createBiquadFilter(); mid.type = 'peaking'; mid.frequency.value = 1000; mid.Q.value = .8;
    const hi = ctx.createBiquadFilter(); hi.type = 'highshelf'; hi.frequency.value = 4000;
    const g = ctx.createGain(); g.gain.value = 0;
    src.connect(st); st.connect(lo); lo.connect(mid); mid.connect(hi); hi.connect(g); g.connect(master);
    live.add(src); src.onended = () => live.delete(src);

    /* ── the source-time ↔ wall-time map ────────────────────────────
       Beat positions live in SOURCE seconds; schedules live in WALL seconds.
       Everything here used to convert with `k = 1 / rate`, which is true only
       while the rate never changes. With a settle ramp it does change, so the
       conversion integrates the rate instead of dividing by it.

         ramp === null      constant rate — pos/when are t*rate and p/rate,
                            i.e. byte-for-byte the old arithmetic.
         ramp = {r0,r1,S}   linear r0→r1 over S wall-seconds, then flat at r1.

       pos(t)  source-seconds consumed by t wall-seconds of playing
       when(p) wall-seconds needed to consume p source-seconds — pos inverted
       Both are relative to the deck's own start; add startedAt for ctx time. */
    const d = {
      src, st, lo, mid, hi, g, track, rate, ramp: null,
      rateAt(t) {
        const r = d.ramp; if (!r) return d.rate;
        return t <= 0 ? r.r0 : t >= r.S ? r.r1 : r.r0 + (r.r1 - r.r0) * (t / r.S);
      },
      pos(t) {
        const r = d.ramp; if (!r) return t * d.rate;
        if (t <= r.S) return r.r0 * t + (r.r1 - r.r0) * t * t / (2 * r.S);
        return (r.r0 + r.r1) / 2 * r.S + r.r1 * (t - r.S);
      },
      when(p) {
        const r = d.ramp; if (!r) return p / d.rate;
        const pS = (r.r0 + r.r1) / 2 * r.S;
        if (p >= pS) return r.S + (p - pS) / r.r1;
        const a = (r.r1 - r.r0) / (2 * r.S), b = r.r0;
        if (Math.abs(a) < 1e-12) return p / b;
        /* the +root is the one before the parabola's vertex — the physical
           one — for both signs of a; the other is the ramp running backwards */
        return (-b + Math.sqrt(Math.max(0, b * b + 4 * a * p))) / (2 * a);
      },
      /* Schedule the ride. Called after the start time is known, because the
         start time is chosen by chain() and not by makeDeck(). */
      setRamp(r0, r1, S, at) {
        d.ramp = { r0, r1, S };
        const wp = st.parameters.get('playbackRate');
        [src.playbackRate, wp].forEach(p => {
          try {
            p.cancelScheduledValues(at);
            p.setValueAtTime(r0, at);
            p.linearRampToValueAtTime(r1, at + S);
          } catch (e) {}
        });
        return d;
      }
    };
    return d;
  }

  function downbeatNear(beats, t) {
    let best = t, d = Infinity;
    for (let i = 0; i < beats.length; i += 4) {
      const dd = Math.abs(beats[i] - t); if (dd < d) { d = dd; best = beats[i]; } }
    return best;
  }

  /* Cancel the blend that chain() has already committed to the graph.
     chain() schedules the next deck the instant the current track starts, so
     anything that wants to change what comes next has to undo that first —
     otherwise the old choice is still wired up and will play. */
  function cancelPending() {
    if (!ctx) return;
    clearTimeout(chainTimer);
    if (B) {
      try { B.src.stop(); } catch (e) {}
      try { B.g.gain.cancelScheduledValues(ctx.currentTime); B.g.gain.value = 0; } catch (e) {}
      live.delete(B.src); B = null;
    }
    if (A) {
      /* put A back to full, un-faded, so chain() can re-plan its exit */
      try {
        A.g.gain.cancelScheduledValues(ctx.currentTime);
        A.g.gain.setValueAtTime(1, ctx.currentTime);
        A.lo.gain.cancelScheduledValues(ctx.currentTime);
        A.lo.gain.setValueAtTime(0, ctx.currentTime);
      } catch (e) {}
    }
  }

  /* Move meta to be the next track, IN PLACE, so the dashboard's array — the
     same object — sees it too. Reassigning order would silently desync them. */
  function placeNext(meta) {
    const at = order.indexOf(meta);
    if (at > -1) order.splice(at, 1);
    order.splice(idx + 1, 0, meta);
  }

  /* The next DOWNBEAT at least `lead` seconds away, in context time.
     Same every-fourth-beat assumption the rest of the engine makes — see the
     build log's note that there is no real downbeat detection, only 4/4.
     Uses the grid already detected for the playing track; no new constant. */
  function nextDownbeatAfter(lead) {
    const m = A.track.meta;
    const since = ctx.currentTime - A.startedAt;
    const beats = (m.beats || []).map(b => A.when(b - A.entry));
    for (let i = 0; i < beats.length; i += 4)
      if (beats[i] > since + lead) return A.startedAt + beats[i];
    return ctx.currentTime + lead;         /* no grid — go on the clock */
  }

  async function chain(forceOut, preBuf) {
    if (!A) return;
    const m = A.track.meta;
    const beats = (m.beats || []).map(b => A.when(b - A.entry));
    /* A stepping stone on a fast route carries `_dwell` — how long it needs to
       exist for, which is blend-in plus a short hold plus blend-out. It plays
       for that instead of its full length; everything else is unchanged.

       NOTE THE CLASH, unresolved deliberately: this floor is MIN_PLAY = 45s
       and patch 10's DWELL.min is 40s, so a 40s dwell is clamped up to 45.
       Both numbers were chosen rather than measured, and moving either is a
       threshold change — so it is surfaced rather than quietly reconciled.
       It is no longer a bare literal here: MIN_PLAY is exposed as
       DW.dwellFloor and the fast-route menu prints the clamped figure, so
       the UI stops advertising a dwell the engine will not honour. */
    const natural = A.when(m.dur - A.entry) - xfade;
    const playFor = m._dwell
      ? Math.max(MIN_PLAY, Math.min(m._dwell, natural))
      : Math.max(MIN_PLAY, natural);
    const exit = beats.length ? downbeatNear(beats, playFor) : playFor;
    const out = forceOut != null ? forceOut : A.startedAt + exit; A.outAt = out;

    A.g.gain.setValueAtTime(1, out);
    A.g.gain.linearRampToValueAtTime(0, out + xfade);
    /* bass swap — only one kick and one bassline sounds at a time */
    A.lo.gain.setValueAtTime(0, out);
    A.lo.gain.linearRampToValueAtTime(-30, out + xfade * .45);
    A.src.stop(out + xfade + .4);

    const ni = idx + 1;
    if (ni >= order.length) { log.unshift('end of set'); return; }
    const nm = order[ni];
    let buf;
    if (preBuf) buf = preBuf;              /* already decoded by the caller */
    else { try { buf = await LIB.decode(nm, ctx); }
      /* A track that will not decode must leave the ORDER, not move idx.
         The old line did `idx = ni`, which advanced the set position while A
         was still playing the previous track — so state.idx named the failed
         track while the deck played the one before it, for the rest of that
         track. Observed: card showing "Druid II", deck playing "Big In Japan".
         idx is the position of the PLAYING deck; nothing but the handover
         timer may move it.
         Splicing is the same in-place idiom placeNext() uses, and order is the
         dashboard's own array, so the list drops the unplayable track too.
         forceOut is passed through: the old bare chain() silently discarded a
         blend-now's forced exit if the incoming track failed to decode. */
      catch (e) {
        log.unshift('SKIP ' + nm.name.slice(-30) + ' — ' + e.message);
        order.splice(ni, 1);
        return chain(forceOut);
      } }

    const rate = tempo / nm.bpm;
    const nd = makeDeck({ meta: nm, buf }, rate);
    nd.entry = (nm.beats || [0])[0] || 0;
    /* Ride a stretched deck back to its own speed, if that is switched on.
       Scheduled HERE, before the exit is planned below, so the exit is chosen
       against the map that will actually apply — a ramp discovered after the
       schedule was written would move every downbeat under it. */
    let settled = false;
    if (settle.on && isFinite(rate) && rate > 0) {
      const off = Math.abs(rate - 1);
      if (off > 1e-4 && (settle.minStretch == null || off > settle.minStretch)) {
        nd.setRamp(rate, 1, Math.max(1, settle.seconds), out);
        settled = true;
      }
    }
    nd.g.gain.setValueAtTime(0, out);
    nd.g.gain.linearRampToValueAtTime(1, out + xfade * .6);
    nd.lo.gain.setValueAtTime(-30, out);
    nd.lo.gain.linearRampToValueAtTime(0, out + xfade * .55);
    nd.src.start(out, nd.entry); nd.startedAt = out;
    B = nd;
    log.unshift('→ ' + nm.name.slice(-30) + ' ×' + rate.toFixed(3) + ' ' + nm.camelot
                + (settled ? ' ⤳settling' : ''));
    if (log.length > 60) log.pop();
    /* A settled deck ENDS at its own BPM, so the rolling target is that BPM
       and not the 35% drift toward it. Using the drift figure after a settle
       would compute the next deck's rate against a tempo nothing is playing. */
    tempo = settled ? nm.bpm : tempo + (nm.bpm - tempo) * .35;

    clearTimeout(chainTimer);
    chainTimer = setTimeout(() => {
      if (A) A.track.buf = null;                       /* release behind */
      idx = ni; A = B; B = null; chain();
    }, (out - ctx.currentTime) * 1000 + 100);
  }

  return {
    async play(seq, from) {
      await boot(); await ctx.resume(); this.stop();
      order = seq; idx = from || 0;
      const m = order[idx], buf = await LIB.decode(m, ctx);
      tempo = m.bpm;
      const d = makeDeck({ meta: m, buf }, 1);
      d.entry = (m.beats || [0])[0] || 0;
      const t0 = ctx.currentTime + .35;
      d.g.gain.setValueAtTime(0, t0); d.g.gain.linearRampToValueAtTime(1, t0 + 1);
      d.src.start(t0, d.entry); d.startedAt = t0;
      A = d; B = null;
      log.unshift('▶ ' + m.name.slice(-30) + ' @' + m.bpm.toFixed(1));
      chain(); return (idx + 1) + '/' + order.length;
    },
    /* stops EVERYTHING, including sources scheduled for a future time */
    stop() {
      clearTimeout(chainTimer);
      let n = 0; live.forEach(s => { try { s.stop(); n++; } catch (e) {} });
      live.clear(); A = null; B = null; return 'stopped ' + n + ' sources';
    },
    /* last resort — always works, whatever state the graph is in */
    kill() { this.stop(); if (ctx) { try { ctx.close(); } catch (e) {} }
      ctx = null; booted = false; return 'context closed'; },
    pause() { if (!ctx) return 'not started';
      if (ctx.state === 'running') { ctx.suspend(); return 'paused'; }
      ctx.resume(); return 'resumed'; },
    /* ── leaving a track early, without cutting ──────────────────────────
       "I am done with this one" — find the next musical opportunity and
       crossfade out of it, rather than waiting for the exit chain() planned
       at the top of the track or hard-cutting with play().

       Order matters here. The buffer is decoded BEFORE the transition point
       is chosen, because a FLAC decode takes real time and picking the point
       first would put it in the past by the time the audio was ready — which
       lands as a click, not a blend. */
    async blendNow(meta, opts) {
      if (!A || !ctx) return 'nothing playing';
      opts = opts || {};
      let buf;
      try { buf = await LIB.decode(meta, ctx); }
      catch (e) { return 'cannot load: ' + e.message; }
      cancelPending();
      placeNext(meta);
      const out = nextDownbeatAfter(opts.lead != null ? opts.lead : 1.2);
      await chain(out, buf);
      return 'blending in ' + Math.max(0, out - ctx.currentTime).toFixed(1) + 's · ' +
             meta.name.slice(-30);
    },

    /* Change what comes next, leaving the current track to finish as planned.
       Also has to cancel first: the old next deck is already in the graph. */
    async queueNext(meta) {
      if (!A || !ctx) return 'nothing playing';
      let buf;
      try { buf = await LIB.decode(meta, ctx); }
      catch (e) { return 'cannot load: ' + e.message; }
      cancelPending();
      placeNext(meta);
      await chain(undefined, buf);
      return 'next: ' + meta.name.slice(-30);
    },

    /* ── handing the player a whole new order, mid-set ───────────────────
       PATCH 09'S BUG, THIRD OCCURRENCE, and the one the keeper caught by ear:
       "quick blend just seems to sit there."

       Everything that changed what comes next went through placeNext(), which
       mutates `order` IN PLACE — safe precisely because the dashboard holds
       that same array object. A ROUTE is not one track: it splices several
       stepping stones in and re-plans the whole tail, so DWNAV.commitAndRepair
       builds a NEW array. There was no way to give that array to the player,
       so the dashboard assigned it to itself alone. The list showed a route;
       `order` still held the pre-route set; the deck walked the old one. Every
       scenic route and every fast blend was inert in audio and correct on
       screen — which is why it looked like nothing happened.

       Falsifier, and the regression test: DW.nowMeta must be === set[state.idx]
       at all times. Under the bug it stops being, the moment a route commits.

       ADOPTS the caller's array rather than copying into ours, because a copy
       would leave two equal-but-separate arrays and put the desync straight
       back. The playing track must still sit at idx afterwards — otherwise
       state.idx and the deck stop naming the same track, which is the failure
       recorded in chain()'s decode-error note. That is refused, not repaired.

       Re-chains, because chain() committed the next deck the instant this
       track started and that decision predates the new order. `now: true`
       also leaves the current track at the next downbeat — what "⚡ blend
       fast" means, as against "↝ scenic route" which lets it finish. */
    async reorder(seq, opts) {
      opts = opts || {};
      if (!Array.isArray(seq) || !seq.length) return 'refused: empty order';
      if (!A || !ctx) { order = seq; idx = Math.min(idx, seq.length - 1); return 'order replaced · not playing'; }
      if (seq[idx] !== A.track.meta)
        return 'refused: ' + (A.track.meta.name || '?').slice(-30) + ' is playing but is not at index ' + idx;
      order = seq;
      cancelPending();
      const nm = order[idx + 1];
      if (!nm) { await chain(); return 'reordered · nothing after this'; }
      if (!opts.now) { await chain(); return 'reordered · ' + (order.length - idx - 1) + ' ahead'; }
      let buf;
      try { buf = await LIB.decode(nm, ctx); }
      catch (e) { return 'reordered, but cannot load ' + nm.name.slice(-30) + ': ' + e.message; }
      const out = nextDownbeatAfter(opts.lead != null ? opts.lead : 1.2);
      await chain(out, buf);
      return 'reordered · leaving in ' + Math.max(0, out - ctx.currentTime).toFixed(1) + 's · ' +
             (order.length - idx - 1) + ' ahead';
    },

    async skip() { if (idx + 1 < order.length) return this.play(order, idx + 1); return 'end'; },
    async back() { return this.play(order, Math.max(0, idx - 1)); },
    setXfade(s) { xfade = Math.max(2, Math.min(60, s)); return xfade; },
    get state() { return { idx, of: order.length, tempo: Math.round(tempo),
      now: A ? A.track.meta.name : null, next: B ? B.track.meta.name : null,
      live: live.size, ctx: ctx ? ctx.state : 'none' }; },
    get log() { return log; },
    get analyser() { return analyser; },

    /* The META OBJECT on the playing deck, not its name. `state.now` is a
       string and two tracks can share one; identity cannot. Every check that
       the list and the deck still agree is `set[state.idx] === DW.nowMeta`,
       so it has to be the object. */
    get nowMeta() { return A ? A.track.meta : null; },
    get nextMeta() { return B ? B.track.meta : null; },

    /* What the deck is actually doing right now, as against what was planned.
       `rate` is the value at this instant — under a settle ramp it moves, so
       reading A.rate (the value it STARTED at) would be a stale number
       presented as a live one. */
    get deck() {
      if (!A || !ctx) return null;
      const el = Math.max(0, ctx.currentTime - A.startedAt);
      const r = A.rateAt(el), m = A.track.meta;
      return { meta: m, name: m.name, bpm: m.bpm, camelot: m.camelot,
               rate: r, startRate: A.rate, playedBpm: m.bpm * r,
               stretchPct: +((r - 1) * 100).toFixed(2),
               settling: !!A.ramp && el < A.ramp.S,
               settleLeft: A.ramp ? Math.max(0, A.ramp.S - el) : 0,
               dwell: m._dwell || null, stepping: !!m._stepping, elapsed: el };
    },

    /* The floor chain() clamps every dwell to. Exposed so the fast-route menu
       can print the number that will actually be honoured instead of the one
       it asked for — see MIN_PLAY. */
    get dwellFloor() { return MIN_PLAY; },

    /* Live config for the settle ride. Mutable on purpose; see the block at
       the top of the Player for what turning it on changes. */
    get settle() { return settle; },

    /* Seconds into the current track, in context time. The render loop needs
       this to work out when the next blend begins; dash.elapsed was declared
       for it and never assigned by anything, so every countdown was computed
       against zero and never moved. */
    get elapsed() {
      if (!A || !ctx) return 0;
      return Math.max(0, ctx.currentTime - A.startedAt);
    },

    /* WHERE THE NEXT BLEND ACTUALLY IS, read from the schedule rather than
       recomputed from the track length.

       This matters because the two can disagree. chain() picks the exit by
       snapping to a downbeat near the nominal point, and blendNow() rewrites
       A.outAt outright to a downbeat a second or so away. Anything deriving
       the transition from (duration - crossfade) is therefore wrong twice:
       out by the downbeat snap always, and completely wrong the moment a
       blend-now happens. A.outAt is what the gain ramps are scheduled
       against, so it is the only honest source.

       Returns null when nothing is playing or no exit has been scheduled.
       `at` and `dur` are in real seconds of playback, already through the
       stretch rate, so a caller can use them as a fraction directly. */
    get blend() {
      if (!A || !ctx || A.outAt == null) return null;
      const dur = A.when(A.track.meta.dur - A.entry);
      const at = A.outAt - A.startedAt;
      return { in: A.outAt - ctx.currentTime, at, dur, xfade,
               frac: dur > 0 ? Math.max(0, Math.min(1, at / dur)) : 0,
               fadeFrac: dur > 0 ? Math.max(0, Math.min(1, xfade / dur)) : 0 };
    },

    /* Master level, 0..1. Independent of everything else on the machine —
       Web Audio output belongs to this page's AudioContext, so it cannot
       touch other tabs or applications.
       setTargetAtTime rather than a direct assignment: stepping a gain value
       mid-playback clicks. 0.02s is a smoothing constant for the control, not
       a calibration of any signal. */
    /* ── debugging seam. NOT API. ───────────────────────────────────────
       This project was built by injecting code into a running page, and that
       worked because everything hung off window globals. Packaging it into
       modules with private state is what made it a real package — and the
       same move removed the ability to change anything without a reload,
       which costs a playing set every time.

       So: read access to the internals, plus the few setters an externally
       written operation needs to put state back. Enough to compose NEW
       behaviour from outside while audio runs. Not enough to replace chain()
       itself, which would need indirection through a mutable reference — and
       that is a bigger hole than this is worth.

       Two rules:
         Nothing inside this application may ever read _dev. If a feature
         needs something here, expose it properly instead.
         It is unstable by definition. Anything built on it is a session
         experiment, not a change — port it into the module to keep it.

       `live` in particular is private for a reason: the stop button once
       failed because scheduled sources were only reachable through the deck
       pointers, and a source scheduled for the future is reachable no other
       way. Reaching in here means you can recreate that bug by hand. */
    get _dev() {
      return {
        get ctx() { return ctx; }, get master() { return master; },
        get A() { return A; },     get B() { return B; },
        get order() { return order; }, get idx() { return idx; },
        get tempo() { return tempo; }, get xfade() { return xfade; },
        get live() { return live; },
        chain, cancelPending, placeNext, nextDownbeatAfter, makeDeck, downbeatNear,
        setIdx(i) { idx = i; },
        setTempo(t) { tempo = t; },
        setDecks(a, b) { if (a !== undefined) A = a; if (b !== undefined) B = b; }
      };
    },

    get volume() { return volume; },
    set volume(v) {
      v = +v;
      if (!isFinite(v)) return;
      volume = Math.max(0, Math.min(1, v));
      if (master && ctx) master.gain.setTargetAtTime(volume, ctx.currentTime, .02);
      else if (master) master.gain.value = volume;
    }
  };
})();

/* ── public API ────────────────────────────────────────────────────────── */
let corpus = [];
return {
  /* assets.allowCDN = true re-enables runtime fetching of third-party code.
     Off by default on purpose — see the ASSETS comment at the top. */
  assets: ASSETS,
  DB, LIB, Player, analyse, walk, sequence, dedupe, camelot, camScore, normalise, arc,
  get corpus() { return corpus; },

  /* one pick, whole tree, cached — safe to re-run after adding music */
  /* ── adding music ──────────────────────────────────────────────────────
     Everything that brings files in goes through ingest(), and ingest MERGES.
     scan() and LIB.pick() both used to assign corpus = [] and a fresh Map, so
     picking a second folder silently discarded the first — which made "add
     the rest of my library" impossible without a rescan of everything.

     Dedupe is by record id (name|size|lastModified), so re-adding a folder you
     already have costs an IndexedDB hit per track and changes nothing.

     normalise() re-runs across the WHOLE corpus afterwards, not just the new
     records: energy is a constructed index scaled to the corpus min and max,
     so adding material can legitimately move every existing track's figure. */
  async ingest(files, onProgress) {
    await bootEssentia();
    const have = new Set(corpus.map(t => t.id));
    let added = 0, cached = 0, failed = 0, dupe = 0;
    if (!LIB.files) LIB.files = new Map();
    for (let i = 0; i < files.length; i++) {
      if (onProgress) onProgress(i + 1, files.length, files[i].name);
      LIB.files.set(norm(files[i].name), files[i]);
      try {
        const r = await analyse(files[i]);
        if (have.has(r.id)) { dupe++; continue; }
        have.add(r.id); corpus.push(r); added++;
        if (r.cached) cached++;
      } catch (e) { failed++; console.warn(files[i].name, e.message); }
    }
    normalise(corpus);
    return { seen: files.length, added, cached, failed, duplicates: dupe, corpus: corpus.length };
  },

  /* Individual tracks, multi-select. showOpenFilePicker takes many files in
     one gesture; showDirectoryPicker takes exactly one folder, which is a
     browser limitation and not something this can work around. */
  async addFiles(onProgress) {
    if (!window.showOpenFilePicker) throw new Error('showOpenFilePicker unavailable (Chromium only)');
    const handles = await window.showOpenFilePicker({
      multiple: true,
      types: [{ description: 'Audio', accept: { 'audio/*': AUDIO_EXT } }]
    });
    const files = [];
    for (const h of handles) files.push(await h.getFile());
    return this.ingest(files, onProgress);
  },

  /* A drop can carry SEVERAL folders and loose files at once, which is the
     only way to select more than one folder in a single gesture. */
  async addDropped(dataTransfer, onProgress) {
    /* Collect the handle promises SYNCHRONOUSLY, then await them together.
       A DataTransferItemList is only valid during the drop event itself: the
       first await yields, the list is neutered, and every item after the
       first is gone. Awaiting inside this loop meant exactly one file or
       folder ever arrived, however many were dropped. */
    const pending = [];
    for (const item of dataTransfer.items) {
      if (item.kind !== 'file') continue;
      if (item.getAsFileSystemHandle) pending.push(item.getAsFileSystemHandle());
    }
    const roots = (await Promise.all(pending)).filter(Boolean);
    const files = [];
    for (const h of roots) {
      if (h.kind === 'directory') { const f = await walk(h); files.push(...f); }
      else { const f = await h.getFile(); if (AUDIO_RE.test(f.name)) files.push(f); }
    }
    if (!files.length) throw new Error('nothing audio in that drop');
    return this.ingest(files, onProgress);
  },

  /* Start over. Only the in-memory corpus — the IndexedDB analysis cache is
     deliberately untouched, so re-adding is fast and nothing expensive dies. */
  clear() {
    corpus.length = 0; LIB.files = new Map(); LIB.dir = null;
    return 'corpus cleared';
  },

  async scan(onProgress) {
    if (!window.showDirectoryPicker) throw new Error('showDirectoryPicker unavailable (Chromium only)');
    await bootEssentia();
    const dir = await window.showDirectoryPicker({ mode: 'read' });
    const files = await walk(dir);
    LIB.dir = dir;
    const r = await this.ingest(files, onProgress);
    return { files: files.length, analysed: r.corpus, cached: r.cached,
             failed: r.failed, added: r.added, duplicates: r.duplicates };
  },

  /* how much to trust the tempo figures, before anyone quotes them */
  confidence() {
    if (!corpus.length) return 'empty';
    const c = corpus.map(t => t.conf).sort((a, b) => a - b);
    const med = c[c.length >> 1];
    return { median: +med.toFixed(3), weak: corpus.filter(t => t.conf < 1).length,
      strong: corpus.filter(t => t.conf >= 2).length, of: c.length,
      note: 'Essentia scale is 0–5.32; 1.5–3.5 is moderately confident. ' +
            'NOT comparable to any other detector\u2019s confidence number.' };
  },

  build(opts) { return sequence(corpus, opts); },

  /* report BEFORE playing: stretch budget, key quality, runtime */
  inspect(seq) {
    if (!seq || !seq.length) return 'empty';
    let perfect = 0, good = 0, weak = 0, maxS = 0;
    for (let i = 1; i < seq.length; i++) {
      const c = camScore(seq[i - 1].camelot, seq[i].camelot);
      if (c >= .85) perfect++; else if (c >= .45) good++; else weak++;
      maxS = Math.max(maxS, Math.abs((seq[i]._stretch || 1) - 1));
    }
    return { tracks: seq.length,
      runtimeMin: Math.round(seq.reduce((a, t) => a + t.dur, 0) / 60),
      maxStretchPct: +(maxS * 100).toFixed(1),
      tempoStart: seq[0].bpm, tempoEnd: seq[seq.length - 1].bpm,
      energyStart: seq[0].energy, energyPeak: Math.max(...seq.map(t => t.energy)),
      energyEnd: seq[seq.length - 1].energy,
      keyPerfect: perfect, keyGood: good, keyWeak: weak };
  },

  async openLibrary() { return LIB.pick(); },
  async play(seq, from) { return Player.play(seq, from); },
  /* Player has had both of these all along; only the public wrappers were
     missing, so DW.skip / DW.back were undefined on the packaged build even
     though the transport's next button and patch 09's own diagnostic both
     assume they exist. */
  async skip() { return Player.skip(); },
  async back() { return Player.back(); },
  async blendNow(meta, opts) { return Player.blendNow(meta, opts); },
  async queueNext(meta) { return Player.queueNext(meta); },
  async reorder(seq, opts) { return Player.reorder(seq, opts); },
  /* see Player._dev — unstable, for live patching, never read by this app */
  get _dev() { return Player._dev; },
  stop() { return Player.stop(); },
  kill() { return Player.kill(); },
  pause() { return Player.pause(); },
  get state() { return Player.state; },
  /* The engine's own event log — '▶', '→', 'SKIP <reason>', 'end of set'.
     Player has had it all along and nothing could reach it: it was missing
     from this facade AND from _dev, so a track that failed to decode wrote
     its reason into an array with no reader. A silent SKIP is indistinguishable
     from a track that simply never came up. */
  get log() { return Player.log; },
  get elapsed() { return Player.elapsed; },
  get blend() { return Player.blend; },
  get nowMeta() { return Player.nowMeta; },
  get nextMeta() { return Player.nextMeta; },
  get deck() { return Player.deck; },
  get dwellFloor() { return Player.dwellFloor; },
  get settle() { return Player.settle; },

  /* ── does this set actually PLAY? ───────────────────────────────────────
     "Songs with brackets in the title won't load" is a report about a handful
     of tracks, and the engine's answer to a track that will not decode is to
     log one line and splice it out of the order — which is invisible unless
     you are watching the log at the moment it happens.

     This decodes every track in a set for real and returns the failures with
     their messages. Not a pixel count, not a DOM check: the pass condition is
     that decodeAudioData returned a buffer, which is the same call playback
     makes, so a pass here cannot be a pass for the wrong reason.

     It is expensive — it decodes the whole library — so it is a button, not
     a loop. Buffers are dropped immediately; only the verdict is kept. */
  async audit(seq, onProgress) {
    seq = seq && seq.length ? seq : corpus;
    if (!seq.length) return 'nothing to audit';
    const AC = window.AudioContext || window.webkitAudioContext;
    const ctx = new AC({ sampleRate: 44100 });
    const bad = [], ok = [];
    for (let i = 0; i < seq.length; i++) {
      const t = seq[i];
      if (onProgress) onProgress(i + 1, seq.length, t.name);
      const f = LIB.find(t);
      if (!f) { bad.push({ name: t.name, stage: 'find', why: 'no file matches this name' }); continue; }
      let ab;
      try { ab = await f.arrayBuffer(); }
      catch (e) { bad.push({ name: t.name, stage: 'read', why: String(e && e.message || e) }); continue; }
      try {
        const buf = await ctx.decodeAudioData(ab);
        ok.push({ name: t.name, sr: buf.sampleRate, ch: buf.numberOfChannels,
                  dur: +buf.duration.toFixed(1), metaDur: t.dur });
      } catch (e) {
        bad.push({ name: t.name, stage: 'decode', bytes: ab.byteLength,
                   why: String((e && e.message) || e) || (e && e.name) || 'decodeAudioData rejected' });
      }
    }
    try { ctx.close(); } catch (e) {}
    return { checked: seq.length, playable: ok.length, failed: bad.length, failures: bad,
      /* metaDur is the duration ANALYSIS recorded; buf.duration is what the
         decoder just produced. A gap between them means the grid is being
         mapped onto a different length of audio than it was measured on. */
      durationMismatch: ok.filter(r => r.metaDur && Math.abs(r.dur - r.metaDur) > 1)
                          .map(r => ({ name: r.name, decoded: r.dur, analysed: r.metaDur })) };
  },

  get volume() { return Player.volume; },
  set volume(v) { Player.volume = v; }
};
})();
