# Changelog

Versions are recorded here and in the package filename. Earlier packages from
the 2026-08-17 session were overwritten in place and no longer exist — this
file begins the lineage that will be preserved.

## 0.5.0 — 2026-08-17 · fast blends, queue as a list

**Fast blends.** The rolling target advances 35% per *track played*, not per
second — so a stepping stone shifts the tempo the same whether it plays 40
seconds or four minutes. Intermediates in a route now play only long enough to
blend in, hold, and blend out.

Measured from 125 BPM: 151 BPM in **4.0 min** instead of 21.0; 90 BPM in
**7.3 min** instead of 38.5. Same hops, same tempo movement, same 8% gate on
every transition.

**The queue is a list.** Several destinations can be queued, reordered and
removed, each with its own mode. `DWNAV.queue` still returns the head, so the
wayposts panel and route commit needed no changes.

**Queue panel**, bottom left: per-entry tempo ladder, wall-clock estimate,
reorder and remove, and a commit action. Badges distinguish fast, scenic,
direct and forced.

**Superseded:** `deckwave-0.4.0.zip`, preserved.

## 0.4.0 — 2026-08-17 · steering

**Steering a running set.** Clicking a track no longer jumps; it opens a menu
with options that each state their cost.

- **`DWNAV` router.** The rolling target moves 35% toward each track played,
  so a track unreachable now may be reachable after a hop. Getting to a
  destination becomes a shortest-path search with the stretch gate as the edge
  condition. One hop gains at most **3.04%** tempo — derived, not guessed.
- **Wayposts panel.** The corpus as a navigable space: angle is Camelot
  position, radius is log tempo, and the lit annulus is everything the gate
  permits from here. A long harmonic tempo climb draws itself as a spiral.
- **Route commit.** A chosen route is spliced into the set rather than
  intercepted at playback, so the player walks it by construction.
- **Tail repair.** A detour changes the tempo state and breaks the rest of the
  set; `resequenceTail` re-plans it. Verified: zero tracks over the gate.
- **Corpus cache export/restore**, with integrity comparison on restore.

**Bug fixed in this release:** the router, steering menu and panel all shipped
in a state where the queue was populated and **nothing in the playback path
read it.** The feature recorded intentions and discarded them. Caught by the
keeper noticing the set was not walking anywhere.

**Measured:** at 109 BPM on 189 tracks — 123 BPM in 2 hops; 139 BPM in 7 hops
and ~25 min; 79 BPM in 13 hops and ~46 min; 172 BPM genuinely unreachable, the
corpus lacks the rungs.

**Superseded:** `deckwave-0.3.0.zip`, which is preserved.

## 0.3.0 — 2026-08-17 · RECONSTRUCTED

Marked RECONSTRUCTED because it is the surviving state of a package that was
rebuilt in place roughly eight times during a single session. The intermediate
states are gone. Nothing here is uncertain — the contents are known and
verified — but the *history* of the artifact was destroyed and cannot be
recovered.

**Contents:** engine, panel registry with twelve panels, portable score format,
FLAC tag reading, listen mode, now-playing card, single render loop, glossary
with 32 terms and translation export, six themes, saveable named views,
collapsible panels, MEGA layout. `mount()` wires every mixin; the loop starts
once. 21 files, all modules syntax-checked.

**Known unverified:** a cold load of `index.html` has never been tested. All
development ran through live injection into an already-running page.

**Superseded in this release:** nothing preserved. See note above.
