/* ─────────────────────────────────────────────────────────────────────────
   DECKWAVE · DASHBOARD
   The instrument. Five panels, a track list, a transport, and the transport's
   worth of decisions that took a whole session to get right.

   Notes worth keeping, because each one was a bug first:

   · fit() iterates the LIVE canvas map, never a captured array. A stale
     snapshot leaves later-added canvases at the browser's default 300x150
     while stretched across the layout — they draw perfectly into a buffer
     nobody sized, which looks exactly like a broken renderer.

   · Panels reflow by ASPECT RATIO, and the grid can reflow without the window
     ever changing size. So the ResizeObserver watches the panel row and each
     panel, not just the window.

   · Stereo comes from whichever source is live — listen mode, or the deck's
     own analyser split into L/R. An AnalyserNode is a pass-through, so
     splitting from its output is always available. Claiming otherwise was an
     invented constraint that hid a real bug underneath it.

   · Every colour is read from a CSS custom property each frame, so a theme
     change lands on the next frame with no reload.
   ───────────────────────────────────────────────────────────────────────── */

window.DWDASH = (function () {
'use strict';

const PITCH = ['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'];

const CSS = `
:host{all:initial;
  --bg:var(--dw-color-bg,#04010f); --surf:var(--dw-color-surface,#0b0424);
  --line:var(--dw-color-line,#22125c); --txt:var(--dw-color-text,#e6ddff);
  --dim:var(--dw-color-dim,#7d6eb0); --ac:var(--dw-color-accent,#22e8ff);
  --ac2:var(--dw-color-accent-2,#ff2d95); --warn:var(--dw-color-warn,#ffb02e);
  --bad:var(--dw-color-bad,#ff5470); --good:var(--dw-color-good,#3ee68a);
  --fn:var(--dw-font-mono,ui-monospace,Menlo,monospace);
  --glow:var(--dw-glow,1); --scan:var(--dw-scanline-opacity,.26);
  --rad:var(--dw-border-radius,0px);
  display:block;height:100%;font-family:var(--fn);color:var(--txt)}
*{box-sizing:border-box;margin:0}
.app{display:grid;grid-template-columns:1fr minmax(230px,clamp(230px,22vw,340px));
  grid-template-rows:auto 1fr auto;height:100vh;background:var(--bg);gap:1px}
.app::before{content:'';position:fixed;inset:0;pointer-events:none;z-index:99;
  background:repeating-linear-gradient(180deg,transparent 0 2px,rgba(0,0,0,var(--scan)) 2px 3px)}
@media(max-width:720px){.app{grid-template-columns:1fr;grid-template-rows:auto auto 1fr auto}}
.bar{grid-column:1/-1;display:flex;align-items:center;gap:clamp(8px,2vw,22px);
  padding:8px 12px;background:var(--surf);border-bottom:1px solid var(--ac2);flex-wrap:wrap}
.bar h1{font-size:clamp(11px,1.4vw,15px);letter-spacing:.3em;color:var(--ac2);
  text-shadow:0 0 calc(10px*var(--glow)) var(--ac2);font-weight:700}
.kv{display:flex;flex-direction:column;line-height:1.15}
.kv u{text-decoration:none;font-size:7.5px;letter-spacing:.18em;text-transform:uppercase;color:var(--dim)}
.kv b{font-size:clamp(11px,1.3vw,15px);color:var(--ac);font-weight:500;
  text-shadow:0 0 calc(7px*var(--glow)) var(--ac)}
.kv b.p{color:var(--ac2)} .kv b.w{color:var(--warn)} .kv b.g{color:var(--good)}
.main{display:grid;grid-template-rows:auto auto 1fr auto;gap:1px;min-height:0;overflow:hidden}
.strip{background:var(--surf);padding:6px 10px 8px;min-height:0}
.strip>u{display:block;text-decoration:none;font-size:7.5px;letter-spacing:.2em;
  text-transform:uppercase;color:var(--dim);margin-bottom:3px}
canvas{display:block;width:100%;height:100%;background:var(--bg)}
.cw{position:relative;min-height:0;height:calc(100% - 12px)}

/* panels reflow by aspect ratio — five slivers on a square screen is useless */
.tri{display:grid;gap:1px;min-height:0;grid-auto-rows:1fr;overflow:auto;
  grid-template-columns:repeat(5,1fr)}
@media (min-aspect-ratio:2/1){.tri{grid-template-columns:repeat(5,1fr)}}
@media (max-aspect-ratio:2/1) and (min-aspect-ratio:7/5){.tri{grid-template-columns:repeat(3,1fr)}}
@media (max-aspect-ratio:7/5) and (min-aspect-ratio:3/4){.tri{grid-template-columns:repeat(2,1fr)}}
@media (max-aspect-ratio:3/4){.tri{grid-template-columns:1fr}}
@media (max-width:620px){.tri{grid-template-columns:1fr}}
.tri>.strip{min-height:clamp(120px,20vh,260px);display:flex;flex-direction:column}
.tri>.strip>.cw{flex:1;min-height:0}

.side{background:var(--surf);display:flex;flex-direction:column;min-height:0;
  border-left:1px solid var(--line)}
.side>u{display:block;text-decoration:none;font-size:7.5px;letter-spacing:.2em;
  text-transform:uppercase;color:var(--dim);padding:8px 10px 5px;border-bottom:1px solid var(--line)}
.list{flex:1;overflow-y:auto;min-height:0;scrollbar-width:thin;scrollbar-color:var(--line) transparent}
.tr{display:grid;grid-template-columns:26px 1fr auto;gap:6px;padding:4px 8px;font-size:10px;
  border-bottom:1px solid rgba(34,18,92,.5);align-items:center;cursor:pointer}
.tr:hover{background:rgba(127,127,127,.08)}
.tr i{color:var(--dim);font-style:normal;font-size:8.5px}
.tr s{text-decoration:none;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tr em{font-style:normal;color:var(--dim);font-size:8.5px;white-space:nowrap}
.tr.now{background:rgba(255,45,149,.14);border-left:2px solid var(--ac2)}
.tr.now s,.tr.now i,.tr.now em{color:var(--ac2)}
.tr.next{background:rgba(34,232,255,.08)} .tr.next s{color:var(--ac)}
.tr.done s,.tr.done i,.tr.done em{opacity:.4}

.tp{grid-column:1/-1;display:flex;gap:5px;padding:7px 10px;background:var(--surf);
  border-top:1px solid var(--line);flex-wrap:wrap;align-items:center}
button{background:none;border:1px solid var(--line);color:var(--dim);font:inherit;font-size:9px;
  letter-spacing:.14em;text-transform:uppercase;padding:6px 11px;cursor:pointer;border-radius:var(--rad)}
button:hover{border-color:var(--ac);color:var(--ac)}
button.hot{border-color:var(--ac2);color:var(--ac2)}
.sep{width:1px;height:20px;background:var(--line);margin:0 3px}
.split{display:inline-flex;position:relative}
.split .face{border-right:none}
.split .arrow{padding:6px 8px;border-left:1px solid var(--line)}
.split .menu{display:none;position:absolute;bottom:calc(100% + 4px);right:0;min-width:200px;
  background:var(--surf);border:1px solid var(--ac2);box-shadow:0 0 22px rgba(0,0,0,.7);z-index:50}
.split.open .menu{display:block}
.split .menu i{display:block;font-style:normal;padding:8px 11px;font-size:9.5px;letter-spacing:.12em;
  text-transform:uppercase;color:var(--dim);cursor:pointer;border-bottom:1px solid var(--line)}
.split .menu i:last-child{border-bottom:none}
.split .menu i:hover{background:rgba(127,127,127,.12);color:var(--ac)}
.split .menu u{display:block;text-decoration:none;padding:6px 11px;font-size:8px;letter-spacing:.14em;
  text-transform:uppercase;color:var(--dim);opacity:.7;border-bottom:1px solid var(--line)}
.log{margin-left:auto;font-size:9px;color:var(--dim);white-space:nowrap;overflow:hidden;
  text-overflow:ellipsis;max-width:44vw}
.nowline{padding:6px 12px;font-size:10.5px;background:var(--surf);border-bottom:1px solid var(--line);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:none}
.nowline b{color:var(--ac2)}
.app.mini .main>.strip:not(.keep),.app.mini .tri,.app.mini .side{display:none}
.app.mini .nowline{display:block}

/* slots: swap + help controls, revealed on hover */
.strip{position:relative}
.strip>u{display:flex;justify-content:space-between;align-items:center;gap:5px}
.swap,.hbtn{opacity:0;transition:opacity .15s;flex:none;cursor:pointer;border:1px solid var(--line);color:var(--dim)}
.swap{font-size:8px;letter-spacing:.1em;padding:1px 5px;white-space:nowrap}
.hbtn{font-size:9px;width:14px;height:14px;line-height:12px;text-align:center;border-radius:50%;cursor:help}
.strip:hover .swap,.strip:hover .hbtn{opacity:1}
.swap:hover,.hbtn:hover{color:var(--ac);border-color:var(--ac)}
.pmenu{display:none;position:absolute;top:20px;right:6px;min-width:190px;z-index:70;background:var(--surf);
  border:1px solid var(--ac2);box-shadow:0 0 24px rgba(0,0,0,.8);max-height:60vh;overflow:auto}
.pmenu.open{display:block}
.pmenu i{display:flex;justify-content:space-between;align-items:center;font-style:normal;padding:7px 10px;
  font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);cursor:pointer;
  border-bottom:1px solid var(--line)}
.pmenu i:last-child{border-bottom:none}
.pmenu i:hover{background:rgba(127,127,127,.14);color:var(--ac)}
.pmenu i.on{color:var(--ac2);border-left:2px solid var(--ac2)}
.pmenu i b{font-weight:400;font-size:7.5px;opacity:.55;margin-left:8px}
.hcard{display:none;position:absolute;top:20px;left:6px;right:6px;z-index:80;padding:10px 12px;
  background:var(--surf);border:1px solid var(--ac);box-shadow:0 0 26px rgba(0,0,0,.85)}
.hcard.open{display:block}
.hcard h4{font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);margin:0 0 6px;font-weight:500}
.hcard p{font-size:10px;line-height:1.55;color:var(--txt);margin:0 0 8px}
.hcard a{font-size:9px;color:var(--ac2);text-decoration:none;letter-spacing:.08em}
.hcard a:hover{text-decoration:underline}
.hcard em{font-style:normal;font-size:8px;color:var(--dim);display:block;margin-top:4px}
/* manual layout override beats the aspect-ratio media queries */
.app[data-cols="1"] .tri{grid-template-columns:1fr!important}
.app[data-cols="2"] .tri{grid-template-columns:repeat(2,1fr)!important}
.app[data-cols="3"] .tri{grid-template-columns:repeat(3,1fr)!important}
.app[data-cols="5"] .tri{grid-template-columns:repeat(5,1fr)!important}
.app[data-side="hide"] .side{display:none}
.app[data-side="hide"]{grid-template-columns:1fr!important}
.app[data-dense="1"] .tri>.strip{min-height:90px}
.app[data-dense="1"] .strip{padding:3px 6px 4px}
/* dropdown selector used for theme / layout */
.sel{position:relative;display:inline-flex}
.sel>button{min-width:118px;text-align:left}
.sel>button::after{content:'\\25be';float:right;opacity:.7;margin-left:8px}
.sel .menu{display:none;position:absolute;bottom:calc(100% + 4px);left:0;min-width:180px;background:var(--surf);
  border:1px solid var(--ac2);box-shadow:0 0 22px rgba(0,0,0,.75);z-index:60;max-height:52vh;overflow:auto}
.sel.open .menu{display:block}
.sel .menu i{display:flex;justify-content:space-between;align-items:center;font-style:normal;padding:8px 11px;
  font-size:9.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--dim);cursor:pointer;
  border-bottom:1px solid var(--line)}
.sel .menu i:last-child{border-bottom:none}
.sel .menu i:hover{background:rgba(127,127,127,.14);color:var(--ac)}
.sel .menu i.on{color:var(--ac2);border-left:2px solid var(--ac2)}
.sw{display:inline-flex;gap:2px;margin-left:8px}
.sw s{width:9px;height:9px;text-decoration:none;border:1px solid rgba(255,255,255,.25)}

/* header glossary: quiet mouseover, with a bridge so the link stays reachable */
.kv{position:relative;cursor:help}
.kv u{border-bottom:1px dotted transparent;transition:border-color .15s}
.kv:hover u{border-bottom-color:var(--dim)}
.tip{display:none;position:absolute;top:calc(100% + 8px);left:-6px;width:290px;z-index:200;
  padding:10px 12px;background:var(--surf);border:1px solid var(--ac);
  box-shadow:0 0 26px rgba(0,0,0,.85);cursor:default;text-align:left}
.kv:hover .tip,.tip:hover{display:block}
.tip::before{content:'';position:absolute;top:-8px;left:0;right:0;height:8px}
.tip h5{margin:0 0 5px;font-size:9.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);font-weight:500}
.tip p{margin:0 0 7px;font-size:10px;line-height:1.55;color:var(--txt);letter-spacing:0;text-transform:none}
.tip a{font-size:8.5px;color:var(--ac2);text-decoration:none;letter-spacing:.06em}
.tip a:hover{text-decoration:underline}
.tip em{font-style:normal;display:block;margin-top:4px;font-size:7.5px;color:var(--dim)}
@media(max-width:720px){.tip{width:240px;left:auto;right:-6px}}

/* now playing, bottom right */
.np{position:fixed;right:12px;bottom:52px;z-index:150;width:min(320px,42vw);background:var(--surf);
  border:1px solid var(--ac2);box-shadow:0 0 26px rgba(0,0,0,.7);padding:9px 11px;font-size:10px;line-height:1.5}
.np.hidden{display:none}
.np u{display:flex;justify-content:space-between;text-decoration:none;font-size:7.5px;letter-spacing:.2em;
  text-transform:uppercase;color:var(--dim);margin-bottom:5px}
.np u b{cursor:pointer}.np u b:hover{color:var(--ac)}
.np .t{color:var(--ac2);font-size:11.5px;word-break:break-word;margin-bottom:3px}
.np .m{color:var(--dim);font-size:9px;letter-spacing:.08em}
.np .nx{color:var(--dim);font-size:9px;margin-top:6px;padding-top:6px;border-top:1px solid var(--line);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.np .nx s{text-decoration:none;color:var(--ac)}
.np .bar{height:3px;background:var(--line);margin-top:7px}
.np .bar i{display:block;height:100%;width:0;background:var(--ac2);transition:width .3s}
/* help moved onto the panel NAME — a ? on every panel was visual noise */
.lbl{cursor:help;border-bottom:1px dotted transparent;transition:border-color .15s}
.strip:hover .lbl{border-bottom-color:var(--dim)}
.strip .lbl:hover ~ .hcard,.hcard:hover{display:block}
/* collapsible panels */
.strip.collapsed .cw{display:none}
.strip.collapsed{min-height:0!important;height:auto!important}
.fold{font-size:9px;color:var(--dim);cursor:pointer;border:1px solid var(--line);padding:0 5px;
  opacity:0;transition:opacity .15s;flex:none;line-height:13px}
.strip:hover .fold{opacity:1}
.fold:hover{color:var(--ac);border-color:var(--ac)}
/* MEGA — every panel at once. Steps down rather than shattering. */
.app[data-cols="6"] .tri{grid-template-columns:repeat(6,1fr)!important}
.app[data-cols="4"] .tri{grid-template-columns:repeat(4,1fr)!important}
.app[data-cols="mega"] .tri{grid-template-columns:repeat(6,1fr)!important;grid-auto-rows:1fr!important;overflow:hidden}
.app[data-cols="mega"] .tri>.strip{min-height:0!important}
.app[data-cols="mega"] .main{grid-template-rows:auto 1fr!important}
.app[data-cols="mega"] .main>.strip.keep{height:clamp(40px,5vh,70px)!important}
.app[data-cols="mega"] .main>.strip:not(.keep):not(.tri){display:none}
.app[data-cols="mega"] .strip{padding:2px 5px 3px}
.app[data-cols="mega"] .strip>u{font-size:6.5px;margin-bottom:1px}
@media(max-width:1400px){.app[data-cols="mega"] .tri{grid-template-columns:repeat(4,1fr)!important}}
@media(max-width:900px){.app[data-cols="mega"] .tri{grid-template-columns:repeat(3,1fr)!important}}

/* glossary: hover any term. One popup, repositioned, not one per term. */
.gl{border-bottom:1px dotted currentColor;cursor:help;opacity:.95}
.glpop{display:none;position:fixed;z-index:9999;width:min(300px,80vw);padding:10px 12px;
  background:var(--surf);border:1px solid var(--ac);box-shadow:0 0 28px rgba(0,0,0,.9);
  font-size:10px;line-height:1.55;letter-spacing:0;text-transform:none;text-align:left;color:var(--txt)}
.glpop.on{display:block}
.glpop h5{margin:0 0 5px;font-size:9.5px;letter-spacing:.14em;text-transform:uppercase;
  color:var(--ac);font-weight:500}
.glpop a{display:block;margin-top:7px;font-size:8.5px;color:var(--ac2);text-decoration:none}
.glpop a:hover{text-decoration:underline}
.glpop em{font-style:normal;display:block;margin-top:3px;font-size:7.5px;color:var(--dim)}
@media(prefers-reduced-motion:reduce){*{animation:none!important}}
`;

function mount(hostEl) {
  const host = document.createElement('div');
  host.id = 'deckwave';
  host.style.cssText = 'position:fixed;inset:0;z-index:2147483647';
  (hostEl || document.body).appendChild(host);
  const sr = host.attachShadow({ mode: 'open' });
  const st = document.createElement('style'); st.textContent = CSS; sr.appendChild(st);
  const $ = id => sr.getElementById(id);

  const app = document.createElement('div'); app.className = 'app';
  app.innerHTML = `
   <div class="bar" part="header"><h1>DECKWAVE</h1>
     ${[['track','kPos'],['tempo','kBpm'],['key','kKey'],['stretch','kStr'],
        ['bass hits','kHit'],['register','kReg']]
        .map(([l,i]) => `<div class="kv"><u>${l}</u><b id="${i}">-</b></div>`).join('')}
   </div>
   <div class="nowline" id="nowline"></div>
   <div class="main">
     <div class="strip keep" style="height:clamp(70px,11vh,130px)"><u>waveform · scope</u>
       <div class="cw"><canvas id="cScope" part="scope"></canvas></div></div>
     <div class="strip" style="height:clamp(54px,8vh,96px)"><u>bass onsets · spectral flux · last 8s</u>
       <div class="cw"><canvas id="cPunch" part="punchcard"></canvas></div></div>
     <div class="tri" id="tri">
       ${[['spectrum','cSpec'],['pitch classes','cChroma'],['camelot · harmonic path','cCam'],
          ['goniometer · stereo field','cGonio'],['vu · 300ms ballistics','cVU']]
          .map(([l,i]) => `<div class="strip"><u>${l}</u><div class="cw"><canvas id="${i}" part="${i}"></canvas></div></div>`).join('')}
     </div>
     <div class="strip" style="height:clamp(60px,9vh,110px)"><u>set arc · energy + tempo across the whole night</u>
       <div class="cw"><canvas id="cArc" part="arc"></canvas></div></div>
   </div>
   <div class="side"><u id="sideHd">set</u><div class="list" id="list"></div></div>
   <div class="tp" id="tp"><span class="log" id="logLine">ready</span></div>`;
  sr.appendChild(app);

  /* ── canvases ─────────────────────────────────────────────────────── */
  const C = {}, X = {};
  ['cScope','cPunch','cSpec','cChroma','cCam','cGonio','cVU','cArc']
    .forEach(k => { C[k] = $(k); X[k] = C[k].getContext('2d'); });

  /* iterate the LIVE map — a captured array leaves later canvases unsized */
  function fit() {
    const d = window.devicePixelRatio || 1;
    Object.keys(C).forEach(k => {
      const c = C[k]; if (!c) return;
      const r = c.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) return;
      const w = Math.round(r.width * d), h = Math.round(r.height * d);
      if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
      X[k].setTransform(d, 0, 0, d, 0, 0);
    });
  }
  fit();
  let fitT;
  const ro = new ResizeObserver(() => { clearTimeout(fitT); fitT = setTimeout(fit, 60); });
  ro.observe(host); ro.observe($('tri'));
  [...$('tri').children].forEach(c => ro.observe(c));
  addEventListener('resize', () => { clearTimeout(fitT); fitT = setTimeout(fit, 60); });

  const css = k => getComputedStyle(host).getPropertyValue(k).trim();
  const g = (c, col, b) => { const s = parseFloat(css('--glow')); c.shadowBlur = b * (isNaN(s) ? 1 : s); c.shadowColor = col; };
  const W = k => C[k].getBoundingClientRect().width;
  const H = k => C[k].getBoundingClientRect().height;
  const RC = window.DWREGISTER;
  const col = (l, a) => (RC && RC.col(l, a)) || null;

  /* ── state ────────────────────────────────────────────────────────── */
  let set = [], deckL = null, deckR = null, raf = null, lastIdx = -1, lastT = performance.now();
  let wave = null, freq = null, prevLow = null;
  const H2 = 43, fhist = new Float32Array(H2);
  let fi = 0, ff = 0, lastHit = 0; const hits = [];

  /* split the deck's own analyser — a pass-through, so this is always available */
  function splitDeck() {
    const an = window.DW && window.DW.Player.analyser; if (!an || deckL) return false;
    const ctx = an.context, sp = ctx.createChannelSplitter(2);
    deckL = ctx.createAnalyser(); deckL.fftSize = 2048;
    deckR = ctx.createAnalyser(); deckR.fftSize = 2048;
    an.connect(sp); sp.connect(deckL, 0); sp.connect(deckR, 1);
    const sink = ctx.createGain(); sink.gain.value = 0;
    deckL.connect(sink); deckR.connect(sink); sink.connect(ctx.destination);
    return true;
  }
  function stereoSource() {
    const L = window.DWLISTEN;
    if (L && L.active && L.L && L.R) return { L: L.L, R: L.R, src: 'listen' };
    if (deckL && deckR) return { L: deckL, R: deckR, src: 'deck' };
    return null;
  }

  function flux(now) {
    if (!freq) return 0;
    if (!prevLow) { prevLow = new Float32Array(10); for (let i = 0; i < 10; i++) prevLow[i] = freq[i]; return 0; }
    let x = 0;
    for (let i = 0; i < 10; i++) { const d = freq[i] - prevLow[i]; if (d > 0) x += d; prevLow[i] = freq[i]; }
    x /= 2550;
    let m = 0; const n = ff || 1;
    for (let i = 0; i < n; i++) m += fhist[i]; m /= n;
    let hit = false;
    if (ff >= 10 && x > m * 2.0 + 0.004 && now - lastHit > 300) {
      lastHit = now; hits.push({ t: now, v: Math.min(1, x / 0.06) }); hit = true;
    }
    fhist[fi] = x; fi = (fi + 1) % H2; if (ff < H2) ff++;
    return { x, hit };
  }

  /* ── panels ───────────────────────────────────────────────────────── */
  const P = {
    scope(c, w, h, T) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
      if (!wave) { c.strokeStyle = T.line; c.beginPath(); c.moveTo(0, h/2); c.lineTo(w, h/2); c.stroke(); return; }
      const k = col(62) || T.ac; c.strokeStyle = k; c.lineWidth = 1.5; g(c, k, 9); c.beginPath();
      const s = wave.length / w;
      for (let x = 0; x < w; x++) { const v = (wave[Math.floor(x*s)]-128)/128;
        const y = h/2 + v*(h/2-3); x ? c.lineTo(x,y) : c.moveTo(x,y); }
      c.stroke(); c.shadowBlur = 0; },

    punch(c, w, h, T, fx, now) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
      c.strokeStyle = T.line; c.lineWidth = 1;
      for (let i = 1; i < 8; i++) { const x = w*i/8; c.beginPath(); c.moveTo(x,0); c.lineTo(x,h); c.stroke(); }
      c.fillStyle = col(55,.45) || 'rgba(34,232,255,.45)';
      c.fillRect(0, h-2-Math.min(h-4, fx*500), w, 2);
      hits.forEach(p => { const x = w - ((now-p.t)/8000)*w, r = 3 + p.v*(h*.14);
        const k = col(60) || T.ac2; c.fillStyle = k; g(c, k, 13);
        c.beginPath(); c.arc(x, h/2, r, 0, 7); c.fill(); });
      c.shadowBlur = 0; },

    spec(c, w, h, T) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h); if (!freq) return;
      const n = Math.max(16, Math.floor(w/9)), bw = w/n;
      for (let i = 0; i < n; i++) {
        const lo = Math.floor(Math.pow(i/n, 2.2)*freq.length);
        const hb = Math.max(lo+1, Math.floor(Math.pow((i+1)/n, 2.2)*freq.length));
        let m = 0; for (let j = lo; j < hb; j++) m = Math.max(m, freq[j]);
        const bh = (m/255)*(h-3);
        const gr = c.createLinearGradient(0, h, 0, h-bh);
        gr.addColorStop(0, col(52)||T.ac2); gr.addColorStop(1, col(72)||T.ac);
        c.fillStyle = gr; g(c, col(52)||T.ac2, 7); c.fillRect(i*bw+1, h-bh, bw-2, bh); }
      c.shadowBlur = 0; },

    /* twelve pitch CLASSES, not notes — see docs. Folded across all octaves. */
    chroma(c, w, h, T) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h); if (!freq) return;
      const b = new Float32Array(12), N = freq.length*2;
      for (let i = 1; i < freq.length; i++) { const f = i*44100/N;
        if (f < 55 || f > 5000) continue;
        b[((Math.round(69+12*Math.log2(f/440))%12)+12)%12] += freq[i]/255; }
      let mx = 0; for (const v of b) mx = Math.max(mx, v);
      const cx = w/2, cy = h/2, r = Math.min(w,h)/2 - 13;
      for (let i = 0; i < 12; i++) { const a = (i/12)*Math.PI*2 - Math.PI/2, v = mx ? b[i]/mx : 0;
        c.strokeStyle = T.line; c.lineWidth = 1; c.beginPath(); c.moveTo(cx,cy);
        c.lineTo(cx+Math.cos(a)*r, cy+Math.sin(a)*r); c.stroke();
        if (v > .12) { const k = v > .6 ? (col(58)||T.ac2) : (col(70)||T.ac);
          c.strokeStyle = k; c.lineWidth = 3; g(c, k, 10); c.beginPath(); c.moveTo(cx,cy);
          c.lineTo(cx+Math.cos(a)*r*v, cy+Math.sin(a)*r*v); c.stroke(); c.shadowBlur = 0; }
        c.fillStyle = v > .5 ? (col(75)||T.ac) : T.dim;
        c.font = '9px ' + css('--fn'); c.textAlign = 'center'; c.textBaseline = 'middle';
        c.fillText(PITCH[i], cx+Math.cos(a)*(r+8), cy+Math.sin(a)*(r+8)); } },

    cam(c, w, h, T, bass, hit) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
      const s = window.DW.state, cur = set[s.idx], nxt = set[s.idx+1];
      const cx = w/2, cy = h/2, R = Math.min(w,h)/2 - 16, t = performance.now()/1000;
      for (let n = 1; n <= 12; n++) {
        const a = ((n-1)/12)*Math.PI*2 - Math.PI/2 + Math.sin(t*.12)*.02;
        [['A', R*.60], ['B', R]].forEach(([L, rr]) => {
          const code = n + L; let fill = T.line, txt = T.dim, pulse = 0;
          if (cur && cur.camelot === code) { fill = col(58)||T.ac2; txt = T.bg; pulse = 1; }
          else if (nxt && nxt.camelot === code) { fill = col(66,.9)||T.ac; txt = T.bg; pulse = .5; }
          else if (cur) { const sc = window.DW.camScore(cur.camelot, code);
            if (sc >= .85) { fill = col(50,.30)||'rgba(34,232,255,.28)'; txt = col(72)||T.ac; }
            else if (sc >= .45) fill = col(42,.13)||'rgba(34,232,255,.12)'; }
          const x = cx+Math.cos(a)*rr, y = cy+Math.sin(a)*rr;
          const rad = Math.max(6, R*.125)*(1 + pulse*bass*.45 + (pulse&&hit ? .22 : 0));
          c.fillStyle = fill; if (pulse) g(c, fill, 10+pulse*14);
          c.beginPath(); c.arc(x, y, rad, 0, 7); c.fill(); c.shadowBlur = 0;
          c.fillStyle = txt; c.font = Math.max(7, rad*.75)+'px '+css('--fn');
          c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(code, x, y); }); }
      if (cur && nxt) { const pt = cd => { const n = +cd.slice(0,-1), L = cd.slice(-1);
          const a = ((n-1)/12)*Math.PI*2 - Math.PI/2, rr = L === 'A' ? R*.60 : R;
          return [cx+Math.cos(a)*rr, cy+Math.sin(a)*rr]; };
        try { const [x1,y1] = pt(cur.camelot), [x2,y2] = pt(nxt.camelot);
          const k = col(62)||T.ac; c.strokeStyle = k; c.lineWidth = 2; g(c, k, 10);
          c.setLineDash([5,4]); c.lineDashOffset = -t*14;
          c.beginPath(); c.moveTo(x1,y1); c.lineTo(x2,y2); c.stroke();
          c.setLineDash([]); c.shadowBlur = 0; } catch (e) {} } },

    /* L vs R rotated 45deg with phosphor persistence — mono draws vertical */
    gonio(c, w, h, T, L, R, stat) {
      c.fillStyle = 'rgba(0,0,0,0.16)'; c.fillRect(0, 0, w, h);
      const cx = w/2, cy = h/2, r = Math.min(w,h)/2 - 6;
      c.strokeStyle = T.line; c.lineWidth = 1; c.beginPath(); c.arc(cx,cy,r,0,7); c.stroke();
      c.globalAlpha = .5; c.beginPath();
      c.moveTo(cx-r*.72, cy-r*.72); c.lineTo(cx+r*.72, cy+r*.72);
      c.moveTo(cx-r*.72, cy+r*.72); c.lineTo(cx+r*.72, cy-r*.72); c.stroke(); c.globalAlpha = 1;
      if (L && R) { const k = col(66)||T.ac; c.fillStyle = k; g(c, k, 6);
        const n = Math.min(L.length, R.length), step = Math.max(1, Math.floor(n/900));
        for (let i = 0; i < n; i += step) { const a = (L[i]-128)/128, b = (R[i]-128)/128;
          c.fillRect(cx+(a-b)*r*.66, cy-(a+b)*r*.66, 1.4, 1.4); }
        c.shadowBlur = 0; }
      if (stat) { const bw = w*.62, bx = (w-bw)/2, by = h-9, mid = bx+bw/2, x = mid+stat.corr*(bw/2);
        c.fillStyle = T.line; c.fillRect(bx, by, bw, 3);
        const k = stat.corr < 0 ? T.bad : (col(70)||T.ac);
        c.fillStyle = k; g(c, k, 7);
        c.fillRect(Math.min(mid,x), by, Math.abs(x-mid)||1.5, 3); c.shadowBlur = 0;
        c.fillStyle = T.dim; c.font = '7.5px '+css('--fn'); c.textAlign = 'center';
        c.textBaseline = 'bottom'; c.fillText('−1   phase   +1', cx, by-2); } },

    vu(c, w, h, T, s) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
      const cx = w/2, cy = h*.92, r = Math.min(w/2, h)*.86;
      c.strokeStyle = T.line; c.lineWidth = 1;
      c.beginPath(); c.arc(cx, cy, r, Math.PI*1.15, Math.PI*1.85); c.stroke();
      for (let i = 0; i <= 10; i++) { const a = Math.PI*1.15 + (i/10)*Math.PI*.7, over = i > 7;
        c.strokeStyle = over ? T.bad : T.dim; c.lineWidth = over ? 1.6 : 1;
        c.beginPath(); c.moveTo(cx+Math.cos(a)*r, cy+Math.sin(a)*r);
        c.lineTo(cx+Math.cos(a)*r*.88, cy+Math.sin(a)*r*.88); c.stroke(); }
      const needle = (v, pk, off, k) => {
        const a = Math.PI*1.15 + Math.min(1,v)*Math.PI*.7;
        c.strokeStyle = k; c.lineWidth = 2; g(c, k, 9);
        c.beginPath(); c.moveTo(cx+off, cy);
        c.lineTo(cx+off+Math.cos(a)*r*.82, cy+Math.sin(a)*r*.82); c.stroke(); c.shadowBlur = 0;
        const pa = Math.PI*1.15 + Math.min(1,pk)*Math.PI*.7;
        c.fillStyle = k; c.beginPath();
        c.arc(cx+off+Math.cos(pa)*r*.9, cy+Math.sin(pa)*r*.9, 2, 0, 7); c.fill(); };
      needle(s.L, s.pkL, -w*.012, col(68)||T.ac);
      needle(s.R, s.pkR,  w*.012, col(56)||T.ac2);
      c.fillStyle = T.dim; c.font = '7.5px '+css('--fn'); c.textAlign = 'center'; c.fillText('VU', cx, h-2); },

    arc(c, w, h, T) { c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
      if (!set.length) { c.strokeStyle = T.line; c.beginPath(); c.moveTo(0,h/2); c.lineTo(w,h/2); c.stroke(); return; }
      const n = set.length, pad = 3, eY = v => h - pad - v*(h-pad*2);
      const bs = set.map(t => t.bpm), bmin = Math.min(...bs), bmax = Math.max(...bs);
      c.strokeStyle = 'rgba(125,110,176,.45)'; c.lineWidth = 1; c.beginPath();
      set.forEach((t,i) => { const x = (i/(n-1))*w,
        y = h-pad-((t.bpm-bmin)/(bmax-bmin||1))*(h-pad*2); i ? c.lineTo(x,y) : c.moveTo(x,y); });
      c.stroke();
      const gr = c.createLinearGradient(0,0,w,0);
      gr.addColorStop(0, col(70)||T.ac); gr.addColorStop(1, col(56)||T.ac2);
      c.strokeStyle = gr; c.lineWidth = 2; g(c, col(56)||T.ac2, 8); c.beginPath();
      set.forEach((t,i) => { const x = (i/(n-1))*w, y = eY(t.energy); i ? c.lineTo(x,y) : c.moveTo(x,y); });
      c.stroke(); c.shadowBlur = 0;
      const s = window.DW.state;
      if (s.of) { const x = (s.idx/(n-1))*w, k = col(58)||T.ac2;
        c.strokeStyle = k; c.lineWidth = 2; g(c, k, 12);
        c.beginPath(); c.moveTo(x,0); c.lineTo(x,h); c.stroke(); c.shadowBlur = 0;
        c.fillStyle = k; c.beginPath(); c.arc(x, eY(set[s.idx].energy), 4, 0, 7); c.fill(); }
      c.fillStyle = T.dim; c.font = '8px '+css('--fn');
      c.textAlign = 'left'; c.fillText('energy', 4, 10);
      c.textAlign = 'right'; c.fillText(Math.round(bmin)+'-'+Math.round(bmax)+' bpm', w-4, 10); }
  };

  /* ── loop ─────────────────────────────────────────────────────────── */
  function loop() {
    raf = requestAnimationFrame(loop);
    const now = performance.now(), dt = Math.min(.1, (now-lastT)/1000); lastT = now;
    const T = { bg: css('--bg')||'#04010f', surf: css('--surf'), line: css('--line')||'#22125c',
      dim: css('--dim')||'#7d6eb0', ac: css('--ac')||'#22e8ff', ac2: css('--ac2')||'#ff2d95',
      bad: css('--bad')||'#ff5470' };

    const an = (window.DWLISTEN && window.DWLISTEN.active && window.DWLISTEN.analyser)
             || (window.DW && window.DW.Player.analyser);
    if (an) {
      if (!wave || wave.length !== an.fftSize) { wave = new Uint8Array(an.fftSize); freq = new Uint8Array(an.frequencyBinCount); }
      an.getByteTimeDomainData(wave); an.getByteFrequencyData(freq);
      if (RC && RC.mode.on) {
        const r = RC.update(freq);
        host.style.setProperty('--dw-color-accent', 'hsl('+r.hue+',80%,64%)');
        host.style.setProperty('--dw-color-accent-2', 'hsl('+((r.hue+38)%360)+',80%,56%)');
        $('kReg').textContent = r.centroidHz+'Hz '+r.band;
      }
    }
    splitDeck();
    const F = flux(now); const fx = F.x || 0, hit = F.hit || false;
    while (hits.length && now - hits[0].t > 8000) hits.shift();
    let bass = 0; if (freq) { let s = 0; for (let i = 0; i < 12; i++) s += freq[i]; bass = s/12/255; }

    P.scope(X.cScope, W('cScope'), H('cScope'), T);
    P.punch(X.cPunch, W('cPunch'), H('cPunch'), T, fx, now);
    P.spec(X.cSpec, W('cSpec'), H('cSpec'), T);
    P.chroma(X.cChroma, W('cChroma'), H('cChroma'), T);
    P.cam(X.cCam, W('cCam'), H('cCam'), T, bass, hit);

    const S = stereoSource();
    if (S) {
      if (!window.__dwL || window.__dwL.length !== S.L.fftSize) {
        window.__dwL = new Uint8Array(S.L.fftSize); window.__dwR = new Uint8Array(S.R.fftSize); }
      S.L.getByteTimeDomainData(window.__dwL); S.R.getByteTimeDomainData(window.__dwR);
      const stat = window.DWSTEREO(window.__dwL, window.__dwR);
      P.gonio(X.cGonio, W('cGonio'), H('cGonio'), T, window.__dwL, window.__dwR, stat);
      /* feed RAW rms — DWVU does the dBFS conversion. Passing pre-scaled
         values is what railed the needles in the first version. */
      const vs = window.DWVU.feed(stat.rmsL, stat.rmsR, dt);
      P.vu(X.cVU, W('cVU'), H('cVU'), T, vs);
    }
    P.arc(X.cArc, W('cArc'), H('cArc'), T);

    head(hits.length);
    const s = window.DW.state;
    if (s.idx !== lastIdx) { lastIdx = s.idx; renderList(); }
  }

  function head(nHits) {
    const s = window.DW.state, t = set[s.idx];
    $('kPos').textContent = s.of ? ((s.idx+1)+'/'+s.of) : '-';
    $('kBpm').textContent = s.tempo || '-';
    $('kKey').textContent = t ? t.camelot : '-';
    $('kKey').className = 'p';
    const str = t && t._stretch ? (((t._stretch-1)*100).toFixed(1)+'%') : '-';
    $('kStr').textContent = str;
    $('kStr').className = t && Math.abs((t._stretch||1)-1) > .08 ? 'w' : '';
    $('kHit').textContent = nHits; $('kHit').className = 'g';
    const nl = $('nowline');
    if (nl.style.display !== 'none' && t)
      nl.innerHTML = '<b>'+(s.idx+1)+'/'+s.of+'</b> '+clean(t.name).slice(0,44)+' · '+Math.round(t.bpm)+' · '+t.camelot;
  }

  const clean = n => n.replace(/^LukHash\s*-\s*/i,'').replace(/^[^-]+-\s*/,'').replace(/^\d+\s*/,'');

  function renderList() {
    const cur = window.DW.state.idx;
    $('sideHd').textContent = 'set · ' + set.length + ' tracks';
    $('list').innerHTML = set.map((t,i) => {
      const cls = i === cur ? 'now' : (i === cur+1 ? 'next' : (i < cur ? 'done' : ''));
      return `<div class="tr ${cls}" data-i="${i}"><i>${String(i+1).padStart(3,'0')}</i>`
           + `<s>${clean(t.name).slice(0,46)}</s><em>${Math.round(t.bpm)} ${t.camelot}</em></div>`;
    }).join('');
    $('list').querySelectorAll('.tr').forEach(el =>
      el.onclick = async () => { $('logLine').textContent = await window.DW.play(set, +el.dataset.i); });
    const n = $('list').querySelector('.now');
    if (n) n.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }

  /* ── transport ────────────────────────────────────────────────────── */
  const tp = $('tp'), log = m => { $('logLine').textContent = m; };
  const btn = (txt, fn, hot) => { const b = document.createElement('button');
    b.textContent = txt; if (hot) b.className = 'hot'; b.onclick = fn;
    tp.insertBefore(b, $('logLine')); return b; };
  const sep = () => { const s = document.createElement('span'); s.className = 'sep';
    tp.insertBefore(s, $('logLine')); };

  btn('scan', async () => { log('pick your music folder…');
    const r = await window.DW.scan((i,n,nm) => log(i+'/'+n+' '+nm.slice(0,40)));
    log(r.analysed+' analysed · '+r.cached+' cached · '+r.failed+' failed'); }, true);

  btn('build set', () => { if (!window.DW.corpus.length) { log('scan first'); return; }
    set = window.DW.build({ length: 200 }); const i = window.DW.inspect(set); renderList();
    log(i.tracks+' tracks · '+Math.floor(i.runtimeMin/60)+'h'+(i.runtimeMin%60)
        +' · max stretch '+i.maxStretchPct+'%'
        + (i.maxStretchPct > 15 ? ' ⚠ OVER BUDGET' : '')); }, true);

  btn('library', async () => { const n = await window.DW.openLibrary();
    const miss = set.filter(t => !window.DW.LIB.find(t)).length;
    log(n+' files · '+(set.length-miss)+'/'+set.length+' resolvable'+(miss?' · '+miss+' missing':'')); });

  sep();
  btn('▶ play', async () => { if (!set.length) { log('build a set first'); return; }
    if (!window.DW.LIB.files) { log('open the library first'); return; }
    log(await window.DW.play(set, 0)); }, true);
  btn('pause', () => log(window.DW.pause()));
  btn('next ▶', async () => log(await window.DW.skip()));
  btn('■ stop', () => log(window.DW.stop()));
  btn('kill', () => log(window.DW.kill()));

  sep();
  const rc = btn('register colour: off', () => {
    RC.mode.on = !RC.mode.on; rc.textContent = 'register colour: ' + (RC.mode.on?'on':'off');
    rc.className = RC.mode.on ? 'hot' : '';
    if (!RC.mode.on) { ['--dw-color-accent','--dw-color-accent-2'].forEach(k => host.style.removeProperty(k));
      $('kReg').textContent = 'off'; } });

  /* split save: face does the common thing, arrow opens the rest */
  sep();
  const sp = document.createElement('span'); sp.className = 'split';
  sp.innerHTML = `<button class="face hot" id="sFace">▾ download set</button>
    <button class="arrow hot" id="sArrow">▴</button>
    <span class="menu" id="sMenu"><u id="sWhere">no folder · face = download</u>
      <i id="mDl">download now · no dialog</i><i id="mJson">download .json only</i>
      <i id="mAs">save as…</i><i id="mChoose">choose folder…</i><i id="mForget">forget folder</i></span>`;
  tp.insertBefore(sp, $('logLine'));

  const dl = (txt, name, mime) => { const b = new Blob([txt], { type: mime });
    const u = URL.createObjectURL(b), a = document.createElement('a');
    a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(u), 15000); return name; };
  const payload = () => { const sc = window.DWSCORE.score(set, { xfade: 16 });
    const stamp = new Date().toISOString().slice(0,19).replace(/[:T]/g,'-');
    return { sc, json: JSON.stringify(sc, null, 2),
             cue: window.DWSCORE.cue(sc, 'Deckwave'), base: 'deckwave-set-'+stamp }; };

  $('sFace').onclick = () => { if (!set.length) { log('build a set first'); return; }
    const p = payload(); dl(p.json, p.base+'.json', 'application/json');
    setTimeout(() => dl(p.cue, p.base+'.cue', 'text/plain'), 350);
    log('downloaded '+p.base+' · '+p.sc.summary.tracks+' tracks'); };
  $('sArrow').onclick = e => { e.stopPropagation(); sp.classList.toggle('open'); };
  document.addEventListener('click', () => sp.classList.remove('open'));
  sp.onclick = e => e.stopPropagation();
  $('mDl').onclick = () => { sp.classList.remove('open'); $('sFace').click(); };
  $('mJson').onclick = () => { sp.classList.remove('open'); if (!set.length) return;
    const p = payload(); dl(p.json, p.base+'.json', 'application/json'); log('downloaded '+p.base+'.json'); };
  $('mAs').onclick = async () => { sp.classList.remove('open'); if (!set.length) return;
    if (!window.showSaveFilePicker) { $('sFace').click(); return; }
    const p = payload();
    try { const hh = await window.showSaveFilePicker({ suggestedName: p.base+'.json' });
      const wr = await hh.createWritable(); await wr.write(p.json); await wr.close();
      log('saved as '+hh.name); } catch (e) { log('cancelled'); } };
  $('mChoose').onclick = () => { sp.classList.remove('open'); log('folder memory not wired in this build'); };
  $('mForget').onclick = () => { sp.classList.remove('open'); log('no folder set'); };

  btn('▴ load set', () => { const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = '.json';
    inp.onchange = async () => { if (!inp.files[0]) return;
      try { const r = window.DWSCORE.load(await inp.files[0].text(), window.DW.corpus);
        set = r.set; renderList();
        log('loaded '+r.loaded+(r.missing.length ? ' · '+r.missing.length+' missing' : ' · complete'));
      } catch (e) { log('load failed: '+e.message); } };
    inp.click(); });

  sep();
  const THEMES = ['cyberpunk','amber','classic','paper','mono','ice'];
  let ti = 0;
  const tb = btn('theme: cyberpunk', () => { ti = (ti+1) % THEMES.length;
    THEMES.forEach(t => host.classList.remove('dw-theme-'+t));
    host.classList.add('dw-theme-'+THEMES[ti]);
    tb.textContent = 'theme: '+THEMES[ti];
    try { localStorage.setItem('dw-theme', THEMES[ti]); } catch (e) {}
    setTimeout(fit, 60); });
  try { const saved = localStorage.getItem('dw-theme');
    if (saved && THEMES.includes(saved)) { ti = THEMES.indexOf(saved);
      host.classList.add('dw-theme-'+saved); tb.textContent = 'theme: '+saved; } } catch (e) {}

  const mb = btn('– compact', () => { const on = app.classList.toggle('mini');
    host.classList.toggle('mini-host', on);
    $('nowline').style.display = on ? 'block' : 'none';
    mb.textContent = on ? '+ expand' : '– compact'; mb.className = on ? 'hot' : '';
    setTimeout(fit, 60); });

  sep();
  const lb = btn('◉ listen to a tab', async () => {
    if (window.DWLISTEN.active) { window.DWLISTEN.stop();
      lb.textContent = '◉ listen to a tab'; lb.className = ''; log('stopped listening'); return; }
    try { log('pick a tab · tick "Share tab audio"');
      const r = await window.DWLISTEN.tab();
      lb.textContent = '◉ listening'; lb.className = 'hot';
      log('listening to '+r.source.slice(0,40)+' · visuals only, no analysis');
    } catch (e) { log(String(e.message||e)); } });

  /* ── wire everything mount() owns ──────────────────────────────────
     This block is the difference between "the code is saved" and "it runs".
     An earlier package had all the mixins present and never called them:
     a fresh page load gave panels and no view selector. */
  const dash = {
    host, shadow: sr, fit, C, X,
    get set() { return set; }, set set(v) { set = v; renderList(); },
    renderList, header: head, slots: null, views: null, applyFolds: null,
    stereoSource, drawFixed: null, elapsed: 0, theme: 'cyberpunk'
  };

  dash.slots      = DWDASH.slots(dash);       /* swappable panel cells */
  dash.applyFolds = DWDASH.folds(dash);       /* collapse / expand, persisted */
  dash.views      = DWDASH.views(dash);       /* named saveable arrangements */
  DWDASH.glossary(dash);                      /* header term tooltips */
  dash.glossary = DWDASH.glossaryBind(dash);  /* hover any term, anywhere */
  dash.applyFolds();

  if (window.DWNOWPLAYING) window.DWNOWPLAYING.mount(dash);

  /* fixed strips the slots do not own */
  dash.drawFixed = (T, D) => {
    const at = (cid, fn) => { const c = C[cid]; if (!c) return;
      const r = c.getBoundingClientRect();
      if (r.width > 2 && r.height > 2) fn(X[cid], r.width, r.height); };
    at('cScope', (c, w, h) => P.scope(c, w, h, T));
    at('cPunch', (c, w, h) => P.punch(c, w, h, T, D.flux || 0, performance.now()));
    at('cArc',   (c, w, h) => P.arc(c, w, h, T));
  };

  /* One loop, started once. Never wrap it to add a feature — add the feature
     to the bundle it already builds. Wrapping is what killed the last one. */
  if (window.DWLOOP) window.DWLOOP.start(dash); else loop();

  buildTransport(dash);
  return dash;
}

/* ── transport ──────────────────────────────────────────────────────────
   Built after the mixins exist, because half these controls drive them. */
function buildTransport(dash) {
  const sr = dash.shadow, $ = id => sr.getElementById(id), tp = $('tp');
  const log = m => { $('logLine').textContent = m; };
  const btn = (txt, fn, hot) => {
    const b = document.createElement('button');
    b.textContent = txt; if (hot) b.className = 'hot'; b.onclick = fn;
    tp.insertBefore(b, $('logLine')); return b;
  };
  const sep = () => { const s = document.createElement('span');
    s.className = 'sep'; tp.insertBefore(s, $('logLine')); };

  /* a small dropdown, used for layout / theme / views */
  function select(label, items, onPick, current) {
    const wrap = document.createElement('span'); wrap.className = 'sel';
    const b = document.createElement('button');
    const menu = document.createElement('span'); menu.className = 'menu';
    const nameOf = k => (items.find(x => x.k === k) || items[0]).n;
    const paint = () => {
      b.textContent = label + ': ' + nameOf(current);
      menu.innerHTML = '<u>' + label + '</u>' + items.map(x =>
        `<i data-k="${x.k}" class="${x.k === current ? 'on' : ''}">${x.n}`
        + (x.hint ? `<b>${x.hint}</b>` : '') + '</i>').join('');
      menu.querySelectorAll('i').forEach(el => el.onclick = ev => {
        ev.stopPropagation(); current = el.dataset.k;
        wrap.classList.remove('open'); paint(); onPick(current);
      });
    };
    paint();
    b.onclick = e => { e.stopPropagation();
      sr.querySelectorAll('.sel').forEach(o => { if (o !== wrap) o.classList.remove('open'); });
      wrap.classList.toggle('open'); };
    wrap.onclick = e => e.stopPropagation();
    wrap.appendChild(b); wrap.appendChild(menu);
    tp.insertBefore(wrap, $('logLine'));
    return { el: wrap, refresh: paint, set(k) { current = k; paint(); } };
  }
  document.addEventListener('click', () =>
    sr.querySelectorAll('.sel,.pmenu,.hcard').forEach(o => o.classList.remove('open')));

  btn('scan', async () => { log('pick your music folder…');
    const r = await window.DW.scan((i, n, nm) => log(i + '/' + n + ' ' + nm.slice(0, 40)));
    log(r.analysed + ' analysed · ' + r.cached + ' cached · ' + r.failed + ' failed'); }, true);

  btn('build set', () => {
    if (!window.DW.corpus.length) { log('scan first'); return; }
    dash.set = window.DW.build({ length: 200 });
    const i = window.DW.inspect(dash.set);
    log(i.tracks + ' tracks · ' + Math.floor(i.runtimeMin / 60) + 'h' + (i.runtimeMin % 60)
      + ' · max stretch ' + i.maxStretchPct + '%'
      + (i.maxStretchPct > 15 ? ' ⚠ OVER BUDGET' : ''));
  }, true);

  btn('library', async () => { const n = await window.DW.openLibrary();
    const miss = dash.set.filter(t => !window.DW.LIB.find(t)).length;
    log(n + ' files · ' + (dash.set.length - miss) + '/' + dash.set.length + ' resolvable'
      + (miss ? ' · ' + miss + ' missing' : '')); });

  sep();
  btn('▶ play', async () => {
    if (!dash.set.length) { log('build a set first'); return; }
    if (!window.DW.LIB.files) { log('open the library first'); return; }
    log(await window.DW.play(dash.set, 0)); }, true);
  btn('pause', () => log(window.DW.pause()));
  btn('next ▶', async () => log(await window.DW.skip()));
  btn('■ stop', () => log(window.DW.stop()));
  btn('kill', () => log(window.DW.kill()));

  sep();
  const rc = btn('register colour: off', () => {
    const M = window.DWREGISTER.mode; M.on = !M.on;
    rc.textContent = 'register colour: ' + (M.on ? 'on' : 'off');
    rc.className = M.on ? 'hot' : '';
    if (!M.on) ['--dw-color-accent', '--dw-color-accent-2']
      .forEach(k => dash.host.style.removeProperty(k));
  });

  sep();
  btn('▾ save set', () => {
    if (!dash.set.length) { log('build a set first'); return; }
    const sc = window.DWSCORE.score(dash.set, { xfade: 16 });
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    const dl = (txt, name, mime) => { const b = new Blob([txt], { type: mime });
      const u = URL.createObjectURL(b), a = document.createElement('a');
      a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(u), 15000); };
    dl(JSON.stringify(sc, null, 2), 'deckwave-set-' + stamp + '.json', 'application/json');
    setTimeout(() => dl(window.DWSCORE.cue(sc, 'Deckwave'),
      'deckwave-set-' + stamp + '.cue', 'text/plain'), 350);
    log('downloaded · ' + sc.summary.tracks + ' tracks');
  }, true);

  btn('▴ load set', () => {
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.json';
    inp.onchange = async () => { if (!inp.files[0]) return;
      try { const r = window.DWSCORE.load(await inp.files[0].text(), window.DW.corpus);
        dash.set = r.set;
        log('loaded ' + r.loaded + (r.missing.length ? ' · ' + r.missing.length + ' missing' : ' · complete'));
      } catch (e) { log('load failed: ' + e.message); } };
    inp.click();
  });

  sep();
  const app = sr.querySelector('.app');
  select('layout', [
    { k: 'auto', n: 'auto', hint: 'by aspect' },
    { k: 'mega', n: '▪ MEGA · all 12', hint: 'widescreen' },
    { k: '6', n: '6 across' }, { k: '5', n: '5 across' }, { k: '4', n: '4 across' },
    { k: '3', n: '3 across' }, { k: '2', n: '2 × n', hint: 'square' },
    { k: '1', n: 'single column', hint: 'tall' }
  ], k => {
    if (k === 'mega') { log(DWDASH.mega(dash)); return; }
    if (app.getAttribute('data-cols') === 'mega') dash.slots.reset(window.DWPANELS.defaults);
    k === 'auto' ? app.removeAttribute('data-cols') : app.setAttribute('data-cols', k);
    log('layout: ' + k); setTimeout(dash.fit, 80);
  }, 'auto');

  const THEMES = ['cyberpunk','amber','classic','paper','mono','ice'];
  const SWATCH = { cyberpunk:['#04010f','#22e8ff','#ff2d95'], amber:['#0a0600','#ffb02e','#ff7020'],
    classic:['#000000','#00ff41','#ffff00'], paper:['#faf7f0','#2f6f8f','#a8452f'],
    mono:['#0c0c0c','#ffffff','#bbbbbb'], ice:['#020a14','#7fdcff','#c9a6ff'] };
  let theme = 'cyberpunk';
  try { const sv = localStorage.getItem('dw-theme');
    if (sv && THEMES.includes(sv)) theme = sv; } catch (e) {}
  const applyTheme = t => { THEMES.forEach(x => dash.host.classList.remove('dw-theme-' + x));
    dash.host.classList.add('dw-theme-' + t); dash.theme = t;
    try { localStorage.setItem('dw-theme', t); } catch (e) {}
    setTimeout(dash.fit, 60); };
  applyTheme(theme);
  select('theme', THEMES.map(t => ({ k: t, n: t,
    sw: SWATCH[t] })), applyTheme, theme);

  let viewSel;
  const viewItems = () => dash.views.list().map(n => ({ k: n, n }))
    .concat([{ k: '__save', n: '⭳ save current as…' },
             { k: '__reset', n: '↺ reset to default' },
             { k: '__export', n: '⤓ export views' },
             { k: '__import', n: '⤒ import views' }]);
  const onView = k => {
    if (k === '__save') { const n = prompt('Name this view:');
      if (n) { dash.views.save(n); log('saved view “' + n + '”'); rebuildViews(); } return; }
    if (k === '__reset') { dash.slots.reset(window.DWPANELS.defaults);
      setTimeout(() => { dash.applyFolds(); dash.fit(); }, 80); log('views reset'); return; }
    if (k === '__export') { const b = new Blob([dash.views.export()], { type: 'application/json' });
      const u = URL.createObjectURL(b), a = document.createElement('a');
      a.href = u; a.download = 'deckwave-views.json';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(u), 9000); log('views exported'); return; }
    if (k === '__import') { const i = document.createElement('input');
      i.type = 'file'; i.accept = '.json';
      i.onchange = async () => { try { const n = dash.views.import(await i.files[0].text());
        log('imported ' + n + ' views'); rebuildViews(); }
        catch (e) { log('import failed: ' + e.message); } };
      i.click(); return; }
    dash.views.load(k); log('view: ' + k);
  };
  function rebuildViews() { if (viewSel) viewSel.el.remove();
    viewSel = select('view', viewItems(), onView, dash.views.list()[0] || 'default'); }
  if (!dash.views.list().length) dash.views.save('default');
  rebuildViews();

  sep();
  const nb = btn('now playing', () => {
    const on = window.DWNOWPLAYING && window.DWNOWPLAYING.toggle();
    nb.className = on ? 'hot' : ''; });
  nb.className = 'hot';

  const lb = btn('◉ listen to a tab', async () => {
    if (window.DWLISTEN.active) { window.DWLISTEN.stop();
      lb.textContent = '◉ listen to a tab'; lb.className = ''; log('stopped listening'); return; }
    try { log('pick a tab · tick "Share tab audio"');
      const r = await window.DWLISTEN.tab();
      lb.textContent = '◉ listening'; lb.className = 'hot';
      log('listening to ' + r.source.slice(0, 40) + ' · visuals only, no analysis');
    } catch (e) { log(String(e.message || e)); } });
}

return { mount, CSS };
})()


/* ─────────────────────────────────────────────────────────────────────────
   SLOTS — every cell is a swap point.

   Each .tri child is a slot backed by the panel registry. Hovering a panel
   reveals a "?" (explanation + Wikipedia) and a "swap" control. The chosen
   layout persists to localStorage; "reset views" restores DWPANELS.defaults.

   Note the ordering constraint learned the hard way: the grid reflows when a
   slot changes WITHOUT the window ever resizing, so every mutation schedules
   a fit(). A canvas whose buffer was never resized draws perfectly into a
   300x150 nobody sized, which looks exactly like a broken renderer.
   ───────────────────────────────────────────────────────────────────────── */
DWDASH.slots = function (dash) {
  const sr = dash.shadow, tri = sr.querySelector('.tri');
  const KEY = 'dw-slots-v1';
  const slots = [];

  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(slots.map(s => s.panel))); } catch (e) {} };
  const restore = () => { try { const v = JSON.parse(localStorage.getItem(KEY)); return Array.isArray(v) ? v : null; } catch (e) { return null; } };

  function paint(slot) {
    const p = window.DWPANELS.get(slot.panel);
    slot.lbl.textContent = p ? p.label : slot.panel;
    slot.menu.innerHTML = window.DWPANELS.list().map(x =>
      `<i data-k="${x.k}" class="${x.k === slot.panel ? 'on' : ''}">${x.n}${x.hint ? '<b>' + x.hint + '</b>' : ''}</i>`).join('');
    slot.menu.querySelectorAll('i').forEach(el => el.onclick = ev => {
      ev.stopPropagation(); slot.panel = el.dataset.k;
      slot.menu.classList.remove('open'); paint(slot); save();
      setTimeout(dash.fit, 40);
    });
  }

  function help(slot) {
    const w = window.DWPANELS.wiki(slot.panel);
    if (!w) { slot.help.innerHTML = '<p>No reference for this panel.</p>'; return; }
    slot.help.innerHTML =
      `<h4>${w.t}</h4><p>${w.d}</p>` +
      `<a href="${w.u}" target="_blank" rel="noopener">Wikipedia &rarr; ${w.t}</a>` +
      `<em>${w.verified ? 'link verified' : 'article title unverified — opens Wikipedia search'}</em>`;
  }

  function build(defaults) {
    tri.innerHTML = ''; slots.length = 0;
    const want = restore() || defaults;
    want.forEach((pid, i) => {
      if (!window.DWPANELS.has(pid)) pid = defaults[i] || 'spectrum';
      const cid = 'slot' + i;
      const d = document.createElement('div'); d.className = 'strip';
      d.innerHTML = `<u><span class="lbl"></span><span class="hbtn">?</span><span class="swap">swap &#9662;</span></u>`
                  + `<div class="cw"><canvas id="${cid}"></canvas></div>`
                  + `<span class="pmenu"></span><div class="hcard"></div>`;
      tri.appendChild(d);
      const slot = { i, el: d, cid, panel: pid, canvas: d.querySelector('canvas'),
        lbl: d.querySelector('.lbl'), menu: d.querySelector('.pmenu'), help: d.querySelector('.hcard') };
      slot.ctx = slot.canvas.getContext('2d');
      dash.C[cid] = slot.canvas; dash.X[cid] = slot.ctx;
      slots.push(slot); paint(slot);

      d.querySelector('.swap').onclick = e => { e.stopPropagation();
        sr.querySelectorAll('.pmenu').forEach(m => { if (m !== slot.menu) m.classList.remove('open'); });
        slot.menu.classList.toggle('open'); };
      d.querySelector('.hbtn').onclick = e => { e.stopPropagation();
        sr.querySelectorAll('.hcard').forEach(c => { if (c !== slot.help) c.classList.remove('open'); });
        help(slot); slot.help.classList.toggle('open'); };
      d.onclick = e => e.stopPropagation();
      if (dash.ro) dash.ro.observe(d);
    });
    setTimeout(dash.fit, 60);
  }

  document.addEventListener('click', () => {
    sr.querySelectorAll('.pmenu,.hcard').forEach(m => m.classList.remove('open')); });

  build(window.DWPANELS.defaults);

  return {
    build, save, get slots() { return slots; },
    set(i, pid) { if (slots[i] && window.DWPANELS.has(pid)) { slots[i].panel = pid; paint(slots[i]); save(); } },
    reset(d) { try { localStorage.removeItem(KEY); } catch (e) {} build(d || window.DWPANELS.defaults); },
    layout: () => slots.map(s => s.panel)
  };
};


/* ─────────────────────────────────────────────────────────────────────────
   HEADER GLOSSARY — quiet mouseover on each top-bar term.

   Each entry explains what the number means IN THIS SYSTEM, not just the
   general concept, and links to Wikipedia. verified:true was confirmed to
   resolve; the rest use the search URL, same discipline as the panels.
   ───────────────────────────────────────────────────────────────────────── */
DWDASH.TERMS = {
  kPos: { t:'DJ mix', u:'https://en.wikipedia.org/wiki/Special:Search?search=DJ+mix', verified:false,
    d:'Position in the set — which track of how many. Click any row in the list to jump there.' },
  kBpm: { t:'Tempo', u:'https://en.wikipedia.org/wiki/Tempo', verified:false,
    d:'The rolling target in beats per minute. It drifts 35% toward each incoming track rather than holding one fixed BPM, which is how a set can climb 100 → 150 without over-stretching anything.' },
  kKey: { t:'Key (music)', u:'https://en.wikipedia.org/wiki/Key_(music)', verified:false,
    d:'The current key in Camelot notation — 12 numbers, A for minor and B for major. Adjacent numbers are a perfect fifth apart; the same number with the other letter is the relative major or minor.' },
  kStr: { t:'Audio time stretching and pitch scaling', u:'https://en.wikipedia.org/wiki/Audio_time_stretching_and_pitch_scaling', verified:true,
    d:'How far this track is bent from its native tempo, with pitch preserved. Amber past 8%. Beyond roughly 15% the stretch becomes an audible wobble — a perceptual limit, not a preference, which is why the sequencer refuses past 8%.' },
  kHit: { t:'Onset detection', u:'https://en.wikipedia.org/wiki/Special:Search?search=onset+detection+audio', verified:false,
    d:'Bass onsets in the last 8 seconds, found with spectral flux — frame-to-frame positive change in the low bins. It measures CHANGE rather than level, because sidechained music holds bass energy near constant and a loudness threshold never fires.' },
  kReg: { t:'Spectral centroid', u:'https://en.wikipedia.org/wiki/Special:Search?search=spectral+centroid', verified:false,
    d:'The magnitude-weighted mean frequency — the standard measure of perceived brightness. Drives the palette when register colour is on. Heavily damped so it drifts rather than flickers.' }
};

DWDASH.glossary = function (dash) {
  const sr = dash.shadow;
  Object.keys(DWDASH.TERMS).forEach(id => {
    const b = sr.getElementById(id); if (!b) return;
    const kv = b.closest('.kv'); if (!kv || kv.querySelector('.tip')) return;
    const w = DWDASH.TERMS[id];
    const tip = document.createElement('span'); tip.className = 'tip';
    tip.innerHTML = `<h5>${w.t}</h5><p>${w.d}</p>`
      + `<a href="${w.u}" target="_blank" rel="noopener">Wikipedia &rarr; ${w.t}</a>`
      + `<em>${w.verified ? 'link verified' : 'article title unverified — opens Wikipedia search'}</em>`;
    kv.appendChild(tip);
  });
};


/* ─────────────────────────────────────────────────────────────────────────
   VIEWS — a saved view is the whole arrangement, not just the panel list:
   which panels, column count, sidebar state, density, theme, and which
   panels are folded. Exportable so a layout can travel between machines.
   ───────────────────────────────────────────────────────────────────────── */
DWDASH.views = function (dash) {
  const sr = dash.shadow, KEY = 'dw-views-v1', FOLD = 'dw-folded-v1';
  const app = () => sr.querySelector('.app');
  const read = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } };
  const write = o => { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} };
  const folds = () => { try { return JSON.parse(localStorage.getItem(FOLD)) || {}; } catch (e) { return {}; } };

  return {
    list: () => Object.keys(read()),
    snapshot() {
      const a = app();
      return { panels: dash.slots.layout(), cols: a.getAttribute('data-cols') || 'auto',
        side: a.getAttribute('data-side') || 'show', dense: a.getAttribute('data-dense') || '0',
        theme: dash.theme || 'cyberpunk', folded: folds() };
    },
    save(name) { if (!name) return null; const all = read(); all[name] = this.snapshot(); write(all); return name; },
    load(name) {
      const v = read()[name]; if (!v) return null;
      try { localStorage.setItem('dw-slots-v1', JSON.stringify(v.panels)); } catch (e) {}
      try { localStorage.setItem(FOLD, JSON.stringify(v.folded || {})); } catch (e) {}
      dash.slots.build(v.panels);
      const a = app();
      v.cols  === 'auto' ? a.removeAttribute('data-cols')  : a.setAttribute('data-cols', v.cols);
      v.side  === 'show' ? a.removeAttribute('data-side')  : a.setAttribute('data-side', v.side);
      v.dense === '0'    ? a.removeAttribute('data-dense') : a.setAttribute('data-dense', v.dense);
      setTimeout(() => { dash.applyFolds(); dash.fit(); }, 80);
      return name;
    },
    remove(n) { const all = read(); delete all[n]; write(all); return n; },
    export() { return JSON.stringify({ format: 'deckwave-views', version: 1, views: read() }, null, 2); },
    import(j) {
      const d = typeof j === 'string' ? JSON.parse(j) : j;
      if (d.format !== 'deckwave-views') throw new Error('not a deckwave views file');
      const all = read(); Object.assign(all, d.views); write(all);
      return Object.keys(d.views).length;
    }
  };
};

/* MEGA — every registered panel at once, for a widescreen monitor. */
DWDASH.mega = function (dash) {
  try { localStorage.removeItem('dw-folded-v1'); } catch (e) {}
  dash.slots.reset(window.DWPANELS.ALL);
  dash.shadow.querySelector('.app').setAttribute('data-cols', 'mega');
  setTimeout(() => { dash.applyFolds(); dash.fit(); }, 120);
  return window.DWPANELS.ALL.length + ' panels';
};

/* Collapse/expand per panel, persisted by panel id. */
DWDASH.folds = function (dash) {
  const KEY = 'dw-folded-v1';
  const read = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } };
  const write = o => { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} };
  return function apply() {
    const f = read();
    dash.slots.slots.forEach(s => {
      const u = s.el.querySelector('u');
      let btn = u.querySelector('.fold');
      if (!btn) {
        btn = document.createElement('span'); btn.className = 'fold';
        u.insertBefore(btn, u.querySelector('.swap'));
        btn.onclick = e => { e.stopPropagation();
          const st = read(); st[s.panel] = !st[s.panel]; write(st);
          apply(); setTimeout(dash.fit, 60); };
      }
      const on = !!f[s.panel];
      s.el.classList.toggle('collapsed', on);
      btn.textContent = on ? '\u25b8' : '\u25be';
      btn.title = on ? 'expand' : 'collapse';
    });
  };
};


/* ─────────────────────────────────────────────────────────────────────────
   GLOSSARY BINDING — hover any term, get what it means here.

   The tooltips vanished twice before this. Both times the cause was the
   same: help was added by patching slot construction, so any rebuild
   (reset, mega, a layout change) recreated the cells without it.

   The fix is not a better patch. It is that terms live in DWMSG as DATA and
   elements are tagged with data-gl="key", so rebuilding re-tags rather than
   re-creating. Nothing can be dropped because nothing was ever stored in
   the DOM.

   One popup element is reused and repositioned rather than one per term —
   with twelve panels and a dozen header fields that is the difference
   between 1 node and 40.
   ───────────────────────────────────────────────────────────────────────── */
DWDASH.glossaryBind = function (dash) {
  const sr = dash.shadow;
  let pop = sr.getElementById('glpop');
  if (!pop) { pop = document.createElement('div'); pop.className = 'glpop';
    pop.id = 'glpop'; sr.appendChild(pop);
    pop.onmouseenter = () => pop.classList.add('on');
    pop.onmouseleave = () => pop.classList.remove('on'); }

  function show(el, key) {
    const m = window.DWMSG.term(key); if (!m) return;
    pop.innerHTML = '<h5>' + m.t + '</h5>' + m.d
      + (m.w ? '<a href="' + m.w + '" target="_blank" rel="noopener">Wikipedia &rarr; '
        + m.t + '</a><em>' + (m.verified ? window.DWMSG.ui('ui.verified')
        : window.DWMSG.ui('ui.unverified')) + '</em>' : '');
    pop.classList.add('on');
    const r = el.getBoundingClientRect(), pr = pop.getBoundingClientRect();
    let left = r.left, top = r.bottom + 6;
    if (left + pr.width > innerWidth - 8) left = innerWidth - pr.width - 8;
    if (top + pr.height > innerHeight - 8) top = r.top - pr.height - 6;
    pop.style.left = Math.max(8, left) + 'px';
    pop.style.top = Math.max(8, top) + 'px';
  }

  function bind(root) {
    (root || sr).querySelectorAll('[data-gl]').forEach(el => {
      if (el.__glBound) return; el.__glBound = true; el.classList.add('gl');
      el.onmouseenter = () => show(el, el.dataset.gl);
      el.onmouseleave = () => setTimeout(() => {
        if (!pop.matches(':hover')) pop.classList.remove('on'); }, 120);
    });
    return sr.querySelectorAll('[data-gl]').length;
  }

  /* which glossary key each panel and header field maps to */
  const PANEL = { waterfall:'spectrogram', chroma:'chromagram', camelot:'camelot',
    gonio:'goniometer', vu:'vu', transition:'beatmatch', position:'position',
    polygraph:'polygraph', spectrum:'spectrogram', journey:'journey',
    loudness:'lufs', scope:'oscilloscope' };
  const HEAD = { kBpm:'bpm', kKey:'key', kStr:'stretch', kHit:'flux', kReg:'register' };

  function tag() {
    Object.keys(HEAD).forEach(id => {
      const b = sr.getElementById(id); if (!b) return;
      const u = b.closest('.kv') && b.closest('.kv').querySelector('u');
      if (u) u.dataset.gl = HEAD[id];
    });
    dash.slots.slots.forEach(s => {
      const l = s.el.querySelector('.lbl');
      if (l && PANEL[s.panel]) l.dataset.gl = PANEL[s.panel];
    });
    const np = sr.getElementById('npBox');
    if (np) { const order = ['bpm','key','stretch','energy'];
      np.querySelectorAll('.grid u').forEach((u, i) => {
        if (order[i]) u.dataset.gl = order[i]; }); }
    return bind();
  }

  /* re-tag after every rebuild — this is the part that was missing twice */
  const origBuild = dash.slots.build, origReset = dash.slots.reset;
  dash.slots.build = function (d) { const r = origBuild.call(dash.slots, d);
    setTimeout(tag, 60); return r; };
  dash.slots.reset = function (d) { const r = origReset.call(dash.slots, d);
    setTimeout(tag, 80); return r; };

  tag();
  return { tag, bind, show };
};
