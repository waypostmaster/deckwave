/* ─────────────────────────────────────────────────────────────────────────
   DECKWAVE · PANELS
   A panel is (id, label, draw(c, w, h, T, D)) and nothing more.
     T = resolved theme colours + a glow helper + the font
     D = the shared per-frame data bundle (wave, freq, set, state, stereo, vu)
   Panels never touch the render loop; the loop never knows what a panel is.
   Adding a twelfth is one register() call — Butterchurn would drop in here.

   WIKIPEDIA REFERENCES
   Each panel carries a plain-language explanation and a link. Entries marked
   verified:true were confirmed to resolve. The rest use Wikipedia's search
   URL, because guessing an article path and presenting it as fact is a
   failure already in this project's log, and a search never dead-ends.
   ───────────────────────────────────────────────────────────────────────── */

window.DWPANELS = (function () {
'use strict';
const reg = new Map();

const WIKI = {
  scope: { t:'Oscilloscope', u:'https://en.wikipedia.org/wiki/Oscilloscope', verified:false,
    d:'Plots amplitude against time. Vertical is signal level, horizontal is the last few milliseconds.' },
  spectrum: { t:'Spectrum analyzer', u:'https://en.wikipedia.org/wiki/Special:Search?search=spectrum+analyzer', verified:false,
    d:'Splits sound into frequency bands with an FFT. Bass left, treble right. Bars are spaced logarithmically, because hearing is.' },
  waterfall: { t:'Spectrogram', u:'https://en.wikipedia.org/wiki/Spectrogram', verified:false,
    d:'Frequency analysis scrolled over time. Left older, right now, low frequencies at the bottom, brighter means louder. Song structure becomes visible — you can see a drop before it arrives.' },
  chroma: { t:'Chroma feature', u:'https://en.wikipedia.org/wiki/Chroma_feature', verified:true,
    d:'Folds every octave into twelve pitch classes, so all the Cs count as one. Shows where the harmony sits. NOT a piano roll — extracting individual notes from a finished mix is an unsolved research problem.' },
  camelot: { t:'Harmonic mixing', u:'https://en.wikipedia.org/wiki/Special:Search?search=harmonic+mixing+camelot+wheel', verified:false,
    d:'The Camelot wheel: 12 numbers, A minor and B major. Adjacent numbers are a perfect fifth apart; same number different letter is the relative major/minor. Lit circles mix cleanly from here.' },
  gonio: { t:'Goniometer (audio)', u:'https://en.wikipedia.org/wiki/Goniometer_(audio)', verified:true,
    d:'Plots left against right as a Lissajous figure. Vertical means mono; horizontal means out of phase and would cancel in mono. A wide ball means a broad stereo image. The bar below is phase correlation, −1 to +1.' },
  vu: { t:'VU meter', u:'https://en.wikipedia.org/wiki/VU_meter', verified:true,
    d:'Averaging meter with the ANSI ballistic: 300 ms to 99% deflection. That deliberate slowness is why analogue meters read as musical rather than twitchy. The trailing dot is a fast-attack peak hold.' },
  transition: { t:'Beatmatching', u:'https://en.wikipedia.org/wiki/Beatmatching', verified:false,
    d:'Both decks\u2019 beat grids at their played tempo, downbeats as wide bars with bar numbers. Matching periods stay locked; drifting periods separate. Also shows crossfade progress and the bass swap.' },
  position: { t:'Cue (DJ)', u:'https://en.wikipedia.org/wiki/Special:Search?search=DJ+cue+point', verified:false,
    d:'Progress through the current track with beat ticks. The magenta marker is the exit downbeat where the next blend begins.' },
  loudness: { t:'LUFS', u:'https://en.wikipedia.org/wiki/Special:Search?search=LUFS+loudness+units+full+scale', verified:false,
    d:'Perceived loudness over time. Broadcast targets \u221223 LUFS, streaming about \u221214. RELATIVE reading only — proper K-weighting per ITU-R BS.1770 is approximated with a crude shelf, so trends are meaningful but the number is not comparable to a real meter.' },
  journey: { t:'Circle of fifths', u:'https://en.wikipedia.org/wiki/Circle_of_fifths', verified:false,
    d:'Every harmonic move of the set drawn across the Camelot circle. Bright is played, faint is ahead. The Camelot wheel is a relabelling of the circle of fifths.' }
};

/* The default set: one of each kind rather than three flavours of the same.
   time-frequency / harmony / navigation / stereo / mix-state / progress */
const DEFAULTS = ['waterfall','chroma','camelot','gonio','transition','position'];

return {
  register(id, label, draw, opts) {
    reg.set(id, { id, label, draw, note: (opts && opts.note) || '' }); return id;
  },
  get: id => reg.get(id),
  has: id => reg.has(id),
  list: () => [...reg.values()].map(p => ({ k: p.id, n: p.label, hint: p.note })),
  wiki: id => WIKI[id] || null,
  get defaults() { return DEFAULTS.slice(); },
  get size() { return reg.size; }
};
})();

/* ── the four later panels ────────────────────────────────────────────── */

/* SPECTROGRAM — calibrated against a MEASURED distribution, not a guess.
   Real material: p10 -23dB, median -10dB, peak -3.7dB. An earlier -62dB floor
   mapped the median to 0.84 and produced a solid block. Floor -50, ceiling -3,
   gamma 3 to spread the mids. See the saturation table in the build log. */
window.DWPANELS.register('waterfall', 'spectrogram', function (c, w, h, T, D) {
  if (!D.freq) return;
  const FLOOR = -50, CEIL = -3, GAMMA = 3, padL = 26;
  try { const img = c.getImageData(padL + 1, 0, Math.max(1, w - padL - 1), h);
        c.putImageData(img, padL, 0); } catch (e) {}
  const x = w - 1, SR = 44100, N = D.freq.length * 2;
  const FMIN = 40, FMAX = 16000, lmin = Math.log2(FMIN), lspan = Math.log2(FMAX) - lmin;
  for (let y = 0; y < h; y++) {
    const fr = 1 - (y / h), f = Math.pow(2, lmin + fr * lspan);
    const raw = D.freq[Math.min(D.freq.length - 1, Math.max(1, Math.round(f * N / SR)))] / 255;
    const db = raw > 0.0005 ? 20 * Math.log10(raw) : -90;
    let v = Math.pow(Math.max(0, Math.min(1, (db - FLOOR) / (CEIL - FLOOR))), GAMMA);
    if (v < 0.03) c.fillStyle = T.bg;
    else {
      const reg = window.DWREGISTER && window.DWREGISTER.mode;
      const base = (reg && reg.on) ? reg.hue : 225;
      c.fillStyle = 'hsl(' + (base - v * 135).toFixed(0) + ','
        + (40 + v * 50).toFixed(0) + '%,' + (3 + Math.pow(v, 0.6) * 66).toFixed(0) + '%)';
    }
    c.fillRect(x, y, 1, 1);
  }
  c.fillStyle = T.bg; c.fillRect(0, 0, padL, h);
  c.font = '7px ' + T.fn; c.textAlign = 'right'; c.textBaseline = 'middle';
  [[55,'A1'],[110,'A2'],[220,'A3'],[440,'A4'],[880,'A5'],[1760,'A6'],[3520,'A7'],[7040,'A8']]
    .forEach(([fq, lab]) => {
      const fr = (Math.log2(fq) - lmin) / lspan; if (fr < 0 || fr > 1) return;
      const y = h - fr * h;
      c.strokeStyle = T.line; c.globalAlpha = .28; c.lineWidth = 1;
      c.beginPath(); c.moveTo(padL, y); c.lineTo(w, y); c.stroke(); c.globalAlpha = 1;
      c.fillStyle = T.dim; c.fillText(lab, padL - 3, y);
    });
}, { note: 'dB, octave axis' });

/* POLYGRAPH — five pens on ruled chart paper. The lie-detector look, and
   every channel is a real signal rather than decoration. */
window.DWPANELS.register('polygraph', 'polygraph', (function () {
  const CH = ['BASS','MID','HIGH','FLUX','WIDTH'], N = 600;
  let buf = null, i = 0, filled = 0;
  return function (c, w, h, T, D) {
    if (!buf) buf = Array.from({ length: CH.length }, () => new Float32Array(N));
    if (D.freq) {
      const bd = (a, b) => { let s = 0, n = 0;
        for (let k = a; k < b && k < D.freq.length; k++) { s += D.freq[k]; n++; }
        return n ? s / n / 255 : 0; };
      buf[0][i] = bd(0, 12); buf[1][i] = bd(12, 90); buf[2][i] = bd(90, D.freq.length);
      buf[3][i] = Math.min(1, (D.flux || 0) * 14);
      buf[4][i] = D.stereo ? Math.min(1, D.stereo.width * 2.2) : 0;
      i = (i + 1) % N; if (filled < N) filled++;
    }
    c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
    const padL = 42, gw = w - padL - 6, gh = h - 12, rowH = gh / CH.length;
    c.strokeStyle = T.line; c.lineWidth = 1; c.globalAlpha = .55;
    for (let k = 0; k <= CH.length; k++) { const y = 6 + k * rowH;
      c.beginPath(); c.moveTo(padL, y); c.lineTo(w - 6, y); c.stroke(); }
    c.globalAlpha = .25;
    for (let k = 0; k <= 10; k++) { const xx = padL + (k / 10) * gw;
      c.beginPath(); c.moveTo(xx, 6); c.lineTo(xx, h - 6); c.stroke(); }
    c.globalAlpha = 1;
    const cols = [T.ac2, T.ac, '#3ee68a', '#ffb02e', T.ac];
    CH.forEach((name, ci) => {
      const y0 = 6 + ci * rowH, mid = y0 + rowH / 2, amp = rowH * .42;
      c.fillStyle = T.dim; c.font = '7.5px ' + T.fn;
      c.textAlign = 'right'; c.textBaseline = 'middle';
      c.fillText(name, padL - 6, mid);
      c.strokeStyle = cols[ci]; c.lineWidth = 1.3; T.g(c, cols[ci], 6); c.beginPath();
      for (let k = 0; k < filled; k++) {
        const idx = (i + k) % N, x = padL + (k / (filled - 1 || 1)) * gw;
        const y = mid - (buf[ci][idx] - .5) * amp * 2;
        k ? c.lineTo(x, y) : c.moveTo(x, y);
      }
      c.stroke(); c.shadowBlur = 0;
      const last = buf[ci][(i - 1 + N) % N];
      c.fillStyle = cols[ci]; T.g(c, cols[ci], 10);
      c.beginPath(); c.arc(w - 7, mid - (last - .5) * amp * 2, 2.2, 0, 7); c.fill();
      c.shadowBlur = 0;
    });
  };
})(), { note: 'strip chart · 5 pens' });

/* TRACK POSITION — progress with beat ticks and the exit downbeat marked. */
window.DWPANELS.register('position', 'track position', function (c, w, h, T, D) {
  c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
  const t = D.set[D.state.idx];
  if (!t) { c.fillStyle = T.dim; c.font = '9px ' + T.fn; c.textAlign = 'center';
    c.textBaseline = 'middle'; c.fillText('no track playing', w / 2, h / 2); return; }
  const pad = 10, bw = w - pad * 2, y = h / 2;
  const rate = t._stretch || 1, entry = (t.beats && t.beats[0]) || 0;
  const dur = (t.dur - entry) / rate;
  const left = window.__TRANS_LEFT;
  const el = left != null ? Math.max(0, dur - 16 - left) : 0;
  const frac = Math.max(0, Math.min(1, el / dur));
  c.strokeStyle = T.line; c.lineWidth = 1; c.strokeRect(pad, y - 11, bw, 22);
  if (t.beats && t.beats.length) { c.fillStyle = T.line;
    for (let k = 0; k < t.beats.length; k += 16) {
      const f = ((t.beats[k] - entry) / rate) / dur;
      if (f >= 0 && f <= 1) c.fillRect(pad + f * bw, y - 9, 1, 18); } }
  c.fillStyle = T.ac; T.g(c, T.ac, 8); c.fillRect(pad, y - 10, frac * bw, 20); c.shadowBlur = 0;
  const ex = (dur - 16) / dur;
  c.fillStyle = T.ac2; T.g(c, T.ac2, 10);
  c.fillRect(pad + ex * bw - 1, y - 14, 2, 28); c.shadowBlur = 0;
  c.font = '8px ' + T.fn; c.textBaseline = 'middle'; c.fillStyle = T.dim;
  const mmss = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
  c.textAlign = 'left';  c.fillText(mmss(el), pad, y - 20);
  c.textAlign = 'right'; c.fillText('blend at ' + mmss(dur - 16), w - pad, y - 20);
  c.textAlign = 'center'; c.fillStyle = T.ac2;
  c.fillText(t.name.replace(/^[^-]+-\s*/, '').slice(0, 40), w / 2, y + 22);
}, { note: 'progress + exit point' });

/* LOUDNESS — RELATIVE. Proper K-weighting per ITU-R BS.1770 is approximated
   with a crude shelf, so trends are meaningful and the absolute number is NOT
   comparable to a real meter. The panel says so on its face. */
window.DWPANELS.register('loudness', 'loudness', (function () {
  const H = 240; let hist = new Float32Array(H), i = 0, filled = 0;
  return function (c, w, h, T, D) {
    c.fillStyle = T.bg; c.fillRect(0, 0, w, h); if (!D.freq) return;
    let sum = 0, wt = 0; const N = D.freq.length * 2;
    for (let k = 1; k < D.freq.length; k++) {
      const f = k * 44100 / N;
      let g2 = 1;
      if (f < 100) g2 = .25; else if (f > 1000 && f < 4000) g2 = 1.4; else if (f > 10000) g2 = .7;
      const m = D.freq[k] / 255; sum += m * m * g2; wt += g2;
    }
    const rms = Math.sqrt(sum / (wt || 1));
    hist[i] = rms > 0.0001 ? 20 * Math.log10(rms) - 10 : -70;
    i = (i + 1) % H; if (filled < H) filled++;
    let mean = 0; for (let k = 0; k < filled; k++) mean += hist[k]; mean /= (filled || 1);
    const pad = 8, gy = h - 26;
    c.lineWidth = 1;
    [-14, -23].forEach(tgt => {
      const y = gy - ((tgt + 40) / 40) * (gy - pad);
      c.strokeStyle = T.line; c.setLineDash([3, 3]);
      c.beginPath(); c.moveTo(pad, y); c.lineTo(w - pad, y); c.stroke(); c.setLineDash([]);
      c.fillStyle = T.dim; c.font = '7px ' + T.fn;
      c.textAlign = 'left'; c.textBaseline = 'bottom'; c.fillText(tgt + ' LUFS', pad + 2, y - 1);
    });
    c.strokeStyle = T.ac; c.lineWidth = 1.5; T.g(c, T.ac, 7); c.beginPath();
    for (let k = 0; k < filled; k++) {
      const idx = (i + k) % H, x = pad + (k / (filled - 1 || 1)) * (w - pad * 2);
      const y = gy - ((Math.max(-40, Math.min(0, hist[idx])) + 40) / 40) * (gy - pad);
      k ? c.lineTo(x, y) : c.moveTo(x, y);
    }
    c.stroke(); c.shadowBlur = 0;
    c.font = '11px ' + T.fn; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillStyle = mean > -12 ? '#ffb02e' : T.ac;
    c.fillText(mean.toFixed(1) + ' LU · relative', w / 2, h - 12);
  };
})(), { note: 'relative, not true LUFS' });

/* SET JOURNEY — the night's harmonic path across the Camelot circle. */
window.DWPANELS.register('journey', 'set journey', function (c, w, h, T, D) {
  c.fillStyle = T.bg; c.fillRect(0, 0, w, h);
  const S = D.set;
  if (!S.length) { c.fillStyle = T.dim; c.font = '9px ' + T.fn; c.textAlign = 'center';
    c.textBaseline = 'middle'; c.fillText('no set built', w / 2, h / 2); return; }
  const cx = w / 2, cy = h / 2, R = Math.min(w, h) / 2 - 14;
  const pt = cd => { if (!cd || cd === '?') return null;
    const n = +cd.slice(0, -1), L = cd.slice(-1); if (isNaN(n)) return null;
    const a = ((n - 1) / 12) * Math.PI * 2 - Math.PI / 2, rr = L === 'A' ? R * .60 : R;
    return [cx + Math.cos(a) * rr, cy + Math.sin(a) * rr]; };
  c.strokeStyle = T.line; c.lineWidth = 1;
  c.beginPath(); c.arc(cx, cy, R, 0, 7); c.stroke();
  c.beginPath(); c.arc(cx, cy, R * .60, 0, 7); c.stroke();
  const idx = D.state.idx;
  for (let k = 1; k < S.length; k++) {
    const a = pt(S[k - 1].camelot), b = pt(S[k].camelot); if (!a || !b) continue;
    const done = k <= idx;
    c.strokeStyle = done ? T.ac2 : T.line;
    c.lineWidth = done ? 1.4 : .8; c.globalAlpha = done ? .85 : .35;
    c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke();
  }
  c.globalAlpha = 1;
  const cur = pt(S[idx] && S[idx].camelot);
  if (cur) { c.fillStyle = T.ac; T.g(c, T.ac, 12);
    c.beginPath(); c.arc(cur[0], cur[1], 5, 0, 7); c.fill(); c.shadowBlur = 0; }
  c.fillStyle = T.dim; c.font = '8px ' + T.fn;
  c.textAlign = 'center'; c.textBaseline = 'bottom';
  c.fillText((idx + 1) + ' of ' + S.length + ' · harmonic path', cx, h - 4);
}, { note: 'camelot trail' });

/* Every panel, for the MEGA layout. */
window.DWPANELS.ALL = ['waterfall','chroma','camelot','gonio','transition','position',
                       'polygraph','spectrum','journey','loudness','vu','scope'];
