/* DECKWAVE — corpus analysis + beat-locked automatic DJ, in the browser.
   No build step. Load by pasting into the console, or via javascript_exec.

   Pipeline:  scan a folder -> analyse each track (Essentia) -> cache to IndexedDB
              -> sequence by key/tempo/energy -> play beat-locked with lazy decode.

   Everything runs locally. No audio is uploaded, bundled, or fetched.        */

window.DW = (function () {
'use strict';

const CDN = {
  essentiaWasm: 'https://cdn.jsdelivr.net/npm/essentia.js@0.1.3/dist/essentia-wasm.web.js',
  essentiaCore: 'https://cdn.jsdelivr.net/npm/essentia.js@0.1.3/dist/essentia.js-core.js',
  soundtouch:   'https://cdn.jsdelivr.net/npm/@soundtouchjs/audio-worklet/dist/soundtouch-worklet.js',
  flac:         'https://cdn.jsdelivr.net/npm/libflacjs@5.4.0/dist/libflac.min.js'
};
const AC = window.AudioContext || window.webkitAudioContext;
const script = s => new Promise((ok, no) => {
  const e = document.createElement('script'); e.src = s;
  e.onload = () => ok(s); e.onerror = () => no(new Error('load failed: ' + s));
  document.head.appendChild(e);
});
const norm = s => s.toLowerCase().replace(/\.[^.]+$/, '').replace(/[^a-z0-9]/g, '');

/* ── cache ─────────────────────────────────────────────────────────────── */
const DB = (() => {
  let db = null;
  const open = () => new Promise((ok, no) => {
    const r = indexedDB.open('deckwave', 1);
    r.onupgradeneeded = e => { const d = e.target.result;
      if (!d.objectStoreNames.contains('f')) d.createObjectStore('f', { keyPath: 'id' }); };
    r.onsuccess = e => { db = e.target.result; ok(db); };
    r.onerror = () => no(r.error);
  });
  return {
    async get(id) { if (!db) await open(); return new Promise(ok => {
      const t = db.transaction('f', 'readonly').objectStore('f').get(id);
      t.onsuccess = () => ok(t.result || null); t.onerror = () => ok(null); }); },
    async put(rec) { if (!db) await open(); return new Promise(ok => {
      const t = db.transaction('f', 'readwrite').objectStore('f').put(rec);
      t.onsuccess = () => ok(true); t.onerror = () => ok(false); }); },
    async all() { if (!db) await open(); return new Promise(ok => {
      const t = db.transaction('f', 'readonly').objectStore('f').getAll();
      t.onsuccess = () => ok(t.result || []); t.onerror = () => ok([]); }); }
  };
})();

/* ── harmonic mixing ───────────────────────────────────────────────────── */
const CAMELOT_MAJOR = { C:8, G:9, D:10, A:11, E:12, B:1, 'F#':2, Gb:2, Db:3, 'C#':3,
                        Ab:4, 'G#':4, Eb:5, 'D#':5, Bb:6, 'A#':6, F:7 };
const CAMELOT_MINOR = { A:11, E:12, B:1, 'F#':2, Gb:2, Db:3, 'C#':3, Ab:4, 'G#':4,
                        Eb:5, 'D#':5, Bb:6, 'A#':6, F:7, C:8, G:9, D:10 };
function camelot(key, scale) {
  const n = /min/i.test(scale) ? CAMELOT_MINOR[key] : CAMELOT_MAJOR[key];
  return n ? n + (/min/i.test(scale) ? 'A' : 'B') : '?';
}
/* 1.0 identical · .92 adjacent (perfect fifth) · .85 relative · .45 two steps */
function camScore(a, b) {
  if (!a || !b || a === '?' || b === '?') return 0.25;
  if (a === b) return 1;
  const na = +a.slice(0, -1), la = a.slice(-1), nb = +b.slice(0, -1), lb = b.slice(-1);
  if (isNaN(na) || isNaN(nb)) return 0.25;
  if (na === nb) return 0.85;
  const d = Math.min(Math.abs(na - nb), 12 - Math.abs(na - nb));
  if (la === lb && d === 1) return 0.92;
  if (la === lb && d === 2) return 0.45;
  return 0.08;
}

/* ── analysis ──────────────────────────────────────────────────────────── */
let essentia = null;
async function bootEssentia() {
  if (essentia) return essentia;
  await script(CDN.essentiaWasm); await script(CDN.essentiaCore);
  essentia = new Essentia(await EssentiaWASM());
  return essentia;
}

/* Decode, analyse a centred excerpt, DISCARD the buffer. Only features are kept. */
async function analyse(file, excerptSec) {
  const id = file.name + '|' + file.size + '|' + (file.lastModified || 0);
  const hit = await DB.get(id); if (hit) return Object.assign({ cached: true }, hit);

  const ctx = new AC({ sampleRate: 44100 });
  let buf; try { buf = await ctx.decodeAudioData(await file.arrayBuffer()); }
  catch (e) { ctx.close(); throw new Error('decode: ' + e.message); }

  const sr = buf.sampleRate, dur = buf.duration;
  const want = Math.min(dur, excerptSec || 120);
  const start = Math.max(0, Math.floor((dur - want) / 2 * sr));
  const n = Math.floor(want * sr);
  const mono = new Float32Array(n), chs = buf.numberOfChannels;
  for (let c = 0; c < chs; c++) { const d = buf.getChannelData(c);
    for (let i = 0; i < n; i++) mono[i] += d[start + i] / chs; }

  let sum = 0, zc = 0;
  for (let i = 1; i < n; i++) { sum += mono[i] * mono[i];
    if ((mono[i] >= 0) !== (mono[i - 1] >= 0)) zc++; }

  const E = await bootEssentia(), vec = E.arrayToVector(mono);
  let bpm = 0, conf = 0, beats = [], key = '?', scale = '?', kstr = 0;
  try {
    const r = E.RhythmExtractor2013(vec, 208, 'multifeature', 40);
    bpm = r.bpm; conf = r.confidence; beats = E.vectorToArray(r.ticks);
    ['ticks','estimates','bpmIntervals'].forEach(k => { if (r[k] && r[k].delete) r[k].delete(); });
  } catch (e) { console.warn('rhythm', file.name, e); }
  try {
    const k = E.KeyExtractor(vec, true, 4096, 4096, 12, 3500, 60, 25, .2, 'bgate', sr, .0001, 440, 'cosine', 'hann');
    key = k.key; scale = k.scale; kstr = k.strength;
  } catch (e) { console.warn('key', file.name, e); }
  if (vec.delete) vec.delete();
  ctx.close(); buf = null;                                   /* ← the whole point */

  const rec = { id, name: file.name.replace(/\.[^.]+$/, ''),
    bpm: +bpm.toFixed(2), conf: +conf.toFixed(3),
    beats: beats.slice(0, 900).map(x => +x.toFixed(4)),
    key, scale, camelot: camelot(key, scale), kstr: +kstr.toFixed(3),
    rms: Math.sqrt(sum / n), zcr: zc / n, dur: +dur.toFixed(1), size: file.size };
  await DB.put(rec); return rec;
}

async function walk(dir, out, depth) {
  out = out || []; depth = depth || 0; if (depth > 6) return out;
  for await (const e of dir.values()) {
    if (e.kind === 'file') { if (/\.(flac|mp3|wav|aiff|m4a|ogg)$/i.test(e.name)) out.push(await e.getFile()); }
    else if (e.kind === 'directory') await walk(e, out, depth + 1);
  } return out;
}

/* Energy is a CONSTRUCTED INDEX, normalised across the corpus — not a measurement. */
function normalise(corpus) {
  if (!corpus.length) return corpus;
  const R = corpus.map(t => t.rms), Z = corpus.map(t => t.zcr);
  const lo = Math.min(...R), hi = Math.max(...R), zl = Math.min(...Z), zh = Math.max(...Z);
  corpus.forEach(t => {
    const r = hi > lo ? (t.rms - lo) / (hi - lo) : .5;
    const z = zh > zl ? (t.zcr - zl) / (zh - zl) : .5;
    const b = Math.min(1, Math.max(0, (t.bpm - 90) / 70));
    t.energy = +(r * .45 + z * .25 + b * .30).toFixed(3);
  });
  return corpus;
}

/* ── sequencing ────────────────────────────────────────────────────────── */
/* Rise to ~72% of the set, peak, gentle release. */
const arc = (i, n) => { const p = i / (n - 1 || 1);
  return p < .72 ? (.22 + p / .72 * .62) : (.84 - (p - .72) / .28 * .30); };

/* Same track on an album AND a single is one track. Strip artist and album prefixes. */
function dedupe(corpus) {
  const key = t => t.name.toLowerCase()
    .replace(/^[^-]+-\s*/, '').replace(/^[^-]+-\s*/, '')
    .replace(/^\d+\s*/, '').replace(/[^a-z0-9]/g, '');
  const seen = new Map();
  for (const t of corpus) { const k = key(t); if (!k) continue;
    if (!seen.has(k) || seen.get(k).conf < t.conf) seen.set(k, t); }
  return [...seen.values()];
}

/* Rolling tempo: the target DRIFTS with the set rather than being fixed.
   A hard gate refuses any track needing more stretch than maxStretch.
   The sequence stops short rather than degrading — that is intended. */
function sequence(corpus, opts) {
  opts = opts || {};
  const maxStretch = opts.maxStretch != null ? opts.maxStretch : 0.08;
  const minConf = opts.minConf != null ? opts.minConf : 0.8;
  const pool = dedupe(corpus).filter(t => t.bpm > 60 && t.dur > 75 && t.conf > minConf);
  if (!pool.length) return [];
  const n = Math.min(opts.length || pool.length, pool.length);
  const w = Object.assign({ key: .30, tempo: .30, energy: .40 }, opts.weights);

  const used = new Set();
  let cur = pool.slice().sort((a, b) =>
    Math.abs(a.energy - arc(0, n)) - Math.abs(b.energy - arc(0, n)))[0];
  used.add(cur.id); const out = [cur]; let tempo = cur.bpm;

  for (let i = 1; i < n; i++) {
    const want = arc(i, n); let best = null, bs = -1;
    for (const t of pool) {
      if (used.has(t.id)) continue;
      const stretch = Math.abs(tempo / t.bpm - 1);
      if (stretch > maxStretch) continue;                    /* ← the gate */
      const s = camScore(cur.camelot, t.camelot) * w.key
              + (1 - stretch / maxStretch) * w.tempo
              + (1 - Math.min(1, Math.abs(t.energy - want) / .30)) * w.energy;
      if (s > bs) { bs = s; best = t; }
    }
    if (!best) break;
    used.add(best.id); best._score = +bs.toFixed(3);
    best._stretch = +(tempo / best.bpm).toFixed(3); best._tempoAt = Math.round(tempo);
    out.push(best); tempo += (best.bpm - tempo) * (opts.drift || 0.35); cur = best;
  }
  return out;
}

/* ── library: directory handle retained, files resolved lazily ─────────── */
const LIB = { dir: null, files: null,
  async pick() {
    if (!window.showDirectoryPicker) throw new Error('showDirectoryPicker unavailable (Chromium only)');
    this.dir = await window.showDirectoryPicker({ mode: 'read' });
    const f = await walk(this.dir); this.files = new Map();
    for (const x of f) this.files.set(norm(x.name), x);
    return this.files.size;
  },
  find(meta) { return this.files ? this.files.get(norm(meta.name)) : null; },
  async decode(meta, ctx) {
    const f = this.find(meta);
    if (!f) throw new Error('missing file: ' + meta.name.slice(-32));
    return ctx.decodeAudioData(await f.arrayBuffer());
  }
};

/* ── player ────────────────────────────────────────────────────────────── */
const Player = (() => {
  let ctx = null, master = null, analyser = null, booted = false;
  let A = null, B = null, order = [], idx = 0, tempo = 0, xfade = 16;
  let chainTimer = null;
  const log = [];
  /* EVERY scheduled source lands here. stop() iterates this, not the deck
     pointers — a source scheduled for the future is not reachable any other way,
     which is exactly how the first stop button failed. */
  const live = new Set();

  async function boot() {
    if (booted) return;
    ctx = new AC({ sampleRate: 44100 });
    await ctx.audioWorklet.addModule(CDN.soundtouch);
    master = ctx.createGain(); master.gain.value = .85;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -12; comp.ratio.value = 4;
    master.connect(comp); comp.connect(ctx.destination);
    analyser = ctx.createAnalyser(); analyser.fftSize = 2048; analyser.smoothingTimeConstant = .7;
    /* an analyser in a dead-end branch is not reliably pulled — give it a silent sink */
    const sink = ctx.createGain(); sink.gain.value = 0;
    master.connect(analyser); analyser.connect(sink); sink.connect(ctx.destination);
    booted = true;
  }

  function makeDeck(track, rate) {
    const src = ctx.createBufferSource(); src.buffer = track.buf;
    const st = new AudioWorkletNode(ctx, 'soundtouch-processor');
    st.parameters.get('tempo').value = rate;          /* speed without pitch change */
    const lo = ctx.createBiquadFilter(); lo.type = 'lowshelf';  lo.frequency.value = 200;
    const mid = ctx.createBiquadFilter(); mid.type = 'peaking'; mid.frequency.value = 1000; mid.Q.value = .8;
    const hi = ctx.createBiquadFilter(); hi.type = 'highshelf'; hi.frequency.value = 4000;
    const g = ctx.createGain(); g.gain.value = 0;
    src.connect(st); st.connect(lo); lo.connect(mid); mid.connect(hi); hi.connect(g); g.connect(master);
    live.add(src); src.onended = () => live.delete(src);
    return { src, st, lo, mid, hi, g, track, rate };
  }

  function downbeatNear(beats, t) {
    let best = t, d = Infinity;
    for (let i = 0; i < beats.length; i += 4) {
      const dd = Math.abs(beats[i] - t); if (dd < d) { d = dd; best = beats[i]; } }
    return best;
  }

  async function chain() {
    if (!A) return;
    const m = A.track.meta, k = 1 / A.rate;
    const beats = (m.beats || []).map(b => (b - A.entry) * k);
    const playFor = Math.max(45, ((m.dur - A.entry) * k) - xfade);
    const exit = beats.length ? downbeatNear(beats, playFor) : playFor;
    const out = A.startedAt + exit; A.outAt = out;

    A.g.gain.setValueAtTime(1, out);
    A.g.gain.linearRampToValueAtTime(0, out + xfade);
    /* bass swap — only one kick and one bassline sounds at a time */
    A.lo.gain.setValueAtTime(0, out);
    A.lo.gain.linearRampToValueAtTime(-30, out + xfade * .45);
    A.src.stop(out + xfade + .4);

    const ni = idx + 1;
    if (ni >= order.length) { log.unshift('end of set'); return; }
    const nm = order[ni];
    let buf; try { buf = await LIB.decode(nm, ctx); }
    catch (e) { log.unshift('SKIP ' + e.message); idx = ni; return chain(); }

    const rate = tempo / nm.bpm;
    const nd = makeDeck({ meta: nm, buf }, rate);
    nd.entry = (nm.beats || [0])[0] || 0;
    nd.g.gain.setValueAtTime(0, out);
    nd.g.gain.linearRampToValueAtTime(1, out + xfade * .6);
    nd.lo.gain.setValueAtTime(-30, out);
    nd.lo.gain.linearRampToValueAtTime(0, out + xfade * .55);
    nd.src.start(out, nd.entry); nd.startedAt = out;
    B = nd;
    log.unshift('→ ' + nm.name.slice(-30) + ' ×' + rate.toFixed(3) + ' ' + nm.camelot);
    if (log.length > 60) log.pop();
    tempo += (nm.bpm - tempo) * .35;

    clearTimeout(chainTimer);
    chainTimer = setTimeout(() => {
      if (A) A.track.buf = null;                       /* release behind */
      idx = ni; A = B; B = null; chain();
    }, (out - ctx.currentTime) * 1000 + 100);
  }

  return {
    async play(seq, from) {
      await boot(); await ctx.resume(); this.stop();
      order = seq; idx = from || 0;
      const m = order[idx], buf = await LIB.decode(m, ctx);
      tempo = m.bpm;
      const d = makeDeck({ meta: m, buf }, 1);
      d.entry = (m.beats || [0])[0] || 0;
      const t0 = ctx.currentTime + .35;
      d.g.gain.setValueAtTime(0, t0); d.g.gain.linearRampToValueAtTime(1, t0 + 1);
      d.src.start(t0, d.entry); d.startedAt = t0;
      A = d; B = null;
      log.unshift('▶ ' + m.name.slice(-30) + ' @' + m.bpm.toFixed(1));
      chain(); return (idx + 1) + '/' + order.length;
    },
    /* stops EVERYTHING, including sources scheduled for a future time */
    stop() {
      clearTimeout(chainTimer);
      let n = 0; live.forEach(s => { try { s.stop(); n++; } catch (e) {} });
      live.clear(); A = null; B = null; return 'stopped ' + n + ' sources';
    },
    /* last resort — always works, whatever state the graph is in */
    kill() { this.stop(); if (ctx) { try { ctx.close(); } catch (e) {} }
      ctx = null; booted = false; return 'context closed'; },
    pause() { if (!ctx) return 'not started';
      if (ctx.state === 'running') { ctx.suspend(); return 'paused'; }
      ctx.resume(); return 'resumed'; },
    async skip() { if (idx + 1 < order.length) return this.play(order, idx + 1); return 'end'; },
    async back() { return this.play(order, Math.max(0, idx - 1)); },
    setXfade(s) { xfade = Math.max(2, Math.min(60, s)); return xfade; },
    get state() { return { idx, of: order.length, tempo: Math.round(tempo),
      now: A ? A.track.meta.name : null, next: B ? B.track.meta.name : null,
      live: live.size, ctx: ctx ? ctx.state : 'none' }; },
    get log() { return log; },
    get analyser() { return analyser; }
  };
})();

/* ── public API ────────────────────────────────────────────────────────── */
let corpus = [];
return {
  DB, LIB, Player, analyse, walk, sequence, dedupe, camelot, camScore, normalise, arc,
  get corpus() { return corpus; },

  /* one pick, whole tree, cached — safe to re-run after adding music */
  async scan(onProgress) {
    if (!window.showDirectoryPicker) throw new Error('showDirectoryPicker unavailable (Chromium only)');
    await bootEssentia();
    const dir = await window.showDirectoryPicker({ mode: 'read' });
    const files = await walk(dir);
    corpus = []; let cached = 0, failed = 0;
    for (let i = 0; i < files.length; i++) {
      if (onProgress) onProgress(i + 1, files.length, files[i].name);
      try { const r = await analyse(files[i]); if (r.cached) cached++; corpus.push(r); }
      catch (e) { failed++; console.warn(files[i].name, e.message); }
    }
    normalise(corpus);
    LIB.dir = dir; LIB.files = new Map();
    for (const f of files) LIB.files.set(norm(f.name), f);
    return { files: files.length, analysed: corpus.length, cached, failed };
  },

  /* how much to trust the tempo figures, before anyone quotes them */
  confidence() {
    if (!corpus.length) return 'empty';
    const c = corpus.map(t => t.conf).sort((a, b) => a - b);
    const med = c[c.length >> 1];
    return { median: +med.toFixed(3), weak: corpus.filter(t => t.conf < 1).length,
      strong: corpus.filter(t => t.conf >= 2).length, of: c.length,
      note: 'Essentia scale is 0–5.32; 1.5–3.5 is moderately confident. ' +
            'NOT comparable to any other detector\u2019s confidence number.' };
  },

  build(opts) { return sequence(corpus, opts); },

  /* report BEFORE playing: stretch budget, key quality, runtime */
  inspect(seq) {
    if (!seq || !seq.length) return 'empty';
    let perfect = 0, good = 0, weak = 0, maxS = 0;
    for (let i = 1; i < seq.length; i++) {
      const c = camScore(seq[i - 1].camelot, seq[i].camelot);
      if (c >= .85) perfect++; else if (c >= .45) good++; else weak++;
      maxS = Math.max(maxS, Math.abs((seq[i]._stretch || 1) - 1));
    }
    return { tracks: seq.length,
      runtimeMin: Math.round(seq.reduce((a, t) => a + t.dur, 0) / 60),
      maxStretchPct: +(maxS * 100).toFixed(1),
      tempoStart: seq[0].bpm, tempoEnd: seq[seq.length - 1].bpm,
      energyStart: seq[0].energy, energyPeak: Math.max(...seq.map(t => t.energy)),
      energyEnd: seq[seq.length - 1].energy,
      keyPerfect: perfect, keyGood: good, keyWeak: weak };
  },

  async openLibrary() { return LIB.pick(); },
  async play(seq, from) { return Player.play(seq, from); },
  stop() { return Player.stop(); },
  kill() { return Player.kill(); },
  pause() { return Player.pause(); },
  get state() { return Player.state; }
};
})();
