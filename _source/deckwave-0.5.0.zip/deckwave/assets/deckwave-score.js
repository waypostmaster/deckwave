/* ─────────────────────────────────────────────────────────────────────────
   DECKWAVE · SCORE
   A mix expressed as executable data rather than rendered audio.

   The premise: nothing about the mix is improvised. The sequence comes from
   measured features, the entry points from beat grids, the tempo multipliers
   from arithmetic. "Live" is only when it runs. So the mix is not a recording
   to capture — it is a score, and a score can be written down.

   Roughly 26KB describes a 197-minute set. The FLAC would be 3GB and would
   preserve only the sound. This preserves the HOW.

   DETERMINISM — read this before quoting the claim.
   Reproducibility depends on identical Essentia/WASM builds, identical decode
   paths, and stable analysis across browser versions. This is the same problem
   tracker modules have always had: no normative spec means the same file can
   sound different in different players. The engine block MITIGATES that by
   declaring what produced the mix. It does not eliminate it, and cross-browser
   determinism has NOT been tested. State the claim with that attached.
   ───────────────────────────────────────────────────────────────────────── */

window.DWSCORE = (function () {
'use strict';

/* every 4th beat, assumed — there is no downbeat detection here (see WISDOM) */
function downbeatNear(beats, t) {
  let best = t, d = Infinity;
  for (let i = 0; i < beats.length; i += 4) {
    const dd = Math.abs(beats[i] - t);
    if (dd < d) { d = dd; best = beats[i]; }
  }
  return best;
}

/* Walk the set exactly as the player will, recording every decision. */
function plan(set, opts) {
  opts = opts || {};
  const XF = opts.xfade || 16, drift = opts.drift || 0.35;
  const out = [];
  let tempo = set[0].bpm, clock = 0;

  set.forEach((m, i) => {
    const rate = i === 0 ? 1 : tempo / m.bpm;
    const entry = (m.beats || [0])[0] || 0;
    const k = 1 / rate;
    const beats = (m.beats || []).map(b => (b - entry) * k);
    const playFor = Math.max(45, ((m.dur - entry) * k) - XF);
    const exit = beats.length ? downbeatNear(beats, playFor) : playFor;

    out.push({
      i, name: m.name,
      bpm: +m.bpm.toFixed(2), camelot: m.camelot, key: m.key + ' ' + m.scale,
      energy: m.energy, conf: m.conf,
      rate: +rate.toFixed(4), stretchPct: +((rate - 1) * 100).toFixed(2),
      entrySec: +entry.toFixed(3), exitSec: +exit.toFixed(3),
      atSec: +clock.toFixed(2),
      xfadeSec: XF, bassSwapSec: +(XF * 0.45).toFixed(2),
      durSec: m.dur
    });
    clock += exit;
    tempo += (m.bpm - tempo) * drift;
  });
  return out;
}

function score(set, opts) {
  opts = opts || {};
  const steps = plan(set, opts);
  const last = steps[steps.length - 1];
  const total = last.atSec + last.exitSec + (opts.xfade || 16);
  return {
    format: 'deckwave-set', version: 1,
    generated: new Date().toISOString(),
    engine: {
      sequencer: 'rolling-tempo target, camelot + energy arc, hard stretch gate',
      drift: opts.drift || 0.35,
      xfadeSec: opts.xfade || 16,
      maxStretch: opts.maxStretch || 0.08,
      detector: 'essentia.js RhythmExtractor2013 multifeature',
      keyDetector: 'essentia.js KeyExtractor',
      stretch: 'SoundTouchJS AudioWorklet (tempo param, pitch preserved)',
      transition: 'downbeat-aligned crossfade with 3-band bass swap',
      downbeat: 'assumed every 4th beat from first — no downbeat detection',
      determinism: 'depends on identical engine builds; NOT cross-browser tested'
    },
    summary: {
      tracks: steps.length, runtimeSec: Math.round(total),
      tempoStart: steps[0].bpm, tempoEnd: last.bpm,
      maxStretchPct: +Math.max(...steps.map(s => Math.abs(s.stretchPct))).toFixed(2)
    },
    steps
  };
}

/* Standard .cue — opens in VLC, foobar2000, most players. */
function cue(sc, title) {
  const t = s => {
    const m = Math.floor(s / 60), ss = Math.floor(s % 60), f = Math.round((s % 1) * 75);
    return [m, ss, f].map(x => String(x).padStart(2, '0')).join(':');
  };
  let o = 'REM DECKWAVE SET — ' + sc.summary.tracks + ' tracks, ' +
          Math.round(sc.summary.runtimeSec / 60) + ' min\n';
  o += 'REM ENGINE ' + sc.engine.detector + ' / ' + sc.engine.stretch + '\n';
  o += 'REM GENERATED ' + sc.generated + '\n';
  o += 'TITLE "' + (title || 'Deckwave Set') + '"\nFILE "mix.flac" WAVE\n';
  sc.steps.forEach((s, i) => {
    o += '  TRACK ' + String(i + 1).padStart(2, '0') + ' AUDIO\n';
    o += '    TITLE "' + s.name.replace(/"/g, "'") + '"\n';
    o += '    REM BPM ' + s.bpm + ' KEY ' + s.camelot +
         ' RATE ' + s.rate + ' STRETCH ' + s.stretchPct + '%\n';
    o += '    INDEX 01 ' + t(s.atSec) + '\n';
  });
  return o;
}

/* Rebuild a set from a score. Reports what it could not find rather than
   silently dropping it — a short set that looks complete is worse than a
   short set that says why. */
function load(json, corpus) {
  const sc = typeof json === 'string' ? JSON.parse(json) : json;
  if (sc.format !== 'deckwave-set') throw new Error('not a deckwave set file');
  const nm = s => s.toLowerCase().replace(/[^a-z0-9]/g, '');
  const set = [], missing = [];
  sc.steps.forEach(s => {
    const m = corpus.find(t => nm(t.name) === nm(s.name));
    if (m) { m._stretch = s.rate; set.push(m); } else missing.push(s.name);
  });
  return { loaded: set.length, missing, set, score: sc };
}

return { plan, score, cue, load, downbeatNear };
})();
