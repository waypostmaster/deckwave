# The Deckwave Score Format

A DJ set described as executable data rather than rendered audio.

## Why this exists

Existing DJ interchange formats — rekordbox XML, Traktor NML, Serato crates, the `.cue` tradition — capture **track order and cue points**. None of them capture the *transition*: the crossfade curve, the EQ automation, the time-stretch ratio, the parameters of the engine that produced them.

The nearest prior art is DJ.Studio's proprietary `.DJS` project format, which does capture transitions and exports deterministically to Ableton. This format differs in being open, compact, and carrying an **engine block** so a conforming player can reproduce the mix rather than merely describe it.

## The determinism claim, stated honestly

A score plus the same source files should reproduce the same mix. That depends on identical Essentia/WASM builds, identical decode paths, and stable analysis across browser versions.

This is exactly the problem tracker modules have always had: without a normative playback spec, the same file sounds different in different players. The engine block **mitigates** that by declaring what produced the mix. It does not eliminate it.

**Cross-browser determinism has not been tested.** Treat reproducibility as an intent with a declared dependency, not a guarantee, until someone measures it.

## Shape

```json
{
  "format": "deckwave-set",
  "version": 1,
  "generated": "2026-08-17T02:49:56.242Z",
  "engine": {
    "sequencer": "rolling-tempo target, camelot + energy arc, hard stretch gate",
    "drift": 0.35,
    "xfadeSec": 16,
    "maxStretch": 0.08,
    "detector": "essentia.js RhythmExtractor2013 multifeature",
    "keyDetector": "essentia.js KeyExtractor",
    "stretch": "SoundTouchJS AudioWorklet (tempo param, pitch preserved)",
    "transition": "downbeat-aligned crossfade with 3-band bass swap",
    "downbeat": "assumed every 4th beat from first — no downbeat detection",
    "determinism": "depends on identical engine builds; NOT cross-browser tested"
  },
  "summary": {
    "tracks": 99, "runtimeSec": 11815,
    "tempoStart": 100.14, "tempoEnd": 150.48, "maxStretchPct": 7.77
  },
  "steps": [ ... ]
}
```

### A step

| Field | Meaning |
|---|---|
| `i` | position in the set |
| `name` | filename stem, used to re-resolve against a library |
| `bpm` | measured native tempo |
| `camelot` | key in Camelot notation (e.g. `8A`) |
| `key` | key and scale as detected (e.g. `C minor`) |
| `energy` | composite index — **constructed, not measured** (see below) |
| `conf` | detector confidence, Essentia scale 0–5.32 |
| `rate` | tempo multiplier applied at playback |
| `stretchPct` | the same as a percentage, for humans |
| `entrySec` | seek offset — the track's first detected beat |
| `exitSec` | when to begin the outgoing fade, snapped to a downbeat |
| `atSec` | position in the finished mix |
| `xfadeSec` | crossfade length |
| `bassSwapSec` | when the outgoing low shelf drops |
| `durSec` | full track duration |

## Reading it honestly

**`conf` is on Essentia's scale (0–5.32), where 1.5–3.5 is moderately confident.** It is not comparable to any other detector's confidence number. Presenting it against a different algorithm's figure as a before-and-after would be misleading.

**`energy` is a constructed index**, not a measurement: 45% loudness, 25% brightness, 30% tempo, normalised across the corpus. It correlates with what a listener would call energy. It is not the same thing, and the weights were chosen rather than fitted.

**`stretchPct` past ±15% will audibly wobble.** That is a perceptual limit, not a style preference. The sequencer gates at 8% for that reason.

## Companion cue sheet

A standard `.cue` is emitted alongside, with BPM, key and stretch as REM lines. It opens in VLC and foobar2000 and gives track navigation over a rendered mix.
